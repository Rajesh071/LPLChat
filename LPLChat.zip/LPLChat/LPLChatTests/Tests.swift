//
//  Tests.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import XCTest
@testable import LPLChat

class Tests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        XCTAssert(true)
    }
    
    func getMessage(msg:String,time:String) -> Message {
        return Message(type: .text,
                content:msg,
                owner: .sender,
                timeStampStr: time,
                isRead: true,
                image: "")
    }
    
    func test_CreateKeys_FullWeek(){
        
        let calendar = Calendar.current
        
        var chats:[Message] = []
        var expectedKeys:[String] = []
        
        //today -2 entries - 2keys
        let todayDate1 = calendar.date(byAdding: .hour, value: -1, to: Date())
        let todayDate1DisplayStr = todayDate1?.toString(dateFormat: "h:mm a")
        let todayDate1DateStr = todayDate1?.toISO8601String()
        let todayDate1Msg = getMessage(msg: todayDate1DisplayStr!, time: todayDate1DateStr!)
       
        let todayDate2 = calendar.date(byAdding: .hour, value: -2, to: Date())
        let todayDate2DisplayStr = todayDate2?.toString(dateFormat: "h:mm a")
        let todayDate2DateStr = todayDate2?.toISO8601String()
        let todayDate2Msg = getMessage(msg: todayDate2DisplayStr!, time: todayDate2DateStr!)
        
        chats.append(todayDate1Msg)
        chats.append(todayDate2Msg)
        
        expectedKeys.append(todayDate1DisplayStr!) //each time for today
        expectedKeys.append(todayDate2DisplayStr!) //each time for today
        
        //yesterday 2 entries - only 1 key
        
        let sterdayDate1 = calendar.date(byAdding: .day, value: -1, to: Date())
        let sterdayDate1DisplayStr = "Yesterday"
        let sterdayDate1DateStr = sterdayDate1?.toISO8601String()
        let sterdayDate1Msg = getMessage(msg: sterdayDate1DisplayStr, time: sterdayDate1DateStr!)
        
        let sterdayDate2 = calendar.date(byAdding: .hour, value: -2, to: Date())
        let sterdayDate2DisplayStr = "Yesterday"
        let sterdayDate2DateStr = sterdayDate2?.toISO8601String()
        let sterdayDate2Msg = getMessage(msg: sterdayDate2DisplayStr, time: sterdayDate2DateStr!)
        
        chats.append(sterdayDate1Msg)
        chats.append(sterdayDate2Msg)
        
        expectedKeys.append(sterdayDate1DisplayStr) //only 1 for yesterday
        
        
        for n in 2...7 {
            let withInWeek = calendar.date(byAdding: .day, value: -n, to: Date())
            let msgWithinWeekStr = withInWeek?.toString(dateFormat: "eeee")
            let withInWeekDateStr = withInWeek?.toISO8601String()
            let msgWithInWeek = getMessage(msg: msgWithinWeekStr!, time: withInWeekDateStr!)
            chats.append(msgWithInWeek)
            
            let withInWeek2 = calendar.date(byAdding: .day, value: -n, to: Date())
            let msgWithinWeekStr2 = withInWeek2?.toString(dateFormat: "eeee")
            let withInWeekDateStr2 = withInWeek2?.toISO8601String()
            let msgWithInWeek2 = getMessage(msg: msgWithinWeekStr2!, time: withInWeekDateStr2!)
            chats.append(msgWithInWeek2)
            
            expectedKeys.append(msgWithinWeekStr!) //only 1 per week
        }

        for n in 8...10 {
            let daysLongAgo = calendar.date(byAdding: .day, value: -n, to: Date())
            let daysLongAgoDisplayStr = daysLongAgo?.toString(dateFormat: "MMM dd,yyyy")
            let daysLongAgoDateStr = daysLongAgo?.toISO8601String()
            let msgdaysLongAgo = getMessage(msg: daysLongAgoDisplayStr!, time: daysLongAgoDateStr!)
            chats.append(msgdaysLongAgo)
            
            let daysLongAgo2 = calendar.date(byAdding: .day, value: -n, to: Date())
            let daysLongAgoDisplayStr2 = daysLongAgo2?.toString(dateFormat: "MMM dd,yyyy")
            let daysLongAgoDateStr2 = daysLongAgo2?.toISO8601String()
            let msgdaysLongAgo2 = getMessage(msg: daysLongAgoDisplayStr2!, time: daysLongAgoDateStr2!)
            chats.append(msgdaysLongAgo2)
            
            
            expectedKeys.append(daysLongAgoDisplayStr!) //only 1 per date
        }

        
        //Act
        let response = createKeysAndDictionary(chats)
        
        
       
       // let expectedDict:[String:[Message]] = [msg1Text:[msg1], msg2Text:[msg2]]
        
        XCTAssertEqual(expectedKeys, response.keys)
    }
    
    
    
    func createKeysAndDictionary(_ chats:[Message]) -> (keys:[String],dict:[String: [Message]]) {
        
        let newChats = chats.sorted(by: { $0.timeDate < $1.timeDate })
        
                var chatSectionArray = [String]()
                var chatSortedDictionary = [String: [Message]]()

        for chat in newChats{
            
            let dateString = chat.timeDate.ConvertDateToReadableString()
            
            if !(dateString.isEmpty){
                
                if var wordValues = chatSortedDictionary[dateString]{
                    
                    wordValues.append(chat)
                    chatSortedDictionary[dateString] = wordValues
                    
                }
                else{
                    chatSectionArray.append(dateString)
                    chatSortedDictionary[dateString] = [chat]
                }
                
            }
        }
        
        return (chatSectionArray.reversed(),chatSortedDictionary)
    }
   
    func createTimeIntervals(start:Date,end:Date, gapInMins: Int){
       
    }
    
    func testReadableDate() {
        let calendar = Calendar.current
        
        let today = Date()
        XCTAssertEqual(today.ConvertDateToReadableString(), today.toString(dateFormat: "h:mm a"))
        
        let yesterDay = calendar.date(byAdding: .day, value: -1, to: Date())
        XCTAssertEqual(yesterDay!.ConvertDateToReadableString(), "Yesterday")
        
        for n in 2...7 {
            let withInWeek = calendar.date(byAdding: .day, value: -n, to: Date())
            XCTAssertEqual(withInWeek!.ConvertDateToReadableString(), withInWeek?.toString(dateFormat: "eeee"))
        }
        
        let moreThan7DaysAgo = calendar.date(byAdding: .day, value: -8, to: Date())
        XCTAssertEqual(moreThan7DaysAgo!.ConvertDateToReadableString(), moreThan7DaysAgo!.toString(dateFormat: "MMM dd,yyyy"))
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
