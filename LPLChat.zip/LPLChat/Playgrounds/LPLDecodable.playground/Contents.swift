//: Playground - noun: a place where people can play

import UIKit
import Foundation

guard let filePath = Bundle.main.path(forResource: "fetchProspectsResponse", ofType: "json") else {
    assert(false, "❌ bad file path, fetchProspectsResponse.son does not exist")
}

guard let jsonData = FileManager.default.contents(atPath: filePath) else {
    assert(false, "❌ unable to get contents of file")
}

//let jsonString = String(data:jsonData, encoding: String.Encoding.utf8) ?? "Data could not be cast to string"
//print("🤖 jsonString = \(jsonString)")

do {
    let response = try JSONDecoder().decode(ProspectResponse.self, from: jsonData)
    for prospect in response.data {
        print("🤖 prospect = \(prospect)")
    }
} catch {
    print(error.localizedDescription)
}
