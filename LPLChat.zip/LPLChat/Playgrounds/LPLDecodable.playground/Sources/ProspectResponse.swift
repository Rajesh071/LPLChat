import Foundation

public struct ProspectResponse: Decodable {
    public let status: String?
    public let statusMessage: String?
    public let data: [Prospect]
}

public struct Prospect: Decodable {
    public let clientID: String?
    public let firstName: String?
    public let lastName: String?
    public let homePhone: String?
    public let businessPhone: String?
    public let mobilePhone: String?
    public let email: String?
    public let mailingAddressLine1: String?
    public let mailingAddressLine2: String?
    public let mailingAddressLine3: String?
    public let mailingCity: String?
    public let mailingState: String?
    public let mailingZipCode: String?
    public let isProspect: String?
    public let marketValue: String?
    public let unrealizedGainLoss: String?
    public let asofDate: String?
}
