//
//  ServiceType.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/10/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

enum ServiceType: String {
    case disclaimer = "Disclaimer"
    case termsOfUse = "TermsOfUse"
    case license = "License"
    case defaulty = "Default"
}

enum Service: String {
    case asat = "asat"
    case registration = "registration"
    case userRetrieve = "userRetrieve"
    case verifyCallFwd = "verifyCallFwd"
    case verifyTokenAndPhone = "verifyTokenAndPhone"
    case disclaimer = "disclaimer"
    case userInfoSave = "userInfoSave"
    case retreiveNumbers = "retreiveNumbers"
    case registerVirtualNumber = "registerVirtualNumber"
    case termsOfUse = "termsOfUse"
    case license = "license"
    case msgGetAll = "msgGetAll"
    case msgGetMessage = "msgGetMessage"
    case msgPost = "msgPost"
    case searchCity = "searchCity"     // 💢 Dead Code?
    case getStateAreaCode = "getStateAreaCode"
    case contactsGet = "contactsGet"
    case saveDisclaimer = "saveDisclaimer"
    case saveProspect = "saveProspect"
    case saveNote = "saveNote"
    case onlyAppNotes = "onlyAppNotes"
    case allNotes = "allNotes"
}
