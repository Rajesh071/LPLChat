//
//  LPLResult.swift
//  LPLMessages
//
//  Created by Phillip English on 5/24/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum LPLResult {
    case success(Data)
    case failure(Error)
}
