//
//  Sample.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class SampleSvc {

    class func sampleSaveDisclaimer(){
     
        let isAccepted = true
        ServiceManager.saveDisclaimer(isAccepted) { (result) in
            switch result {
            case let .success(value):
                print(value as Any)
            case let .failure(error):
                print(error)
            }
        }
    }
    
    class func regSaveUser(){
        ServiceManager.userInfoSave(callForwardNumber: "1704593936", deviceToken: "", twilioNumber: "1123456789") { (result) in
            
            switch result {
            case let .success(value):
                print(value as Any)
            case let .failure(error):
                print(error)
            }
            
        }
    }
    
    class func sampleVerifyTokenAndPhone(){
        
        let callFwdNumber = "17045939367"
        let code = "1234"
        
        ServiceManager.verifyTokenAndPhone(callForwardNumber: callFwdNumber, token: code) { (result
            ) in
            switch result {
            case let .success(value):
                print(value as Any)
                case let .failure(error):
                print(error)
            }
        }
    }
    
    class func sampleCallFwdVerify_And_SampleToken(){
        
        ServiceManager.verifyCallForward ("17045939367") { (result) in
            switch result {
            case let .success(value):
                print(value as Any)
                //SampleSvc.sampleVerifyTokenAndPhone()
            case let .failure(error):
                print(error)
            }
        }
    }

    class func sampleUserRetrieve() {
        
        ServiceManager.retriveUser { (result) in
            switch result {
            case let .success(value):
                print(value as Any)
            case let .failure(error):
                print(error as Any)
            }
        }
    }

    class func sampleRegisterTwilioVirtualNumber() {
        ServiceManager.registerVirtualNumber("909") { (result) in
            switch result {
            case let .success(value):
                print(value as Any)
            case let .failure(error):
                print(error)
            }
        }
    }
    
    class func sampleSaveProspectToClientWorks() {
        
        let contactInfo = ContactInfo(firstName: "first name",
                                      lastName: "last name",
                                      mobileNumber: "9090909090",
                                      email: "a@bb090.com")
        
        ServiceManager.saveProspectToClientWorks(with: contactInfo) { (result) in
            switch result {
            case let .success(value):
                print(value as Any)
            case let .failure(error):
                print(error)
            }
        }
    }
    
    class func sampleSaveNote() {
        
        let note = Note(noteText: "Now emileen is happy",
                               investorName: "Adam Garvey",
                               clientId: "15203268")
        //        15203268 - Adam Garvey for vigilius.booke

        ServiceManager.save(note: note) { (result) in
            switch result {
            case let .success(value):
                print(value as Any)
            case let .failure(error):
                print(error)
            }
        }
    }
    
    class func sampleFetchNotes() {
        
        //"3766906 : Essenes Uphoff"
        ServiceManager.fetchNotes(with: "3766906", pageNumber: 1, pageSize: 200) { (result) in
            switch result {
            case let .success(value):
                print("🍏 success = \(value as Any)")
                
            case let .failure(error):
                print(error)
            }
        }
    }
    
    class func sampleFetchAllNotes() {
        
        //"3766906 : Essenes Uphoff"
        ServiceManager.fetchNotes(with: "3766906", pageNumber: 1, pageSize: 200, isAppOnly: false) { (result) in
            switch result {
            case let .success(value):
                print("🍏 success = \(value as Any)")
            case let .failure(error):
                print(error)
            }
        }
    }
    
}
