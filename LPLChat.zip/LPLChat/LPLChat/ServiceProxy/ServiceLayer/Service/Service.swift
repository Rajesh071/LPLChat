////
////  Service.swift
////  LPLMessages
////
////  Created by Avinash Rajendran on 4/9/18.
////  Copyright © 2018 LPL. All rights reserved.
////
//
//import Foundation
//
//enum ServiceError: Error {
//    case invalid(String)
//}
//
////TOOD: update names/msgs and enumify this
//class ErrorMessages{
//    static let msg = "Unknown error. Please try again."
//    static let msg401 = "Unauthorized error. Please try again."
//}
//
//class ServiceExecutioner {
//
//    class func executeServiceWith<T: Codable>(urlRequest: URLRequest, type: T.Type,
//                                completionHandler: @escaping (_ resp: Result<T?>) -> ())
//                    -> URLSessionTask {
//
//        let task = URLSession.shared.dataTask(with: urlRequest) { (data, urlResponse, error) in
//
//            guard let httpUrlResponse = urlResponse as? HTTPURLResponse else {
//                completionHandler(Result<T?>(error: ServiceError.invalid(ErrorMessages.msg)))
//                return
//            }
//
//            //status code 401
//            let statusCode = httpUrlResponse.statusCode
//            guard statusCode != 401 else {
//                //TODO global error handling - load login screen ???
//               completionHandler(Result<T?>(error: ServiceError.invalid(ErrorMessages.msg401)))
//                return
//            }
//
//            //any status code other than 200 is considered failure
//            guard  statusCode == 200 else {
//                completionHandler(Result<T?>(error: ServiceError.invalid(ErrorMessages.msg)))
//                return
//            }
//
//            // handle error
//            if let error = error {
//                print(error.localizedDescription)
//                completionHandler(Result<T?>(error: ServiceError.invalid(ErrorMessages.msg)))
//                return
//            }
//
//            //handle result
//            completionHandler(convertDataToResult(data: data))
//        }
//
//        task.resume()
//
//        // return task - so caller can cancel it if needed ( for type ahead  search scenarios )
//        return task
//    }
//
//    //TODO: resuse this method and write a call with empty result
////    class func call<T: Codable>(url: URL, type: T.Type,
////                                completionHandler: @escaping (_ resp: Result<T?>) -> ())
////                    -> URLSessionTask {
//
//
//    class func convertDataToResult<T: Codable>(data: Data?) -> Result<T?> {
//
//        do {
//            //Error: empty response
//            guard let data = data else {
//                return Result<T?>(error: ServiceError.invalid(ErrorMessages.msg))
//            }
//
//            let serviceResponse = try JSONDecoder().decode(ServiceResponseCodable<T>.self, from: data)
//
//            //any status other than "success" is considered failure
//            guard serviceResponse.status == "success" else {
//                return Result<T?>(error: ServiceError.invalid(serviceResponse.statusMessage ?? ErrorMessages.msg))
//            }
//
//            let successResult = Result<T?>(value: serviceResponse.data ?? nil)
//            return successResult //only success scenario
//
//        } catch let error {
//            print(error.localizedDescription)
//            return Result<T?>(error: ServiceError.invalid(ErrorMessages.msg))
//            
//        }
//    }
//
//    class func log(data: Data?, urlResponse: URLResponse?, error: Error?) {
//        //TODO : log
//        //log verbose  : log url , request header, response headers, error, statuscode, response
//        //log info mode log url , error, statuscode
//        //log error with error
//    }
//}
