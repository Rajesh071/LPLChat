//
//  URLDataManager.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/10/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

//struct URLDataManager {
//
//    func getURLWith(serviceType: Service) -> String {
//
//        return EnvironmentManager.baseWebApiUrl + ServiceURL.getURLWith(serviceName: serviceType)
//    }
//}

