//
//  LocalDataManager.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/9/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import Foundation

struct LocalDataManager {

}
