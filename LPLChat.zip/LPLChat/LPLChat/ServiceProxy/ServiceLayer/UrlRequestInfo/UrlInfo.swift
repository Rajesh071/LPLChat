//
//  UrlInfo.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 4/10/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import Foundation

struct UrlRequestInfo {
    var service:Service
    var baseUrl :String
    var endpoint :String
    var httpType :HTTPMethodType
    var headers :HeaderBuilderProtocol
}

protocol HeaderBuilderProtocol {
    func build() -> [String:String]
}

struct HeaderBuilder : HeaderBuilderProtocol{
   
    func build() -> [String:String] {
        
        let headers = [
            "transactionId": UUID().uuidString,
            "timestamp": Date().toISO8601String(),
            "sourceSystem": "LPLMessage",
            "X-XSRF-TOKEN": AppStateData.shared.getXSRFCookie() ,
            "Cookie": AppStateData.shared.getCookie(),
            "Accept": "application/json",
            "Content-Type": "application/json",
            "TimeZone": TimeZoneUtil.timezone()
        ]
        
        return headers
    }
}

struct UrlInfoManager {
    
    static var config = Configuration()
    
    static func retreive(key:Service) -> UrlRequestInfo  {
        
        var urlRequestInfo: UrlRequestInfo?
        
        switch key {
        case .asat:
            urlRequestInfo = createASAT()
            
        case .disclaimer:
            urlRequestInfo = createDisclaimer()
            
        case .retreiveNumbers:
            urlRequestInfo = createRetrieveNumbers()

        case .userRetrieve:
            urlRequestInfo = createUserRetrieve()
        
        case .registerVirtualNumber:
            urlRequestInfo = createRegisterVirtualNumber()
       
        case .verifyCallFwd:
            urlRequestInfo = createVerifyCallFwd()
            
        case .verifyTokenAndPhone:
            urlRequestInfo = createVerifyTokenAndPhone()
            
        case .userInfoSave:
            urlRequestInfo = createUserInfoSave()
            
        case .saveDisclaimer:
            urlRequestInfo = createSaveDisclaimer()
         
        case .saveProspect:
            urlRequestInfo = createSaveProspect()
            
        case .saveNote:
            urlRequestInfo = createSaveNote()
        
        case .onlyAppNotes:
            urlRequestInfo = createFetchNotes()
      
        case .allNotes:
            urlRequestInfo = createFetchNotes(isAppOnly: false)
            
        // 💢 Dead Code?
        case .searchCity:
            urlRequestInfo = createSearchCity()

        case .getStateAreaCode:
            urlRequestInfo = createGetStateAreaCodes()

        case .msgGetMessage:
            urlRequestInfo = createMsgGet()
            
        case .msgGetAll:
            urlRequestInfo = createMsgGetAll()
            
        case .msgPost:
            urlRequestInfo = createMsgPost()
            
        default :
            //throw
            print("\(key) missing")
        }// switch end
        
        return urlRequestInfo!
    }
  
    static func createRegisterVirtualNumber() -> UrlRequestInfo{
        
        let service:Service = .registerVirtualNumber
        
        let userUrlInfo = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .post,
            headers: HeaderBuilder())
        
        return userUrlInfo
    }
    
    static func createUserRetrieve() -> UrlRequestInfo{
        
        let service:Service = .userRetrieve

        let userUrlInfo = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .get,
            headers: HeaderBuilder())
        
        return userUrlInfo
    }
    
    static func createASAT() -> UrlRequestInfo{
        let asatUrlInfo = UrlRequestInfo(
            service: .asat,
            baseUrl: config.environment.baseLPLServicesUrl,
            endpoint: ServiceURL.getURLWith(serviceName: .asat),
            httpType: .get,
            headers: HeaderBuilder())
        
        return asatUrlInfo
    }
    
    static func createDisclaimer() -> UrlRequestInfo {
        let disclaimer = UrlRequestInfo(
            service: .disclaimer,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: .disclaimer),
            httpType: .get,
            headers: HeaderBuilder())
        
        return disclaimer
    }
    
    static func createRetrieveNumbers() -> UrlRequestInfo {
        let info = UrlRequestInfo(
            service: .retreiveNumbers,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: .retreiveNumbers),
            httpType: .post,
            headers: HeaderBuilder())
        
        return info
    }
    
     static func createVerifyCallFwd() -> UrlRequestInfo{
        let service:Service = .verifyCallFwd
        let userUrlInfo = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .post,
            headers: HeaderBuilder())
        
        return userUrlInfo
    }
    
    static func createVerifyTokenAndPhone() -> UrlRequestInfo{
        
        let service:Service = .verifyTokenAndPhone
        let userUrlInfo = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .post,
            headers: HeaderBuilder())
        
        return userUrlInfo
    }
    
    static func createUserInfoSave() -> UrlRequestInfo{
        
        let service:Service = .userInfoSave
        let userUrlInfo = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .post,
            headers: HeaderBuilder())
        
        return userUrlInfo
    }
    
    static func createSaveDisclaimer() -> UrlRequestInfo{
        
        let service:Service = .saveDisclaimer
        let userUrlInfo = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .post,
            headers: HeaderBuilder())
        
        return userUrlInfo
    }
    
    static func createSaveProspect() -> UrlRequestInfo {
        let info = UrlRequestInfo(
            service: .saveProspect,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: .saveProspect),
            httpType: .post,
            headers: HeaderBuilder())
        
        return info
    }
    
    static func createSaveNote() -> UrlRequestInfo {
        let info = UrlRequestInfo(
            service: .saveNote,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: .saveNote),
            httpType: .post,
            headers: HeaderBuilder())
        
        return info
    }
    
    static func createFetchNotes(isAppOnly: Bool? = true) -> UrlRequestInfo {
        
        let service: Service = isAppOnly == true ? .onlyAppNotes : .allNotes
        let info = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .get,
            headers: HeaderBuilder())
        
        return info
    }
    
    // 💢 Dead Code?
    static func createSearchCity() -> UrlRequestInfo {
        
        let service:Service = .searchCity
        let disclaimer = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .get,
            headers: HeaderBuilder())
        
        return disclaimer
    }
    
    static func createGetStateAreaCodes() -> UrlRequestInfo {
        
        let service:Service = .getStateAreaCode
        let disclaimer = UrlRequestInfo(
            service: service,
            baseUrl: config.environment.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .get,
            headers: HeaderBuilder())
        
        return disclaimer
    }

    
    static func createMsgGet() -> UrlRequestInfo {
        let service: Service = .msgGetMessage
        
        let userUrlInfo = UrlRequestInfo(service: service, baseUrl: config.environment.baseWebApiUrl, endpoint: ServiceURL.getURLWith(serviceName: service), httpType: .get, headers: HeaderBuilder())
        
        return userUrlInfo
    }
    
    static func createMsgGetAll() -> UrlRequestInfo {
        let service: Service = .msgGetAll
        
        let userUrlInfo = UrlRequestInfo(service: service, baseUrl: config.environment.baseWebApiUrl, endpoint: ServiceURL.getURLWith(serviceName: service), httpType: .get, headers: HeaderBuilder())
        
        return userUrlInfo
    }
    
    static func createMsgPost() -> UrlRequestInfo {
        let service: Service = .msgPost
        
        let userUrlInfo = UrlRequestInfo(service: service, baseUrl: config.environment.baseWebApiUrl, endpoint: ServiceURL.getURLWith(serviceName: service), httpType: .post, headers: HeaderBuilder())
        
        return userUrlInfo
    }
}
