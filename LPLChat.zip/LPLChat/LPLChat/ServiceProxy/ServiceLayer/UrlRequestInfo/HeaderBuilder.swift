//
//  HeaderBuilder.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/11/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation


protocol HeaderBuilderProtocol {
    func build() -> [String:String]
}

struct HeaderBuilderForPartnerService : HeaderBuilderProtocol{
    
    func build() -> [String:String] {
        
        let headers: [String:String] = [
            "Accept":"application/json",
            "client_id":EnvConstants.clientId,
            "client_secret":EnvConstants.clientSecret,
            "Content-Type":"application/json",
            "Cookie":AppStateData.shared.getCookie(),
            "origin":EnvConstants.headerOrigin,
            "x-api-rep-id":Session.getUser()?.repId ?? "",
            "x-api-tenant-id":"1",
            "x-api-transaction-id": UUID().uuidString,
            "X-XSRF-TOKEN": AppStateData.shared.getXSRFCookie()
        ]
        return headers
    }
}

struct HeaderBuilder : HeaderBuilderProtocol{
    
    func build() -> [String:String] {
        
        let headers = [
            "transactionId": UUID().uuidString,
            "timestamp": Date().toISO8601String(),
            "sourceSystem": "LPLMessage",
            "X-XSRF-TOKEN": AppStateData.shared.getXSRFCookie() ,
            "Cookie": AppStateData.shared.getCookie(),
            "Accept": "application/json",
            "Content-Type": "application/json",
            "TimeZone": TimeZoneUtil.timezone()
        ]
        
        return headers
    }
}
