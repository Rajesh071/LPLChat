//
//  RegUrlInfo.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/11/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class RegUrlInfo{
    
    static func createAll(){
        createASAT()
        createDisclaimer()
        createCheckRegistration()
    }
    
    /*
     
     static let userASATCheck        = EnvConstants.baseWebApiUrl + "user/information/asat/check"
     static let regSaveDisclaimer    = EnvConstants.baseWebApiUrl + "disclaimer/save"
     static let checkRegistration    = EnvConstants.baseWebApiUrl + "user/registration/status"
     static let userRetrieve         = EnvConstants.baseWebApiUrl + "user/information/retrieve"
     
     static let verifyCallFwd        = EnvConstants.baseWebApiUrl + "user/information/callfwd/verify"
     static let verifyTokenAndPhone  = EnvConstants.baseWebApiUrl + "user/information/callfwd/save"
     static let userInfoSave         = EnvConstants.baseWebApiUrl + "user/information/save"
     
     static let regRetreiveNumbers   = EnvConstants.baseWebApiUrl + "twilio/numbers/retrieve"
     static let regSaveNumber        = EnvConstants.baseWebApiUrl + "user/information/twilionumber/save"
     
     static let disclaimer           = EnvConstants.baseWebApiUrl + "User/Information/GetConfig/Disclaimer"
     
     static let termsOfUse           = EnvConstants.baseWebApiUrl + "Information/GetConfig/termsofuse"
     
     */
    
    static func createASAT() {
        let asatUrlInfo = UrlRequestInfo(
            service: .asat,
            baseUrl: EnvironmentManager.baseLPLServicesUrl,
            endpoint: ServiceURL.getURLWith(serviceName: .asat),
            httpType: .get,
            headers: HeaderBuilder())
        
        UrlInfoManager.register(info: asatUrlInfo, for: .asat)
    }
    
    static func createDisclaimer() {
        
        let service : Service = .registration
        
        let disclaimer = UrlRequestInfo (
            service: service,
            baseUrl: EnvironmentManager.baseWebApiUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .get,
            headers: HeaderBuilder())
        
        UrlInfoManager.register(info: disclaimer, for: service)
    }
    
    static func createCheckRegistration() {
        
        let service : Service = .registration
        
        let urlInfo = UrlRequestInfo(
            service: service,
            baseUrl: EnvironmentManager.baseLPLServicesUrl,
            endpoint: ServiceURL.getURLWith(serviceName: service),
            httpType: .get,
            headers: HeaderBuilder())
        
        UrlInfoManager.register(info: urlInfo, for: service)
    }
    
   
}
