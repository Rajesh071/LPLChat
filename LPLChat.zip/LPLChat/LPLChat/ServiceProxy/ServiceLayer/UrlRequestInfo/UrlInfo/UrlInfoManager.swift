//
//  UrlInfoManager.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/11/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct UrlInfoManager {
    
    static var allUrlInfo :[Service:UrlRequestInfo]! = [:]
    
    static func register(info: UrlRequestInfo, for service: Service) {
         allUrlInfo[service] = info
    }
    
    static func retreive(key:Service) -> UrlRequestInfo!  {
        return allUrlInfo[key]!
    }   
}
