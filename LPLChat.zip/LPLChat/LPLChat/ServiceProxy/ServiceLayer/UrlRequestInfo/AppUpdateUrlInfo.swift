//
//  AppUpdateUrlInfo.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 4/10/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import Foundation

// 💢 Dead Code? 
//struct AppUpdateUrlInfo {
//
//    func retreive() -> UrlRequestInfo {
//        var config = Configuration()
//
//        return UrlRequestInfo(
//            service: .asat,
//            baseUrl: config.environment.baseLPLServicesUrl,
//            endpoint: ServiceURL.userASATCheck,
//            httpType: .get,
//            headers: HeaderBuilder())
//    }
//}
