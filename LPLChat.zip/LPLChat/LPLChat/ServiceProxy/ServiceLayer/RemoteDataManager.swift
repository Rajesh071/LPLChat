//
//  RemoteDataManager.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/9/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

typealias GenericCompletionHandler<T> = (Result<T?>) -> ()
typealias NonOptionalCompletion<T> = (Result<T>) -> ()
typealias LPLResultCompletion = (LPLResult) -> ()

struct RemoteDataManager {
    
    static func postChatMessage(_ fromNumber: String, fromName: String, receiverNumber: String, messageText: String, completionHandler: @escaping LPLResultCompletion) {
        let formattedToNumber = "+" + CustomUtility.removeFormatting(receiverNumber).removeWhiteListedCharacters()
        let receiverContactList: [[String: String]] = [["toNumber": formattedToNumber]]
        let params: [String: Any] = ["fromNumber": fromNumber, "fromName": fromName, "receiverContactList": receiverContactList, "messageText": messageText]
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(for: .msgPost, params: params)
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWithData(urlRequest: request) { result in
                completionHandler(result)
                
            }
        }
        
    }
    
    static func retrieveChatsAll(_ pageNo: Int = 1, pageSize: Int = 10, completionHandler: @escaping LPLResultCompletion) {
        let components: [Any] = [pageNo, pageSize]
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(for: .msgGetAll, components: components)
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWithData(urlRequest: request) { result in
                completionHandler(result)
                
            }
        }
//        if let request = urlRequest {
//            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type: CodableChatsCollection.self) { result in
//
//                completionHandler(result)
//            }
//        }
    }
    
    static func retrieveChatDetails(_ phoneNumber: String, pageNo: Int = 1, pageSize: Int = 10, completionHandler: @escaping LPLResultCompletion) {
        //Passing version number as component string for updated url
        let components : [Any] = [phoneNumber,"1.3", pageNo,pageSize]
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(for: .msgGetMessage, components: components)
        if let request = urlRequest {
//            let _ = ServiceExecutioner.executeChatServiceWith(urlRequest: request,
//                                                          type: ChatDetails.self) { result in
//                                                            completionHandler(result)
//            }
            let _ = ServiceExecutioner.executeServiceWithData(urlRequest: request) { result in
                completionHandler(result)
                
            }
        }
        
    }

    
    static func retrieveUser(_ completionHandler: @escaping GenericCompletionHandler<ModelUser>) {
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(for: .userRetrieve)
        if let request = urlRequest { 
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type: ModelUser.self) { (result) in
                completionHandler(result)
            }
        }
    }
    
    static func retriveDisclaimer(_ completionHandler: @escaping GenericCompletionHandler<Disclaimer>) {
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(for: .disclaimer)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request,
                                                          type: Disclaimer.self) { result in
                                                            completionHandler(result)
            }
        }
    }

    static func retrieveStateAreaCodes(_ searchText: String, pageNo:Int, pageSize:Int,
                                  _ completionHandler: @escaping GenericCompletionHandler<[StateAreaCodes]>) {
        
        if searchText.count > 2 {
            //this order is important
            let components : [Any] = [searchText.trim()]
            
            let urlRequest : URLRequest? = QueryBuilder.constructUrlRequest(for: .getStateAreaCode, components:components)
            
            if let request = urlRequest {
                let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type: [StateAreaCodes].self) {
                    result in
                    completionHandler(result)
                }
            }
        }
    }


    static func retreiveNumbers(state:String, areaCode:String,
                                _ completionHandler: @escaping GenericCompletionHandler<[RetrieveNumberResponse]>) {
        
        let params :[String:Any] = ["state": state,"areaCode": areaCode]
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(for: .retreiveNumbers,
                                                                       params:params)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request,
                                                          type: [RetrieveNumberResponse].self) { (result) in
                completionHandler(result)
            }
        }
    }
    
    static func registerVirtualNumber(_ phoneNumber :String, _ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        
        let token = DeviceTokenHelpers.getTokenFromApp()
        let params :[String:Any] = ["phoneNumber": phoneNumber,
                                    "deviceToken": token ?? ""]
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(
            for: .registerVirtualNumber,
            params:params)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type: String.self) { result in
                
                //Business Logic - to convert response
                //in case of success , Service returns "Success"
                //in case of failure , Service returns  object{} }
                
                var boolResult = Result<Bool?>(error: ServiceError.invalid(ErrorMessages.msg))
                
                switch result {
                case let .success(value):
                    if value?.uppercased() == "SUCCESS"{
                        boolResult = Result<Bool?>(value: true)
                    }
                case let .failure(error):
                    boolResult = Result<Bool?>(error: error)
                }
                
                completionHandler(boolResult)
            }
        }
    }
    
    static func verifyCallForward(_ callForwardNumber:String, _ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        
        let params :[String:Any] = ["fwdNumber": callForwardNumber]
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(
            for: .verifyCallFwd,
            params: params)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type: Bool.self) { (result) in
                completionHandler(result)
            }
        }
    }
    
    
    static func verifyTokenAndPhone (callForwardNumber:String, token : String, _ completionHandler: @escaping GenericCompletionHandler<Bool>){
        let deviceToken = DeviceTokenHelpers.getTokenFromApp()
        let params :[String:Any] = ["fwdNumber": callForwardNumber,
                                    "verificationCode":token,
                                    "deviceToken": deviceToken ?? ""]
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(
            for: .verifyTokenAndPhone,
            params: params)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type: Bool.self) { (result) in
                completionHandler(result)
            }
        }
    }
    
    static func userInfoSave(callForwardNumber: String,
                    deviceToken: String,
                    twilioNumber:String,
                    _ completionHandler: @escaping GenericCompletionHandler<Bool>){
        
        let params : [String:Any] = ["callForwardNumber":callForwardNumber,
                                        "deviceToken":deviceToken,
                                        "twilioNumber":twilioNumber]
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(
            for: .userInfoSave,
            params: params)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type: Bool.self) { (result) in
                completionHandler(result)
            }
        }
    }
    
    static func saveProspectToClientWorks(with contactInfo: ContactInfo,
                                          _ completionHandler: @escaping GenericCompletionHandler<SaveProspectResponse>) {
        
        let params : [String:Any] = ["fName": contactInfo.firstName,
                                     "lName": contactInfo.lastName,
                                     "mobileNo": contactInfo.mobileNumber,
                                     "email": contactInfo.email]
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(
            for: .saveProspect,
            params: params)

        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request,
                                                          type: SaveProspectResponse.self) { (result) in
                completionHandler(result)
            }
        }
    }
    
    static func save(note: Note,
                     _ completionHandler: @escaping GenericCompletionHandler<Int>) {
        let params : [String:Any] = ["noteText": note.noteText ?? "",
                                     "investorName": note.investorName ?? "",
                                     "clientID": note.clientID ?? ""]
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(
            for: .saveNote,
            params: params)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request,
                                                          type: Int.self) { (result) in
                                                            completionHandler(result)
            }
        }
    }
    
    static func fetchNotes(with clientID: String, pageNumber: Int, pageSize: Int, isAppOnly: Bool? = true, _ completionHandler: @escaping GenericCompletionHandler<[AdvisorNote]>) {
        
        let components: [Any] = [clientID, pageNumber, pageSize]

        let currentRequest: Service = isAppOnly == true ? .onlyAppNotes : .allNotes
        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(for: currentRequest, components: components)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type:  Array<AdvisorNote>.self) { (result) in
                completionHandler(result)
            }
        }
    }

    static func saveDisclaimer(_ isAccepted:Bool,
                               _ completionHandler: @escaping GenericCompletionHandler<SaveDisclaimerResponse>) {
        
        let params : [String:Any] = ["accepted":isAccepted]
                                        
        let urlRequest: URLRequest? = QueryBuilder.constructUrlRequest(
            for: .saveDisclaimer,
            params: params)
        
        if let request = urlRequest {
            let _ = ServiceExecutioner.executeServiceWith(urlRequest: request, type: SaveDisclaimerResponse.self) { (result) in
                completionHandler(result)
            }
        }

    }
}
