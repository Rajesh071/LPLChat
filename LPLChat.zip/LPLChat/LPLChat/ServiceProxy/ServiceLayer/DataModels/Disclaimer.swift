//
//  Disclaimer.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/11/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct Disclaimer: Codable {
    
    var ConfigValue: String?
}

struct RetrieveNumberResponse : Codable {
    var phone_number : String?
}

struct SaveDisclaimerResponse : Codable {    
}

struct StateAreaCodes: Codable {
    var state: String?
    var areaCode: String?
    
    enum CodingKeys: String, CodingKey {
        case state = "State"
        case areaCode = "AreaCode"
    }
}

struct SaveProspectResponse : Codable {
    var clientId: Int?
}
