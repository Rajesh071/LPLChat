//
//  ModelUser.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/12/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct ModelUser : Codable {
    var advisorBusinessnumberId: String?
    var userName: String?
    var fullname: String?
    var firstName: String?
    var lastName: String?
    var state: String?
    var city: String?
    var zipCode: String?
    var phoneNumbers: [String]?
    var isRegistered: Bool?
}
