//
//  EnvironmentManager.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/10/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

// 💢 Dead Struct
struct EnvironmentManager {

    // 💢 Dead Code?
    #if Dev
    
    // debug
//    static let baseLPLServicesUrl =  "https://clientworksdevint.lpl.com/ieCors/"
//    static let baseWebApiUrl =  "https://webapidvi.dev.lpl.com/lplmessagingwebapi/"
//    static let baseSharedServicesUrl = "https://apidvi.dev.lpl.com/"

//    static let urlLogin = "https://logindevint.lpl.com"
//    static let urlSuccess = "https://clientworksdevint.lpl.com/clientmanagement/"
//    static let clientId = "491e2a25eeb541daa6b2dbb7a4b6ce3d"
//    static let clientSecret = "4DD655BBae7641ff8921484654f91a2F"
//    static let headerOrigin = "https://clientworksdevint.lpl.com"
//    static let env = "DevInt"
    
    #elseif QA
    // release
//    static let baseLPLServicesUrl =  "https://clientworksqa.lpl.com/ieCors/"
//    static let baseWebApiUrl =  "https://webapiqa.qa.lpl.com/lplmessagingwebapi/"
//    static let baseSharedServicesUrl = "https://apiqa.qa.lpl.com/"
    
//    static let urlLogin = "https://loginqa.lpl.com"
//    static let urlSuccess = "https://clientworksqa.lpl.com/clientmanagement/"
//    static let clientId  = "2ac772ef99964d7f9623947af4f35fa8"
//    static let clientSecret = "98f424aE865D4731ae74591256732512"
//    static let headerOrigin = "https://clientworksqa.lpl.com"
//    static let env = "QA"
    
    #else
    // app store
//    static let baseLPLServicesUrl =  "https://clientworks.lpl.com/ieCors/"
//    static let baseWebApiUrl =  "https://webapi.lpl.com/lplmessagingwebapi/"
//    static let baseSharedServicesUrl = "https://api.lpl.com/"

//    static let urlLogin = "https://login.lpl.com"
//    static let urlSuccess = "https://clientworks.lpl.com/clientmanagement/"
//    static let clientId = "8b9b6bf850c343dbab85b080ffcb5cf3"
//    static let clientSecret = "f8371DCB4d174b238ffC5087eD26249D"
//    static let headerOrigin = "https://clientworks.lpl.com"
//    static let env = "Prod"
    
    #endif
}
