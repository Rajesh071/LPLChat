//
//  QueryBuilder.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/10/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import Foundation

struct QueryBuilder {
    
    static func constructUrlRequest(for service:Service,
                                    params:[String:Any]? = [:],
                                    headers:[String:String]? = [:] ,
                                    components:[Any]? = nil) -> URLRequest? {
        
        let info :UrlRequestInfo = UrlInfoManager.retreive(key:service)
        let url = info.baseUrl + info.endpoint
        var serviceUrl = URL.init(string: url)
        
        //Add components like /searchQuery/1/100
        if let components = components{
            for comp in components{
                // Encoding done automatically.
                serviceUrl?.appendPathComponent("\(comp)")
            }
        }
        
        /*
        Add queryString Params like  ?foo=bar&abc=def
         if let queryParams = queryParams{
            url = url + ""
         }
         */
        
        log.verbose(serviceUrl?.absoluteString as Any)
        
        var request = URLRequest.init(url: serviceUrl!)
        request.httpMethod = info.httpType.rawValue
        request.allHTTPHeaderFields = info.headers.build()
        
        if !(headers?.isEmpty)! {
            for (key,value) in headers!{
                request.setValue(value, forHTTPHeaderField: key)
            }
        }
        
        if !(params?.isEmpty)! {
            guard let httpBody = try? JSONSerialization.data(withJSONObject: params as Any, options: []) else {
                print("error in creating data for params")
                return nil
            }
            request.httpBody = httpBody
        }
        
        return request
    }
}
