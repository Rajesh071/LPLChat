//
//  Service.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/9/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum ServiceError: Error {
    case invalid(String)
}

//typealias ChatType = ChatDetails.Type & ChatData.Type

//TOOD: update names/msgs and enumify this
class ErrorMessages{
    static let msg = "Unknown error. Please try again."
    static let msg401 = "Unauthorized error. Please try again."    
}

class ServiceExecutioner {
    
    class func executeServiceWithData(urlRequest: URLRequest, completionHandler: @escaping (_ resp: LPLResult) -> () ) -> URLSessionTask {
        logReq(urlRequest: urlRequest)
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, urlResponse, error) in
            
            logResponse(data:data,urlResponse:  urlResponse,error:  error)
            
            guard let httpUrlResponse = urlResponse as? HTTPURLResponse else {
                //completionHandler(Result<T?>(error: ServiceError.invalid(ErrorMessages.msg)))
                completionHandler(.failure(ServiceError.invalid(ErrorMessages.msg)))
                return
            }
            
            //status code 401
            let statusCode = httpUrlResponse.statusCode
            guard statusCode != 401 else {
                //TODO global error handling - load login screen ???
               // completionHandler(Result<T?>(error: getError(ErrorMessages.msg401, "401")))
                completionHandler(.failure(getError(ErrorMessages.msg401, "401")))
                return
            }
            
            //any status code other than 200 is considered failure
            guard  statusCode == 200 else {
                //completionHandler(Result<T?>(error: getError(ErrorMessages.msg, "\(statusCode)")))
                completionHandler(.failure(getError(ErrorMessages.msg, "\(statusCode)")))
                return
            }
            
            // handle error
            if let error = error {
                //completionHandler(Result<T?>(error: getError(error)))
                completionHandler(.failure(getError(error)))
                return
            }
            guard let data = data else { completionHandler(.failure(getError(ErrorMessages.msg, "error")))
                return
            }
            //completionHandler(convertDataToResult(data: data))
            completionHandler(.success(data))
            
        }
        
        task.resume()
        
        // return task - so caller can cancel it if needed ( for type ahead  search scenarios )
        return task
    }
    
    class func executeServiceWith<T: Codable>(urlRequest: URLRequest, type: T.Type, completionHandler: @escaping (_ resp: Result<T?>) -> ()) -> URLSessionTask {
            
            
            logReq(urlRequest: urlRequest)

            let task = URLSession.shared.dataTask(with: urlRequest) { (data, urlResponse, error) in
               logResponse(data:data, urlResponse:urlResponse, error:error)
                
                guard let httpUrlResponse = urlResponse as? HTTPURLResponse else {
                    completionHandler(Result<T?>(error: ServiceError.invalid(ErrorMessages.msg)))
                    return
                }
               
                //status code 401
                let statusCode = httpUrlResponse.statusCode
                guard statusCode != 401 else {
                    //TODO global error handling - load login screen ???
                    completionHandler(Result<T?>(error: getError(ErrorMessages.msg401, "401")))
                    return
                }
                
                //any status code other than 200 is considered failure
                guard  statusCode == 200 else {
                    completionHandler(Result<T?>(error: getError(ErrorMessages.msg, "\(statusCode)")))
                    return
                }
                
                // handle error
                if let error = error {                  
                    completionHandler(Result<T?>(error: getError(error)))
                    return
                }
                
//                guard let objectFromData = convertDataToObject(data: data, type: type) else { completionHandler(Result<T?>(value: nil))
//                    return
//                }
//                print(objectFromData)
                
                
                //handle result
                      //let testResult = convertDataToResult(data: data)
//                let collection = convertChatDataToCollection(data: data, type: type)
//                completionHandler(Result<ChatCollection?>(value: collection))
               // completionHandler(Result<T?>(value: objectFromData))
                    completionHandler(convertDataToResult(data: data))
              
            }
            
            task.resume()
            
            // return task - so caller can cancel it if needed ( for type ahead  search scenarios )
            return task
    }
    
    //This is a temporary fix until chat api is modified away from unkeyed data array
    class func executeChatServiceWith<T: Codable>(urlRequest: URLRequest, type: T.Type,
                                                  completionHandler: @escaping (_ resp: Result<ChatCollection<T>?>) -> ())
        -> URLSessionTask {
            
            
            logReq(urlRequest: urlRequest)
            
            let task = URLSession.shared.dataTask(with: urlRequest) { (data, urlResponse, error) in
                
                logResponse(data:data,urlResponse:  urlResponse,error:  error)
                
                guard let httpUrlResponse = urlResponse as? HTTPURLResponse else {
                    completionHandler(Result<ChatCollection?>(error: ServiceError.invalid(ErrorMessages.msg)))
                    return
                }
                
                //status code 401
                let statusCode = httpUrlResponse.statusCode
                guard statusCode != 401 else {
                    //TODO global error handling - load login screen ???
                    completionHandler(Result<ChatCollection?>(error: getError(ErrorMessages.msg401, "401")))
                    return
                }
                
                //any status code other than 200 is considered failure
                guard  statusCode == 200 else {
                    completionHandler(Result<ChatCollection?>(error: getError(ErrorMessages.msg, "\(statusCode)")))
                    return
                }
                
                // handle error
                if let error = error {
                    completionHandler(Result<ChatCollection?>(error: getError(error)))
                    return
                }
                
                //handle result
                //let collection = //convertChatDataToCollection(data: data)
                let collection = convertChatDataToCollection(data: data, type: type)
                
                
                completionHandler(Result<ChatCollection?>(value: collection))
                
            }
            
            task.resume()
            
            // return task - so caller can cancel it if needed ( for type ahead  search scenarios )
            return task
    }

    
    
    
    //TODO: resuse this method and write a call with empty result
    //    class func call<T: Codable>(url: URL, type: T.Type,
    //                                completionHandler: @escaping (_ resp: Result<T?>) -> ())
    //                    -> URLSessionTask {
    
    
    
    class func convertDataToResult<T: Codable>(data: Data?) -> Result<T?> {
        
        
        do {
            guard let data = data else {
                return Result<T?>(error: getError(ErrorMessages.msg, "Empty Response"))
            }
            
            let serviceResponse = try JSONDecoder().decode(ServiceResponseCodable<T>.self, from: data)
            
            //any status other than "success" is considered failure
            guard serviceResponse.status == "success" else {
                return Result<T?>(error: ServiceError.invalid(serviceResponse.statusMessage ?? ErrorMessages.msg))
            }
            
        
            let successResult = Result.success(serviceResponse.data)


            return successResult //only success scenario

        } catch let error {
            return Result<T?>(error: getError(error))
        }
        
    }
    
    class func convertDataToObject<T: Codable>(data: Data?, type: T.Type) -> T? {
        guard let data = data else { return nil }
        do {
            let serviceResponse = try JSONDecoder().decode(ServiceResponseCodable<T>.self, from: data)
            
            guard serviceResponse.status == "success" else {
                return nil
            }
            
            return serviceResponse.data
            
        } catch  {
            return nil
        }
        
    }
    
    //This is a temporary fix while we wait for the API payload to be updated sans array. - Phil
    class func convertChatDataToCollection<T: Codable>(data: Data?, type: T.Type) -> ChatCollection<T>? {
        guard let data = data else { return nil }
        
        
        do {
            let serviceResponse = try JSONDecoder().decode(ServiceResponseCodableUnkeyedData<T>.self, from: data)
            
            guard serviceResponse.status == "success" else {
                return nil
            }
            
            //let chats = ChatCollection(chats: serviceResponse.data)
            var chatCollection = ChatCollection<T>()
            let chats = serviceResponse.data
            chatCollection.chats = chats
            
            return chatCollection
        } catch  {
            return nil
        }
        
    }



   
    class func getError(_ errorMsg:String, _ debugMessage:String) -> Error{
        
        var finalError: Error
        
        #if Dev
        finalError = ServiceError.invalid("\(errorMsg) \(debugMessage)")
        #elseif QA
        finalError = ServiceError.invalid("\(errorMsg) \(debugMessage)")
        #else
        // PROD: User displayable error messages
        finalError = ServiceError.invalid(errorMsg)
        #endif
        
        return finalError
    }
    
    
    
    class func getError(_ error:Error) -> Error{
        
        var finalError: Error
        
        #if Dev
            finalError = error
        #elseif QA
            finalError = error
        #else
        // PROD: User displayable error messages
            finalError = ServiceError.invalid(ErrorMessages.msg)
        #endif
        
        return finalError
    }
    
    class func logReq(urlRequest: URLRequest) {
          log.verbose(urlRequest)
    }
    
    class func logResponse(data: Data?, urlResponse: URLResponse?, error: Error?) {
        
        let httpUrlResponse = urlResponse as? HTTPURLResponse  
        log.verbose(httpUrlResponse as Any)
        
        if let error = error{
            log.error(error)
        }
        
        if let data = data{
            log.verbose(String(data:data,encoding:.utf8) ?? "empty")
        }
        
        //TODO : log
        //log verbose  : log url , request header, response headers, error, statuscode, response
        //log info mode log url , error, statuscode
        //log error with error
    }
}
