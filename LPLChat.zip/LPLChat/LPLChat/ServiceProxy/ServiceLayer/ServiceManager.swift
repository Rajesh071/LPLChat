//
//  ServiceManager.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/9/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

struct ServiceManager {

    static func retriveDisclaimerWith(_ completionHandler: @escaping GenericCompletionHandler<Disclaimer>) {
        RemoteDataManager.retriveDisclaimer(completionHandler)
    }

    static func retriveUser(_ completionHandler: @escaping GenericCompletionHandler<ModelUser>) {
        RemoteDataManager.retrieveUser(completionHandler)
    }

    static func registerVirtualNumber(_ phoneNumber: String, _ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        RemoteDataManager.registerVirtualNumber(phoneNumber, completionHandler)
    }

    static func verifyCallForward(_ callForwardNumber: String, _ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        RemoteDataManager.verifyCallForward(callForwardNumber, completionHandler)
    }

    static func verifyTokenAndPhone(callForwardNumber: String, token: String, _ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        RemoteDataManager.verifyTokenAndPhone(callForwardNumber: callForwardNumber, token: token, completionHandler)
    }
    
    static func userInfoSave(callForwardNumber:String,
                             deviceToken:String,
                             twilioNumber:String,
                             _ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        
        RemoteDataManager.userInfoSave(callForwardNumber: callForwardNumber,
                                       deviceToken: deviceToken,
                                       twilioNumber:twilioNumber,
                                       completionHandler)
    }
    
    static func saveProspectToClientWorks(with contactInfo: ContactInfo,
                                          _ completionHandler: @escaping GenericCompletionHandler<SaveProspectResponse>) {
      
        RemoteDataManager.saveProspectToClientWorks(with: contactInfo,
                                                    completionHandler)
    }
    
    static func save(note: Note,
                         _ completionHandler: @escaping GenericCompletionHandler<Int>) {
        
        RemoteDataManager.save(note: note, completionHandler)
    }
    
    static func fetchNotes(with clientID: String, pageNumber: Int, pageSize: Int, isAppOnly: Bool? = true, _ completionHandler: @escaping GenericCompletionHandler<[AdvisorNote]>) {
        
        RemoteDataManager.fetchNotes(with: clientID, pageNumber: pageNumber, pageSize: pageSize, isAppOnly: isAppOnly, completionHandler)
    }
    
    static func saveDisclaimer(_ isAccepted : Bool,
                               _ completionHandler: @escaping GenericCompletionHandler<SaveDisclaimerResponse>) {
        RemoteDataManager.saveDisclaimer(isAccepted, completionHandler)
    }
    
    // 💢 Dead Code
//    static func retreiveNumbers(city:String,
//                                state:String,
//                                _ completionHandler: @escaping GenericCompletionHandler<[RetrieveNumberResponse]>) {
//        RemoteDataManager.retreiveNumbers(city: city,
//                                          state: state,
//                                          completionHandler)
//    }
}
