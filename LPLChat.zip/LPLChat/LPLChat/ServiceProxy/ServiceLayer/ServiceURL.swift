//
//  ServiceURL.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/10/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//


struct ServiceURL {
    
    static let  userASATCheck        = "user/information/asat/check"
    static let  regSaveDisclaimer    = "disclaimer/save"                                    
    static let  checkRegistration    = "user/registration/status"
    static let  userRetrieve         = "user/information/retrieve"
    
    static let  verifyCallFwd        = "user/information/callfwd/verify"
    static let  verifyTokenAndPhone  = "user/information/callfwd/save"
    static let  userInfoSave         = "user/information/save"
    
    static let  regRetreiveNumbers   = "twilio/numbers/retrieve"
    static let  registerVirtualNumber = "user/information/twilionumber/save"
    
    static let  searchCity           = "User/Information/GetCity/"
    static let  getStateAreaCode     = "user/information/getstate/"

    static let  disclaimer           = "Information/GetConfig/Disclaimer"
    static let  termsOfUse           = "Information/GetConfig/termsofuse"
    static let  license              = "Information/GetConfig/Licenses"
    
    //Chat
    static let  msgGetAll            = "chat/all/1.3/"
    static let  msgGetMessages       = "message/"
    static let  msgPost              = "sendmessage/out"
    
    
    //Contacts
    static let contactsGet          = "shared-services/exp/client/detail/byrepid"
    static let saveProspect         = "user/information/prospects"
    static let clientsGet           = "user/information/contact"
    static let getProspects         = "advisor/prospects"

    
    //Notes
    static let saveNote = "user/information/addnotes"
    static let onlyAppNote = "user/information/app/notes"
    static let allNotes = "user/information/notes"
    
    static func getURLWith(serviceName: Service) -> String {
    
        var service = ""
        
        switch serviceName {
            
        case .disclaimer:
            service = disclaimer
            
        case .asat:
            service = userASATCheck
            
        case .registration:
            service = checkRegistration
            
        case .userRetrieve:
            service = userRetrieve
            
        case .verifyCallFwd:
            service = verifyCallFwd
            
        case .userInfoSave:
            service = userInfoSave
            
        case .retreiveNumbers:
            service = regRetreiveNumbers
            
        case .registerVirtualNumber:
            service = registerVirtualNumber
            
        case .termsOfUse:
            service = termsOfUse
            
        case .license:
            service = license
        
        case .msgGetAll:
            service = msgGetAll
        
        case .msgGetMessage:
            service = msgGetMessages
        
        case .searchCity:
            service = searchCity

        case .getStateAreaCode:
            service = getStateAreaCode

        case .contactsGet:
            service = contactsGet
        
        case .verifyTokenAndPhone:
            service = verifyTokenAndPhone
            
        case .saveDisclaimer:
            service = regSaveDisclaimer
         
        case .msgPost:
            service = msgPost
            
        case .saveProspect:
            service = saveProspect
            
        case .saveNote:
            service = saveNote
            
        case .onlyAppNotes:
            service = onlyAppNote
            
        case .allNotes:
            service = allNotes
        }
        
        return service
    }
    
}
