//
//  LPLServices.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/20/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

import Foundation

class LPLServicesRequest {
    let page: Page
    let search: Search
    let sort: Display
    let display: Display
    let listID: String
    
    init(page: Page, search: Search, sort: Display, display: Display, listID: String) {
        self.page = page
        self.search = search
        self.sort = sort
        self.display = display
        self.listID = listID
    }
}

class Display {
    let cols: String
    
    init(cols: String) {
        self.cols = cols
    }
}

class Page {
    let pn: Int
    let ps: String
    
    init(pn: Int, ps: String) {
        self.pn = pn
        self.ps = ps
    }
}

class Search {
    
    init() {
    }
}
