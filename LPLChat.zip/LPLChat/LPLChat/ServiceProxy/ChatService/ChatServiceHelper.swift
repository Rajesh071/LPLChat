//
//  ChatServiceHelper.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/11/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class ChatServiceHelper {
    
    static func findOwner(advisor advisorNumber:String, to toNumber:String?, from fromNumber: String?) -> MessageOwner {
        
        let advisorNumberActual = advisorNumber
        var owner : MessageOwner = .receiver
        let matchesToNumber = CustomUtility.comparePhone(ph1: toNumber, ph2: advisorNumberActual)
        
        if matchesToNumber{
            owner = .receiver
        }
        
        let matchesFromNumber = CustomUtility.comparePhone(ph1: fromNumber, ph2: advisorNumberActual)
        
        if matchesFromNumber{
            owner = .sender
        }
        return owner
    }
    
    static func getNumberValue (advisor advisorNumber:String, to toNumber:String?, from fromNumber:String?) -> String {
        
        let advisorNumberActual = advisorNumber
        var numberValue = ""
        let matchesToNumber = CustomUtility.comparePhone(ph1: toNumber, ph2: advisorNumberActual)
        
        if matchesToNumber {
            
        } else {
            numberValue = toNumber!
        }
        
        let matchesFromNumber = CustomUtility.comparePhone(ph1: fromNumber, ph2: advisorNumberActual)
        
        if matchesFromNumber {
            
        } else {
            numberValue = fromNumber!
        }
        return numberValue
    }
}
