//
//  GetChatByChatId.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireObjectMapper

public class GetChatByIdService {
  
    static func getChat_Dummy(chatIdOrPhoneNumber:String!, completionHandler : @escaping([DateMessage]?,ResponseStatus) -> Void) {
        //output
        let status = ResponseStatus(.success)
        let returnObj:[DateMessage]? = []
        
        return completionHandler(returnObj,status)
    }
    
    static func getChat(_ chatIdOrPhoneNumber:String!, completionHandler : @escaping([DateMessage]?,ResponseStatus) -> Void) {
                
        //url
        let phoneNumber_noFormat = CustomUtility.removeFormattingAndPlus(chatIdOrPhoneNumber)
        //
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.msgGetMessages + "\(phoneNumber_noFormat)/1/100"
        log.verbose(url)
        
        //output
        var status = ResponseStatus(.success)
        var returnObj:[DateMessage]? = []
        
//        var request = URLRequest.init(url: URL.init(string: url)!)
//        request.httpMethod = "GET"
//        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
//        request.allHTTPHeaderFields = RequestHelper.getHeaders()
//
//        let session = URLSession.shared
//        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
//            //print(response!)
//            do {
//
////                let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
//
//                let jsonRes: Any? = try JSONSerialization.jsonObject(with: data!)
//
//                if let json = jsonRes {
//
//                }
//
//
//
//            } catch {
//                print("error")
//            }
//        })
//        task.resume()
//

        Alamofire.request(url,  method:.get, headers: RequestHelper.getHeaders()).responseString(completionHandler: { (response: DataResponse<String>) in

            log.verbose(response)
         })

            Alamofire.request(url,  method:.get, headers: RequestHelper.getHeaders()).responseObject {
            (response: DataResponse<GetChatResponse>) in
            
            print("response WEB API = \(response)")
//            log.verbose(response)
            
            switch response.result {
            case .success:
                let responseObj = response.result.value
                if responseObj?.status == "success" {
                    returnObj = convertToDateMessageList(responseObj!.data!)
                    //returnObj = convertToMessageList(responseObj!.data!)
                }else {
                    status = ResponseStatus(.fail,(responseObj?.statusMessage)!)
                }
                break
            case .failure(let error):
                log.verbose(error)
                status = ResponseStatus(.fail,"Unknown Error. Please try again.")
            }
            
            return completionHandler(returnObj,status)
        }
        
        
    }
    
    static func convertToDateMessageList(_ svcListActual: [DateMessageItem]) -> [DateMessage]{
    
        var returnObj:[DateMessage] = []
        let svcList = svcListActual.reversed()
        
        for svcItem in svcList {
            var msgList:[Message] = []
            
            for svcItemMsg in svcItem.messages!{
                msgList.append(convertToMessage(svcItemMsg))
            }
            let sortedMsgList = msgList.sorted(by: { $0.timeDate < $1.timeDate })

            returnObj.append(DateMessage(date: svcItem.date, messages: sortedMsgList))
        }
        return returnObj
    }
    
    static func convertToMessageList (_ messageItemList:[MessageItem]) -> [Message] {
        var msgList : [Message] = []
        
        for msgItem in messageItemList{
            let msg = convertToMessage(msgItem)
            msgList.append(msg)
        }
        
        msgList = msgList.sorted(by: { $0.timeDate < $1.timeDate })

        return msgList
    }
    
    static func convertToMessage (_ msgItem:MessageItem) -> Message{
        /*
         
         {
         
         "messageId": "75d0fb59-c60c-4f12-a2f0-6211d9269e36",
         "messageDate": "2018-03-05T05:17:15.523",
         "messageBody": "LPLMessaging Receive Test - Investor to Advisor.",
         "messageToNumber": "+1 (858) 703-5772",
         "messageToName": "Advisor",
         "messageFromNumber": "+91 (967) 488-0074",
         "messageFromName": "Investor",
         "messageIsRead": false
         },
         
         or
         empty ToNumber
         
         {
         "messageId": "bd189fe8-bc58-48ce-804d-729eefe03834",
         "messageDate": "2018-03-05T09:47:48.243",
         "messageBody": "Hello! from postman 2 20 2018 8 50 pm",
         "messageToNumber": "",
         "messageToName": "+17049050118",
         "messageFromNumber": "+1 (123) 456-7890",
         "messageFromName": "vaishali.zachrich",
         "messageIsRead": false
         },
         
         */
        
        //owner
//        let user = Session.getUser()
//        let advisorNumber = user?.twilioNumber
        
//        let owner = ChatServiceHelper.findOwner(advisor: advisorNumber!, to: msgItem.messageToNumber, from: msgItem.messageFromNumber)

        var owner:MessageOwner = .sender
        if msgItem.messageType == "MESSAGE_IN" {
            owner = .receiver
        }
        
//        "messageType": "MESSAGE_IN",
//        "messageType": "MESSAGE_OUT",
        
        let msg = Message(type: .text,
                          content: msgItem.messageBody ?? "",
                          owner: owner,
                          timeStampStr: msgItem.messageDate!,
                          isRead: msgItem.messageIsRead!,
                           image: "",
                messageId: msgItem.messageID ?? ""
        )
        return msg
    }
}
