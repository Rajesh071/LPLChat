//
//  GetAllChat.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireObjectMapper

public class GetAllChatService {
    
         static func getAllChat(pageNo:String!, pageSize:String!, completionHandler : @escaping([SMSData]?,ResponseStatus) -> Void) {
            
            //url : https://webapidvi.dev.lpl.com/lplmessagingwebapi/chat/all/1/200
            var config = Configuration()
            let url = "\(config.environment.baseWebApiUrl + ServiceURL.msgGetAll)\(pageNo!)/\(pageSize!)"
            log.verbose(url)
            
            //output
            var status = ResponseStatus(.success)
            //var respon:[ChatData]?
            
            var returnObj:[SMSData]? = []
            
            if EnvOverrides.debugUseDummyData{
                log.verbose("== DEBUGOVERRIDE == debugUseDummyData")
                return completionHandler(returnObj,ResponseStatus(.success))
            }

            //Request
            Alamofire.request(url,  method:.get, headers: RequestHelper.getHeaders()).responseObject {
                (response: DataResponse<ChatAllResponse>) in
                
                print("get all chats: \(response)")
                //log.verbose(response)
                
                switch response.result {
                case .success:
                    let responseObj = response.result.value
                    if responseObj?.status == "success" {
                        let chatList:[ChatData] = responseObj!.data!
                       returnObj = convertToSMSData(chatList)
                    }else {
                        status = ResponseStatus(.fail,(responseObj?.statusMessage)!)
                    }
                    break
                case .failure(let error):
                    log.verbose(error)
                    status = ResponseStatus(.fail,"Unknown Error. Please try again.")
                }
                
                return completionHandler(returnObj,status)
            }
        
    }
    
    static func convertToSMSData(_ chatlist:[ChatData]) -> [SMSData] {
        
        var smsDataList : [SMSData] = []
        
        for chat in chatlist {
            let sms = convertChatDataToSMSData(chat)
            if sms.fromNumber.isEmpty || sms.toNumber.isEmpty {
                continue
            }
            if let foundSms = checkIfAlreadyAvailable (numberValue: sms.numberValue, smslist: smsDataList) {
                
                if foundSms.timeDate < sms.timeDate {
                    //already available - but at a newer date - replace with new one.
                    smsDataList = smsDataList.filter{$0.numberValue != foundSms.numberValue}
                    smsDataList.append(ModelHelper.copySMSData(sms: sms))
                }
            } else {
                smsDataList.append(sms)
            }
        }
        smsDataList = smsDataList.sorted(by: { $0.timeDate < $1.timeDate })

        return smsDataList
    }
    
    static func checkIfAlreadyAvailable(numberValue:String, smslist:[SMSData]) -> SMSData? {
        
        //var isFound:Bool = false
        var foundSms:SMSData?
        
        for item in smslist {
            if item.numberValue == numberValue {
                //isFound = true
                foundSms = item
                break
            }
        }
        
        return foundSms
    }
    
    static func convertChatDataToSMSData(_ chat:ChatData) -> SMSData {
        
        /*
         {
         "chatId": "0b19bf81-72cb-46b4-a3f4-bc3e263323c9",
         "fromNumber": "+1 (858) 703-5772",
         "toNumber": "",
         "toName": "12404634944",
         "time": "2018-03-06T11:36:02.613",
         "body": "Hi 236",
         "totalUnread": 43
         }
         
         {
         "chatId": "0b19bf81-72cb-46b4-a3f4-bc3e263323c9",
         "fromNumber": "+1 (858) 703-5772",
         "toNumber": "",
         "toName": "12404634944",
         "time": "2018-03-06T11:36:02.613",
         "body": "Hi 236",
         "totalUnread": 43
         }
         
         */
        
        
        let user = Session.getUser()
       let advisorNumber = user?.twilioNumber ?? AppStateData.shared.virtualNumber
        
        //Date
        let dateStr = chat.time
        let date = dateStr?.convertToDate()
        let dateDisplay = date?.ConvertDateToReadableString()
        
        let numberValue = ChatServiceHelper.getNumberValue(advisor: advisorNumber!,
                                                           to: chat.toNumber, from: chat.fromNumber)
        
        let owner = ChatServiceHelper.findOwner(advisor: advisorNumber!,
                                                to: chat.toNumber, from: chat.fromNumber)

        return SMSData(
            imageName: "",
            nameValue: ContactUtility.mapName(to: numberValue),
            description: chat.body!,
            time: dateDisplay!,
            badgeValue: 0,
            owner: owner,
            numberValue: numberValue,
            timeDate: date!,
            
            fromNumber:chat.fromNumber!,
            toNumber:chat.toNumber!,
            totalUnread: chat.totalUnread!
        );
    }
}
