//
//  GetAllChatResponse.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import AlamofireObjectMapper
import ObjectMapper

 class ChatAllResponse : Mappable,CustomDebugStringConvertible {
    var status: String?
    var statusMessage: String?
    var data: [ChatData]?
    
    required init?(map: Map){
    }
    
    init(status: String?, statusMessage: String?, data: [ChatData]?) {
        self.status = status
        self.statusMessage = statusMessage
        self.data = data
    }
    
    func mapping(map: Map) {
        status <- map["status"]
        statusMessage <- map["statusMessage"]
        data <- map["data"]
    }
    
    var debugDescription: String {
        return String("Status: \(status ?? "BLANK STATUS"). Message: \(statusMessage ?? "") Data: \(String(describing: data))")
    }
}

 class ChatData : Mappable, CustomDebugStringConvertible {
    var chatID: String?
    var fromNumber: String?
    var toNumber: String?
    var toName: String?
    var time: String?
    var body: String?
    var totalUnread: Int?
    
    required init?(map: Map){
    }
    
    init(chatID: String?, fromNumber: String?, toNumber: String?, toName: String?, time: String?, body: String?, totalUnread: Int?) {
        self.chatID = chatID
        self.fromNumber = fromNumber
        self.toNumber = toNumber
        self.toName = toName
        self.time = time
        self.body = body
        self.totalUnread = totalUnread
    }
    
    func mapping(map: Map) {
        chatID <- map["chatID"]
        fromNumber <- map["fromNumber"]
        toNumber <- map["toNumber"]
        toName <- map["toName"]
        time <- map["time"]
        body <- map["body"]
        totalUnread <- map["totalUnread"]
    }
    
    var debugDescription: String {
        return String("from: \(String(describing: fromNumber)). to: \(String(describing: toNumber)) time: \(String(describing: time))")
    }
}
