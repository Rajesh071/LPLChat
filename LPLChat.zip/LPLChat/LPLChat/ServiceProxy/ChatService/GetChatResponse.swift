//
//  GetChatResponse.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import AlamofireObjectMapper
import ObjectMapper


class GetChatResponse : Mappable,CustomDebugStringConvertible {
    var status: String?
    var statusMessage: String?
    var data: [DateMessageItem]?
    
    required init?(map: Map){
    }
    
    init(status: String?, statusMessage: String?, data: [DateMessageItem]?) {
        self.status = status
        self.statusMessage = statusMessage
        self.data = data
    }
    
    func mapping(map: Map) {
        status <- map["status"]
        statusMessage <- map["statusMessage"]
        data <- map["data"]
    }
    
    var debugDescription: String {
        return String("Status: \(String(describing: status)). Message: \(String(describing: statusMessage)) Data: \(String(describing: data))")
    }
}

class DateMessageItem : Mappable, CustomDebugStringConvertible{
    
    var date: String?
    var messages: [MessageItem]?
    
    required init?(map: Map) {
    }
    
    init(date:String?, messages:[MessageItem]?) {
        self.date = date
        self.messages = messages
    }
    
    func mapping(map: Map) {
        date <- map["Date"]
        messages <- map["Message"]
    }
    
    var debugDescription: String {
        return String("date: \(String(describing: date)). messages.count: \(String(describing: messages?.count))")
    }
}

class MessageItem : Mappable {
    var messageType: String?
    var messageID: String?
    var messageLinkID: NSNull?
    var messageDate: String?
    var messageBody: String?
    var messageToNumber: String?
    var messageToName: String?
    var messageFromNumber: String?
    var messageFromName: String?
    var messageFromCity: NSNull?
    var messageFromState: NSNull?
    var messageFromCountry: NSNull?
    var messageFromZip: NSNull?
    var messageIsRead: Bool?
    
    required init?(map: Map) {
    }
    
    init(messageType: String?, messageID: String?, messageLinkID: NSNull?, messageDate: String?,
         messageBody: String?, messageToNumber: String?, messageToName: String?, messageFromNumber: String?,
         messageFromName: String?, messageFromCity: NSNull?, messageFromState: NSNull?,
         messageFromCountry: NSNull?, messageFromZip: NSNull?, messageIsRead: Bool?) {
        
        self.messageType = messageType
        self.messageID = messageID
        self.messageLinkID = messageLinkID
        
        self.messageDate = messageDate
        self.messageBody = messageBody
        self.messageToNumber = messageToNumber
        
        self.messageToName = messageToName
        self.messageFromNumber = messageFromNumber
        self.messageFromName = messageFromName
        
        self.messageFromCity = messageFromCity
        self.messageFromState = messageFromState
        self.messageFromCountry = messageFromCountry
        
        self.messageFromZip = messageFromZip
        self.messageIsRead = messageIsRead
    }
    
    func mapping(map: Map) {
        messageType <- map["messageType"]
        messageID <- map["messageID"]
        messageLinkID <- map["messageLinkID"]
        
        messageDate <- map["messageDate"]
        messageBody <- map["messageBody"]
        messageToNumber <- map["messageToNumber"]
        
        messageToName <- map["messageToName"]
        messageFromNumber <- map["messageFromNumber"]
        messageFromName <- map["messageFromName"]
        
        messageFromCity <- map["messageFromCity"]
        messageFromState <- map["messageFromState"]
        messageFromCountry <- map["messageFromCountry"]
        
        messageFromZip <- map["messageFromZip"]
        messageIsRead <- map["messageIsRead"]
    }
    
    var debugDescription: String {
        return String("from: \(String(describing: messageFromNumber)). to: \(String(describing: messageToNumber)) Date: \(String(describing: messageDate))")
    }
}
