//
//  SendMessageService.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire

class SendMessageService {
    
    
    static func sendSMSLPL (sendRequest:SendRequest , internalMsgId:String,
                            completionHandler: @escaping (String,ResponseStatus,String) -> Void) {

        //url
        var config = Configuration()
        let UrlMessageSend =  config.environment.baseSharedServicesUrl + "sendmessage/out"

        //output
        var status: ResponseStatus = ResponseStatus(.success)
        let serverMsgId :String = ""

        //input
        let number = Session.getUser()?.twilioNumber!

        let params: Parameters = [
            // remove formatting add +1

            "fromNumber": CustomUtility.removeFormatting(number!),
            //regUser?.twilioNumber
            //"fromName" : regUser?.data.fullname ?? "Advisor",
            "fromName" : "Advisor",
            "messageText":sendRequest.messageBody.trim(),
            "receiverContactList":[["toNumber":CustomUtility.removeFormatting(sendRequest.messageToNumber)]]
        ]
        
        print("Sam Params =>>>>> \(params)")
        
        Alamofire.request(UrlMessageSend, method: .post, parameters :params,encoding:JSONEncoding.default,
                        headers:RequestHelper.getHeaders() ).logRequest()
            .responseString { response in
                log.verbose(response)
                if response.result.isSuccess {

                    /* todo avi: map sendmessage response
                    if dr.status == "success"

                    */

                } else {

                    print("Error: \(String(describing: response.result.error))")
                    status = ResponseStatus(.fail, "Please try again.")
                }
                print("\(status.statusType)")

                return completionHandler(serverMsgId,status,internalMsgId)
        }
    }
}
