//
//  ServiceProxy.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/20/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON


class ServiceProxy : NSObject {

    static let baseLPLServicesUrl =  "https://clientworksdevint.lpl.com/ieCors/"


    private static func getMockNumbers()-> [String:String]{

        var localMap = [String: String]()
        localMap["+16175042850"] = "Anthony Perkins"
        localMap["+19176807102"] = "Sumesh Madisetti"
        localMap["+19802288034"] = "Rajesh Sharma"
        localMap["+17045939367"] = "Avinash Rajendran"
        localMap["+1"] = "Abhishek Sharma"
        localMap["+14802975219"] = "Avra Bannerjee"
        return localMap
    }

    private static func numberToNameMapping(_ number:String)->String{
        var map = getMockNumbers()
        if let name = map[number]{
            return name
        }
        else{
            return number
        }
    }

    public static func sendSMS (sendRequest:SendRequest , completionHandler: @escaping (ResponseStatus) -> Void) {

        //sendToFireBase(sendRequest:sendRequest)
        var status: ResponseStatus = ResponseStatus(.Success)

        //LPL - internal -only Twilio
//        let UrlMessageSend = "http://10.29.137.99:12123/2010-04-01/Accounts/AC337e6d01a70774fc5fe69ad681b26b3b/Messages.json"
//
//        let params: Parameters = [
//            "To": sendRequest.messageToNumber,
//            "Body":sendRequest.messageBody,
//            "From":"+18587035772", //Twilio number - temp for demo.
//        ]

        //Azure - firebase + twilio
        let UrlMessageSend = "https://lplmessaging.azurewebsites.net/Sms/SendSms"
        let params: Parameters = [
            "messageToNumber": sendRequest.messageToNumber,
            "messageBody": sendRequest.messageBody
        ]
        print(UrlMessageSend)

        Alamofire.request(UrlMessageSend, method: .post, parameters :params,encoding:JSONEncoding.default )
            .responseJSON { response in
                if response.result.isSuccess {
                    
                } else {
                    print("Error: \(String(describing: response.result.error))")
                    status = ResponseStatus(.Fail, "Please try again.")
                }
                print("\(status.StatusType)")
                return completionHandler(status)
        }
    }

    public static func getAllChat(completionHandler: @escaping ([SMSData]?, ResponseStatus) -> Void) {
        
        var smsUniqArray : [SMSData] = []
        
        getAllSMSFromService { (allSms, responseStatus) in
            
            //Get uniq items - to display in ChatList Page
            if responseStatus.StatusType == .Success{
                smsUniqArray = getUniqChat(smsArray:allSms!)
            }
            
            return completionHandler(smsUniqArray,responseStatus)
        }
    }
    
    public static func getChatForContact (tonumber:String,completionHandler: @escaping ([Message]?, ResponseStatus) -> Void) {
     
        var messageArrayForContact : [Message] = []
        
        getAllSMSFromService { (allSms, responseStatus) in
            
            //Get uniq items - to display in ChatList Page
            if responseStatus.StatusType == .Success{
                messageArrayForContact = filter(tonumber: tonumber, smsArray:allSms!)
            }
            
            return completionHandler(messageArrayForContact,responseStatus)
        }
    }
    
    private static func getAllSMSFromService(completionHandler: @escaping ([SMSData]?, ResponseStatus) -> Void) {
        
        var allSms : [SMSData] = []
        var status : ResponseStatus = ResponseStatus(.Success)
        let UrlMessageGet =  "https://lplmessaging.azurewebsites.net/Sms/GetSms?page=1&count=1"
        
        print(UrlMessageGet)
        
        Alamofire.request(UrlMessageGet, method: .get)
            .responseJSON { response in
                if response.result.isSuccess {
                    
                    let msgListJson = JSON(response.result.value!)
                    for (_, dict) in msgListJson {
                        allSms.append(ConvertJsonToSMSData(json:dict))
                        //allSms.append(SMSData(imageName: "customer1", nameValue: dict["messageToNumber"].stringValue, description: dict["messageBody"].stringValue, time: "", badgeValue: 1));
                    }
                } else {
                    print("Error: \(String(describing: response.result.error))")
                    status = ResponseStatus(.Fail,"Please try again.")
                }
                print(" \(status.StatusType)")
                return completionHandler(allSms,status)
        }
    }



    public static func checkRegistration(completionHandler : @escaping(ResponseStatus) -> Void) {

        var status: ResponseStatus = ResponseStatus(.Success)

        let urlUserInfo = baseLPLServicesUrl + "UserService/UserInfo"

        Alamofire.request(urlUserInfo, method: .get)
                .response { (r) in
                    //if it is redirecting to Login - implies that session is not valid.
                    if r.response?.url?.host == "logindevint.lpl.com" {
                        status = ResponseStatus(.SessionInvalid)
                        return completionHandler(status)
                    }
                    return completionHandler(status)
                }
    }


    private static func filter (tonumber:String, smsArray:[SMSData]) -> [Message] {

        var msgArray : [Message] = []
        for sms in smsArray {
            if sms.numberValue == tonumber {
                msgArray.append(ConvertToMessage(sms))
            }
        }
        return msgArray
    }

    private static func ConvertToMessage ( _ sms:SMSData) -> Message{
        let msg = Message(type: .text,
                content: sms.description,
                owner: sms.owner,
                timestamp: "12:40 PM", isRead: true, image: "customer1")
        return msg
    }

    private static func ConvertJsonToSMSData (json:JSON ) -> SMSData {

        var advisorNumber = "+17048102223"

        //ToNumber
        var toNumberValue = json["messageToNumber"].stringValue

        if toNumberValue == advisorNumber  {
            toNumberValue = json["messageFromNumber"].stringValue
        }

        //Sender/Receiver
        var owner : MessageOwner = .receiver
        var messageTypeValue = json["messageType"].stringValue

        if messageTypeValue == "SMS_OUT" {
            owner = .sender
        }

        //Date
        var dateStr = json["messageDate"].stringValue
        var date = ConvertStrToDate(dateStr: dateStr)
        var dateDisplay = ConvertDateToReadableString(date: date)

        return SMSData(
                imageName: "customer1",
                nameValue: numberToNameMapping(toNumberValue),
                description: json["messageBody"].stringValue,
                time: dateDisplay,
                badgeValue: 1,
                owner: owner,
                numberValue: toNumberValue,
                timeDate: date
        );
    }

    private static func getUniqChat (smsArray:[SMSData]) -> [SMSData] {

        var uniqChatArray : [SMSData] = []

        for sms in smsArray{

            var found = false
            for uniqChat in uniqChatArray {
                if uniqChat.numberValue == sms.numberValue{
                    found = true //already in uniqChatArray
                    break
                }else{
                    found = false
                }
            } //foreach checking uniq

            if found == true {
                //Todo update last message information - based on time.
                continue //go to next item
            }

            if found == false {
                uniqChatArray.append(sms)
            }

        } // end of smsArray foreach
        return uniqChatArray
    }

    private static func ConvertStrToDate(dateStr:String ) -> Date {
        //var dateStr = "2018-02-16T10:01:07.0618583Z"

        let formatter = ISO8601DateFormatter()

        formatter.formatOptions = [.withFullDate,
                                   .withTime,
                                   .withDashSeparatorInDate,
                                   .withColonSeparatorInTime]

        formatter.timeZone = TimeZone(secondsFromGMT: 0)


        let date = formatter.date(from: dateStr)

        return date!
    }

    private static func ConvertDateToReadableString (date:Date) -> String {
        //apply logic - date, yesterday , time, etc...
        return date.description
    }

  //  private static func sendToFireBase (sendRequest: SendRequest) {
//        let UrlMessageSend = "https://lplmessaging.azurewebsites.net/Sms/SendSms"
//        let params: Parameters = [
//            "messageToNumber": sendRequest.messageToNumber,
//            "messageBody": sendRequest.messageBody
//        ]
//
//        Alamofire.request(UrlMessageSend, method: .post, parameters: params, encoding: JSONEncoding.default)
//                .responseJSON { response in
//                    if response.result.isSuccess {
//
//                    } else {
//                        print("Error: \(String(describing: response.result.error))")
//                        status = ResponseStatus(.Fail, "Please try again.")
//                    }
//                    print("\(status.StatusType)")
//                    //return completionHandler(status)
//                }
//    }
}
