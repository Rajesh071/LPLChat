//
//  DataStore.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/1/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class Session {
    
    static var user: UserRegStatusData?
    static var contacts: [Contacts] = []
    static var propects: [Prospect] = []
    static var unreadMessagesInTheApp = 0
    
    static func updateUser(twilioNumber:String, callFwdNumber:String) {
        AppStateData.shared.virtualNumber = twilioNumber
        Session.user?.twilioNumber = twilioNumber
        Session.user?.callForwardNumber = callFwdNumber
        Session.user?.isRegistered = true
    }
    
    static func saveUser(_ user:UserRegStatusData?){
        Session.user = user
        AppStateData.shared.virtualNumber = self.getUser()?.twilioNumber
    }

    static func getUser() -> UserRegStatusData? {
        //user?.twilioNumber = user?.twilioNumber
        return user
    }
        
    static func saveCwContacts(contacts:[Contacts]){
        Session.contacts = contacts
    }
    
    static func clear(){
        Session.contacts = []
        Session.user = nil
        CookieUtility.clearCookies()
    }
    
    static func getAdvisorVirtualNumber() -> String {
        let virtualNumber = AppStateData.shared.virtualNumber!
        return virtualNumber
    }
    
    static func getAdvisorCallFwdNumber() -> String {
        
        //send from session
        return "+17045939367"
    }
}
