//
//  ServiceProxy.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/20/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON


class MessageService : NSObject {
    
    //temp until registration is completed.
    static let  advisorNumber = "+17048102223"
   
    
    public static func getChatForContact (tonumber:String,completionHandler: @escaping ([DateMessage]?, ResponseStatus) -> Void) {
        
        GetChatByIdService.getChat(tonumber, completionHandler: { (msgList, status) in
            return completionHandler(msgList,status)
        })
//
//        if EnvConstants.useTempAzure == false {
//            GetChatByIdService.getChat(chatIdOrPhoneNumber: tonumber, completionHandler: { (msgList, status) in
//                 return completionHandler(msgList,status)
//            })
//
//        } else {
//
//            var messageArrayForContact : [Message] = []
//
//            getAllSMSFromService_TempAzure { (allSms, responseStatus) in
//
//                //Get uniq items - to display in ChatList Page
//                if responseStatus.statusType == .success{
//                    messageArrayForContact = ModelHelper.filter(tonumber: tonumber, smsArray:allSms!)
//                }
//
//                return completionHandler(messageArrayForContact,responseStatus)
//            }
//        }
    }
    
    private static func getAllSMSFromService_TempAzure(completionHandler: @escaping ([SMSData]?, ResponseStatus) -> Void) {
        
        var allSms : [SMSData] = []
        var status : ResponseStatus = ResponseStatus(.success)
        let UrlMessageGet =  "https://lplmessaging.azurewebsites.net/Sms/GetSms?page=1&count=1"
        
        print(UrlMessageGet)
        
        Alamofire.request(UrlMessageGet, method: .get)
            .responseJSON { response in
                if response.result.isSuccess {
                    
                    let msgListJson = JSON(response.result.value!)
                    for (_, dict) in msgListJson {
                        allSms.append(ModelTransformer.ConvertJsonToSMSData(json:dict))
                        //allSms.append(SMSData(imageName: "customer1", nameValue: dict["messageToNumber"].stringValue, description: dict["messageBody"].stringValue, time: "", badgeValue: 1));
                    }
                } else {
                    print("Error: \(String(describing: response.result.error))")
                    status = ResponseStatus(.fail,"Please try again.")
                }
                print(" \(status.statusType)")
                return completionHandler(allSms,status)
        }
    }
}
