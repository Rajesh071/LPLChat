//
//  RawTextService.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/27/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

//
//enum ServiceType: String {
//    case disclaimer = "Disclaimer"
//    case termsOfUse = "TermsOfUse"
//    case license = "License"
//    case defaulty = "Default"
//}

typealias CompletionHandler = (String) -> Void

class RawTextService: NSObject {
    
    class func retriveRawDataFor(serviceType: Service,
                                 completionHandler: @escaping CompletionHandler) {
        
        var urlString = ""
        var config = Configuration()
        switch serviceType.rawValue {
        case ServiceType.disclaimer.rawValue:
            urlString = config.environment.baseWebApiUrl + ServiceURL.disclaimer
        case ServiceType.termsOfUse.rawValue:
            urlString = config.environment.baseWebApiUrl + ServiceURL.termsOfUse
        default:
            urlString = config.environment.baseWebApiUrl + ServiceURL.license
        }
        
        let serviceUrl = URL.init(string: urlString)
        
        var request = URLRequest.init(url: serviceUrl!)
        
        request.httpMethod = "GET" //HTTPMethodType.get.rawValue
        
        request.setValue("Application/json",
                         forHTTPHeaderField: "Content-Type")
    
        request.allHTTPHeaderFields = RequestHelper.getHeaders()
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            if let response = response {
                print("json response for twillio registration = ", response)
            }
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String: Any]
                    
                    let data = json["data"] as! [String:String]
                    
                        //TODO: - This should be the text returned by WEB-API
                        DispatchQueue.main.async {
                            completionHandler(data["ConfigValue"]!)
                        }
                } catch {
                    print(error)
                    completionHandler("Failure to fetch the \(serviceType.rawValue)")
                }
            }
            }.resume()
    }
    
}
