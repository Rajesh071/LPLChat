//
//  ModelTransformer.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/28/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import SwiftyJSON

//Json to obj conversion
class ModelTransformer {
    
//     static func ConvertJsonToSMSData (json:JSON ) -> SMSData {
//        
//        let advisorNumber = Session.getAdvisorVirtualNumber()
//        
//        //ToNumber
//        var toNumberValue = json["messageToNumber"].stringValue
//        
//        if toNumberValue == advisorNumber  {
//            toNumberValue = json["messageFromNumber"].stringValue
//        }
//        
//        //Sender/Receiver
//        var owner : MessageOwner = .receiver
//        let messageTypeValue = json["messageType"].stringValue
//        
//        if messageTypeValue == "SMS_OUT" {
//            owner = .sender
//        }
//        
//        //Date
//        let dateStr = json["messageDate"].stringValue
//        let date = dateStr.convertToDate()
//        let dateDisplay = date.ConvertDateToReadableString()
//        
//        return SMSData(
//            imageName: "",
//            nameValue: ModelHelper.numberToNameMapping(toNumberValue),
//            description: json["messageBody"].stringValue,
//            time: dateDisplay,
//            badgeValue: 0,
//            owner: owner,
//            numberValue: toNumberValue,
//            timeDate: date,
//            
//            fromNumber:json["messageFromNumber"].stringValue,
//            toNumber:json["messageToNumber"].stringValue
//        );
//    }
    
    static func convertNewServiceJsonToLPLContact(_ json:JSON ) -> Contacts {
        
        let name = "\(json["firstName"].stringValue) \(json["lastName"].stringValue)"
        let contact:Contacts = Contacts(imageName:"",
                                        nameValue: name,
                                        amountValue: json["marketValue"].numberValue,
                                        variationValue: json["unrealizedGainLoss"].numberValue,
                                        unreadCount: 0,
                                        isNew : false,
                                        isFav: false,
                                        badgeValue : 2,
                                        phoneNumber : json["homePhone"].stringValue,
                                        asOfDateStr:json["asOfDate"].stringValue,
                                        mobilePhone: json["mobilePhone"].stringValue,
                                        businessPhone: json["businessPhone"].stringValue,
                                        firstName: json["firstName"].stringValue,
                                        lastName: json["lastName"].stringValue,
                                        clientID: json["clientID"].stringValue)
        
        contact.profile = ConvertNewServiceJsonToProfile(json)
        
        return contact
        
        /*
         
         {
         "clientID": 13558744,
         "firstName": "Test",
         "lastName": "Account",
         "homePhone": "1251523553",
         "businessPhone": "3241560560",
         "mobilePhone": null,
         "email": "ASDF@SADF.COM",
         "mailingAddressLine1": "123 TEST LANE",
         "mailingAddressLine2": "SAN DIEGO CA 92121",
         "mailingAddressLine3": " ",
         "mailingCity": "SAN DIEGO",
         "mailingState": "CA",
         "mailingZipCode": "92121",
         "marketValue": 172790.63,
         "unrealizedGainLoss": 0
         },
         
         */
    }
    
    static func ConvertNewServiceJsonToProfile(_ json:JSON ) -> Profile {
        
        let name = "\(json["firstName"].stringValue) \(json["lastName"].stringValue)"
        
        var phoneNumbers : [PhoneNumber] = []

        if let workPhone = json["businessPhone"].string   , !workPhone.isEmpty {
            phoneNumbers.append(PhoneNumber(displayValue:workPhone,
                                            label:"work",
                                            isFav:false))
        }
        
        if let homePhone = json["homePhone"].string , !homePhone.isEmpty {
            phoneNumbers.append(PhoneNumber(displayValue:homePhone,
                                            label:"home",
                                            isFav:false))
        }
        
        if let mobilePhone = json["mobilePhone"].string , !mobilePhone.isEmpty {
            phoneNumbers.append(PhoneNumber(displayValue:mobilePhone,
                                            label:"mobile",
                                            isFav:false))
        }
        
        
        var emails : [Email] = []
        if let email = json["email"].string , !email.isEmpty {
            emails.append(Email(value:email,label:"email"))
        }
        
        var addresses : [Address] = []
        addresses.append(Address(label: "address",
                                 line1: json["mailingAddressLine1"].stringValue,
                                 line2: json["mailingAddressLine2"].stringValue,
                                 line3: json["mailingAddressLine3"].stringValue,
                                 city: json["mailingCity"].stringValue,
                                 state: json["mailingState"].stringValue,
                                 zipCode:json["mailingZipCode"].stringValue))
        
        let asOfDateStr = json["asOfDate"].stringValue
        
        return Profile(name:name,phoneNumbers: phoneNumbers,emails:emails,addresses:addresses, birthday: nil, anniversary: nil, amountValue: 0, variationValue: 0, asOfDateStr:asOfDateStr)
        
    }
    
//    static func ConvertJsonToProfile(_ json:JSON ) -> Profile {
//        
//        let name = "\(json["firstName"].stringValue) \(json["lastName"].stringValue)"
//        
//        var phoneNumbers : [PhoneNumber] = []
//        
//        if let mobilePhone = json["mobilePhone"].string  , !mobilePhone.isEmpty {
//            phoneNumbers.append(PhoneNumber(displayValue:mobilePhone,label:"mobile",isFav:false))
//        }
//        
//        if let workPhone = json["workPhone"].string   , !workPhone.isEmpty {
//            phoneNumbers.append(PhoneNumber(displayValue:workPhone,label:"work",isFav:false))
//        }
//        
//        if let homePhone = json["homePhone"].string , !homePhone.isEmpty {
//            phoneNumbers.append(PhoneNumber(displayValue:homePhone,label:"home",isFav:false))
//        }
//        
//        
//        var emails : [Email] = []
//        if let email = json["emailAddress"].string , !email.isEmpty {
//            emails.append(Email(value:email,label:"email"))
//        }
//        
//        var addresses : [Address] = []
//        addresses.append(Address(label: "residence",
//                                 line1: json["residenceAddressLine1"].stringValue,
//                                 line2: json["residenceAddressLine2"].stringValue,
//                                 city: json["residenceCity"].stringValue,
//                                 state: json["state"].stringValue,
//                                 zipCode:json["residencePostalCode"].stringValue))
//        
//        if isValidAddress(json: json, type: "mailing"){
//            
//            
//            
//            addresses.append(Address(label: "mail",
//                                     line1: json["mailingAddressLine1"].stringValue,
//                                     line2: json["mailingAddressLine2"].stringValue,
//                                     city: json["mailingCity"].stringValue,
//                                     state: json["mailingState"].stringValue,
//                                     zipCode:json["mailingPostalCode"].stringValue))
//        }
//        if isValidAddress(json: json, type: "employer"){
//            
//            addresses.append(Address(label: "employer",
//                                     line1: json["employerAddressLine1"].stringValue,
//                                     line2: json["employerAddressLine2"].stringValue,
//                                     city: json["employerCity"].stringValue,
//                                     state: json["employerState"].stringValue,
//                                     zipCode:json["employerPostalCode"].stringValue))
//            
//        }
//        
//        
//        return Profile(name:name,phoneNumbers: phoneNumbers,emails:emails,addresses:addresses, amountValue: 0, variationValue: 0)
//        
//    }
    
    private static func isValidAddress(json:JSON , type:String) -> Bool{
        
        if let line1 = json[type+"AddressLine1"].string , line1.isEmpty {
            return false
        }
        
        if let city = json[type+"City"].string , city.isEmpty {
            return false
        }
        
        if let state = json[type+"State"].string , state.isEmpty {
            return false
        }
        
        return true
    }
    
//    static func convertJsonToLPLContact(_ json:JSON ) -> Contacts {
//
//        //        Contacts(imageName: "customer1", nameValue: "Richard Bacon", amountValue: "$4,111,234", variationValue: 3232, unreadCount: 0, isNew : false, isFav: true, badgeValue : 2, phoneNumber : "980980989"),
//        //
//
//        let name = "\(json["firstName"].stringValue) \(json["lastName"].stringValue)"
//        let contact:Contacts = Contacts(imageName:"",nameValue: name,
//                                        amountValue: 411234, variationValue: 3232, unreadCount: 0, isNew : false, isFav: false, badgeValue : 2, phoneNumber : json["mobilePhone"].stringValue)
//
//        contact.profile = ConvertJsonToProfile(json)
//
//        return contact
//
//        /*
//
//         "data": {
//         "records": [
//         {
//         "dynamicsProspectFullName": "Cran Isafruit Berry",
//         "firstName": "Cran",
//         "middleName": "Isafruit",
//         "lastName": "Berry",
//         "email": "CranIBerry@aol.com",
//         "description": "",
//         "addressLine1": null,
//         "addressLine2": null,
//         "city": "Ocean Spray",
//         "state": "DE",
//         "zipCode": "44423",
//         "birthDate": "1971-10-13T00:00:00",
//         "employer": "LPL",
//         "employmentStatus": 0,
//         "mobilePhone": "(294) 937-7402",
//         "homePhone": "(294) 221-1497",
//         "workPhone": "(334) 422-1242",
//         "addressType": 0,
//         "emailAddress": "CranIBerry@aol.com",
//         "mailingAddress": null,
//         "residentialAddress": null,
//         "AddressList": null,
//         "isProspect": false,
//         "repId": "",
//         "contactType": 0,
//         "residencyStatuses": "U.S. Citizen/Entity with a U.S. Address",
//         "residencyStatusessCode": "923980000",
//         "residenceAddressLine1": "100 Cranberry Lane",
//         "residenceAddressLine2": "Tree #274",
//         "residenceAddressLine3": "Root address",
//         "residenceCountry": null,
//         "residenceCity": "Ocean Spray",
//         "residencePostalCode": "44423",
//         "mailingAddressLine1": "",
//         "mailingAddressLine2": "",
//         "mailingAddressLine3": "",
//         "mailingCountry": null,
//         "mailingCity": "",
//         "mailingState": "",
//         "mailingisforeign": false,
//         "mailingPostalCode": "",
//         "employerRetired": false,
//         "employerName": "LPL",
//         "employerAddressLine1": "Address Line 1",
//         "employerAddressLine2": "Address Line 2",
//         "employerAddressLine3": null,
//         "employerCountry": "",
//         "employerState": "State",
//         "employerCity": "",
//         "employerPostalCode": "Zip Code",
//         "fax": "948822247",
//         "gender": "Male",
//         "genderCode": "1",
//         "maritalStatus": "Married",
//         "maritalStatusCode": "2",
//         "spouseFirstName": "Francis",
//         "spouseMiddleName": "Weatherby",
//         "spouseLastName": "McDormand",
//         "spouseGender": "--",
//         "spouseGenderCode": 0,
//         "spouseSsnTaxId": "334441124",
//         "spouseDateOfBirth": "",
//         "isSSN": true,
//         "ssnTaxId": "665520574",
//         "dateOfBirth": "1971-10-13T00:00:00",
//         "noOfDependents": 1,
//         "citizenship": "",
//         "govtIdType": null,
//         "govtIdTypeCode": null,
//         "govtIdPlaceOfIssuance": null,
//         "govtId": null,
//         "govtIdIssuanceDate": null,
//         "govtIdExpDate": null,
//         "sameMailInd": false,
//         "employerIndustry": null,
//         "accountId": "",
//         "clientId": "",
//         "createdDate": "2018-01-05T18:02:52",
//         "createdBy": "52c8700b-65c6-e711-8113-c4346bdcd1f1",
//         "createdByGuid": "00000000-0000-0000-0000-000000000000",
//         "id": "99306ba0-42f2-e711-8110-c4346bdc92c1",
//         "sourceType": null,
//         "repName": null,
//         "clientName": null,
//         "accountName": null,
//         "modifiedBy": null,
//         "modifiedDate": null,
//         "logicalName": null
//         },
//
//         */
//    }
}
