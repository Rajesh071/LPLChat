//
//  ModelHelper.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/27/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import AddressBook
import Contacts

class ModelHelper {
    
//    public static func CreateSMSData (notiMsg:LPLNotificationMessage) -> SMSData{
//        
//        let date = Date()
//        let dateStr:String = date.toISO8601String()
//        
//        return SMSData(
//            imageName: "",
//            nameValue: ContactUtility.mapName(to: notiMsg.fromNo),
//            description: notiMsg.msg,
//            time: dateStr,
//            badgeValue: 0,
//            owner: .receiver,
//            numberValue: Session.getAdvisorVirtualNumber(),//to the advisor
//            timeDate: date,
//            fromNumber:notiMsg.fromNo,
//            toNumber:Session.getAdvisorVirtualNumber(),
//            totalUnread: 0
//        )
//    }
    
    static func ConvertToMessage ( _ sms:SMSData) -> Message{
        let msg = Message(type: .text,
                          content: sms.description,
                          owner: sms.owner,
                          timeAsDate:sms.timeDate, isRead: true, image: "customer1")
        return msg
    }
    
    static func filter (tonumber:String, smsArray:[SMSData]) -> [Message] {
        
        var msgArray : [Message] = []
        for sms in smsArray {
            if sms.numberValue == tonumber {
                msgArray.append(ConvertToMessage(sms))
            }
        }
        return msgArray
    }
    
    static func copySMSData(sms:SMSData) -> SMSData {
        return SMSData(imageName: sms.imageName, nameValue: sms.nameValue, description: sms.description, time: sms.time, badgeValue: sms.badgeValue, owner: sms.owner, numberValue: sms.numberValue, timeDate: sms.timeDate,fromNumber:sms.fromNumber,toNumber:sms.toNumber, totalUnread: sms.totalUnread)
    }
    
    static func getUniqChat (smsArray:[SMSData]) -> [SMSData] {
        
        var uniqChatArray : [SMSData] = []
        
        for sms in smsArray{
            
            var found = false
            var foundValue : SMSData!
            for uniqChat in uniqChatArray {
                if uniqChat.numberValue == sms.numberValue{
                    found = true //already in uniqChatArray
                    foundValue = uniqChat
                    break
                }else{
                    found = false
                }
            } //foreach checking uniq
            
            if found == true {
                if sms.timeDate > foundValue!.timeDate {
                    //remove item and add latest item
                    uniqChatArray = uniqChatArray.filter{$0.numberValue != foundValue!.numberValue}
                    uniqChatArray.append(ModelHelper.copySMSData(sms: sms))
                }
                
                continue //go to next item
            }
            
            if found == false {
                uniqChatArray.append(ModelHelper.copySMSData(sms:sms))
            }
            
        } // end of smsArray foreach
        return uniqChatArray
    }
    
//    static func GetMessage(_ info: [AnyHashable: Any])->  LPLNotificationMessage {
//        
//        log.verbose(dump(info))
//        
//        if let aps = info["aps"] {
//            let aps = aps as! Dictionary<AnyHashable,Any>
//            let alert = aps["alert"] as! Dictionary<AnyHashable,Any>
//            let fromNo = alert["title"]
//            let msg = alert["body"]
//            //var status = ResponseStatus(.success)
//            return LPLNotificationMessage(msg: msg as! String,fromNo:fromNo as! String)
//        }
//        //var status = ResponseStatus(.fail,"invalid format")
//        return LPLNotificationMessage(msg: "",fromNo:"")
//    }
}
