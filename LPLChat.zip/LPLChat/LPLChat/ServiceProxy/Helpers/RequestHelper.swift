//
//  CookieHelper.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/28/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire

class RequestHelper{
    
    
    static func getHeadersForPartnerService(pageNo:String, pageSize:String, searchString : String) -> HTTPHeaders {
        
        var config = Configuration()

        let headers: HTTPHeaders = [
            "Accept":"application/json",
            "client_id":config.environment.clientId,
            "client_secret":config.environment.clientSecret,
            "Content-Type":"application/json",
            "Cookie":AppStateData.shared.getCookie(),
            "origin":config.environment.headerOrigin,
            "x-api-page-number":pageNo,
            "x-api-page-size":pageSize,
            "x-api-rep-id":Session.getUser()?.repId ?? "",
            "x-api-search-string":searchString,
            "x-api-tenant-id":"1",
            "x-api-transaction-id": UUID().uuidString,
            "X-XSRF-TOKEN": AppStateData.shared.getXSRFCookie()
        ]
        
        return headers
    }
    
    static func getHeaders() -> HTTPHeaders {
        
        //Always saving and retrieving the cookie//
        
        let headers: HTTPHeaders = [
            "transactionId": UUID().uuidString,
            "timestamp":Date().toISO8601String(),
            "sourceSystem":"LPLMessage",
            "X-XSRF-TOKEN": AppStateData.shared.getXSRFCookie() ,
            "Cookie":AppStateData.shared.getCookie(),
            "Accept":"application/json",
            "Content-Type":"application/json",
            "TimeZone": TimeZoneUtil.timezone()
            
        ]
        
        return headers
    }


}
