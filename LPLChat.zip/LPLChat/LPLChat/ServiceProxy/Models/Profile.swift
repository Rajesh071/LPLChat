//
//  Profile.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/22/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

public class Email {
    public var value:String!
    public var label:String!
    
    init(value:String, label:String) {
        self.value = value
        self.label = label
    }
}

public class Profile {
    var name:String!
    var phoneNumbers : [PhoneNumber]!
    var emails : [Email]!
    var addresses:[Address]!
    var birthday: String?
    var anniversary: String?
    var initals : String
    var amountValue: NSNumber!
    var variationValue: NSNumber!
    var asOfDate: Date!
    
    init(name: String, phoneNumbers: [PhoneNumber], emails: [Email], addresses: [Address], birthday: String?, anniversary: String?, amountValue: NSNumber, variationValue: NSNumber, asOfDateStr: String) {
        self.name = name
        self.phoneNumbers = phoneNumbers
        self.emails = emails
        self.addresses = addresses
        self.birthday = birthday
        self.anniversary = anniversary
        self.amountValue = amountValue
        self.variationValue = variationValue
        self.initals =  CustomUtility.returnStringInitials(name) //from name get initials.
        self.asOfDate = asOfDateStr.convertToDate()
    }
}
