//
// Created by Avinash Rajendran on 2/20/18.
// Copyright (c) 2018 LPL. All rights reserved.
//

import Foundation

class UserServiceResponse {
    let status: String
    let statusMessage: String
    let data: UserServiceResponseData
    
    init(status: String, statusMessage: String, data: UserServiceResponseData) {
        self.status = status
        self.statusMessage = statusMessage
        self.data = data
    }
}

class UserServiceResponseData {
    let validSession: Bool
    let userType: String
    let userID: String
    let userName: String
    let userInfo: UserInfo
    
    init(validSession: Bool, userType: String, userID: String, userName: String, userInfo: UserInfo) {
        self.validSession = validSession
        self.userType = userType
        self.userID = userID
        self.userName = userName
        self.userInfo = userInfo
    }
}

class UserInfo {
    let isActive: Bool
    let fullName: String
    let repID: String
    let officeID: String
    let unLicensedID: NSNull
    let institID: String
    let companyID: String
    let firmID: Int
    let profileID: Int
    let acctType: String
    
    init(isActive: Bool, fullName: String, repID: String, officeID: String, unLicensedID: NSNull, institID: String, companyID: String, firmID: Int, profileID: Int, acctType: String) {
        self.isActive = isActive
        self.fullName = fullName
        self.repID = repID
        self.officeID = officeID
        self.unLicensedID = unLicensedID
        self.institID = institID
        self.companyID = companyID
        self.firmID = firmID
        self.profileID = profileID
        self.acctType = acctType
    }
}

