//
//  Response.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/20/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class ResponseStatus {
    let statusType:StatusType
    let statusMessage:String!
    
    init(_ statusType:StatusType, _ msg:String = ""){
        self.statusType = statusType
        self.statusMessage = msg
    }
    
}

enum SMSMessageType : String, Codable {
    case SMS_Out
    case SMS_In
}

enum StatusType {
    case success
    case fail
    case sessionInvalid
}

class SendRequest {
    var messageToNumber: String
    var messageBody: String
    
    init(to: String, body: String) {
        self.messageToNumber = to
        self.messageBody = body
    }
}

class SMSResponse : Codable {
    
    let messageType: SMSMessageType
    let messageId: String!
    let messageLinkId: String!
    let messageDate: String!
    let messageBody: String!
    let messageToNumber: String!
    let messageToName: String!
    let messageFromNumber: String!
    let messageFromName: String!
    
    
    init(messageType: SMSMessageType, messageId: String!, messageLinkId: String!, messageDate: String!, messageBody: String!,
         messageToNumber: String, messageToName: String!, messageFromNumber: String!, messageFromName: String!) {
        self.messageType = messageType
        self.messageId = messageId
        self.messageLinkId = messageLinkId
        self.messageDate = messageDate
        self.messageBody = messageBody
        self.messageToNumber = messageToNumber
        self.messageToName = messageToName
        self.messageFromNumber = messageFromNumber
        self.messageFromName = messageFromName
    }
}

/*
 */

