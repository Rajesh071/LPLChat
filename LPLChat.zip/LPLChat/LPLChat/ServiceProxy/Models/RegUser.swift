////
////  RegUser.swift
////  LPLChat
////
////  Created by Avinash Rajendran on 3/1/18.
////  Copyright © 2018 LPL. All rights reserved.
////
//// To parse the JSON, add this file to your project and do:
////
////   let regUser = try RegUser(json)
////
//// To parse values from Alamofire responses:
////
////   Alamofire.request(url).responseRegUser{ response in
////     if let regUser = response.result.value {
////       ...
////     }
////   }
//
//import Foundation
//import Alamofire
//
//struct RegUser: Codable {
//    let status, statusMessage: String
//    let data: RegUserData
//
//    enum CodingKeys: String, CodingKey {
//        case status = "status"
//        case statusMessage, data
//    }
//}
//
//struct RegUserData: Codable {
//    let advisorBusinessnumberId, userName, fullname, firstName, lastName, state: String
//    let city, zipCode: String
//    let phoneNumbers: [String]
//    let isRegistered: Bool
//
//
//    enum CodingKeys: String, CodingKey {
//        case advisorBusinessnumberId = "advisorBusinessnumberId"
//        case userName, fullname, firstName, lastName, state, city, zipCode, phoneNumbers
//        case isRegistered = "isRegistered"
//
//    }
//}
//
//// MARK: Alamofire response handlers -
//
//extension DataRequest {
//
//
//    @discardableResult
//    func responseRegUser(queue: DispatchQueue? = nil, completionHandler: @escaping (DataResponse<RegUser>) -> Void) -> Self {
//        return responseDecodable(queue: queue, completionHandler: completionHandler)
//    }
//}
//
//// MARK: Convenience initializers
//
//extension RegUser {
//    init(data: Data) throws {
//        self = try JSONDecoder().decode(RegUser.self, from: data)
//    }
//
//    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
//        guard let data = json.data(using: encoding) else {
//            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
//        }
//        try self.init(data: data)
//    }
//
//    init(fromURL url: URL) throws {
//        try self.init(data: try Data(contentsOf: url))
//    }
//
//    func jsonData() throws -> Data {
//        return try JSONEncoder().encode(self)
//    }
//
//    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
//        return String(data: try self.jsonData(), encoding: encoding)
//    }
//}
//
