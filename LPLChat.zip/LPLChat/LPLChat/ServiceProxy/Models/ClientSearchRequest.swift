//
//  ClientSearchRequest.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/23/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

// To parse the JSON, add this file to your project and do:
//
//   let clientSearchRequest = try ClientSearchRequest(json)

struct ClientSearchRequest: Codable {
    var page: PageParam
    var sort, display: DisplayParam
    var listID: String
    
    enum CodingKeys: String, CodingKey {
        case page, sort, display
        case listID = "listId"
    }

    
    init(page:PageParam,sort:DisplayParam,display:DisplayParam,listID:String) {
        self.page = page
        self.sort = sort
        self.display = display
        self.listID = listID
    }
}

struct DisplayParam: Codable {
    var cols: String
    
    init(cols:String) {
        self.cols = cols
    }
}

struct PageParam: Codable {
    var pn: Int
    var ps: String
    
    init(pn:Int,ps:String) {
        self.pn = pn
        self.ps = ps
    }
}

struct SearchParam: Codable {
}

// MARK: Convenience initializers

extension ClientSearchRequest {
    init(data: Data) throws {
        self = try JSONDecoder().decode(ClientSearchRequest.self, from: data)
    }
    
    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }
    
    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }
    
    func jsonData() throws -> Data {
        return try JSONEncoder().encode(self)
    }
    
    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

extension DisplayParam {
    init(data: Data) throws {
        self = try JSONDecoder().decode(DisplayParam.self, from: data)
    }
    
    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }
    
    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }
    
    func jsonData() throws -> Data {
        return try JSONEncoder().encode(self)
    }
    
    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

extension PageParam {
    init(data: Data) throws {
        self = try JSONDecoder().decode(PageParam.self, from: data)
    }
    
    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }
    
    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }
    
    func jsonData() throws -> Data {
        return try JSONEncoder().encode(self)
    }
    
    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

extension SearchParam {
    init(data: Data) throws {
        self = try JSONDecoder().decode(SearchParam.self, from: data)
    }
    
    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }
    
    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }
    
    func jsonData() throws -> Data {
        return try JSONEncoder().encode(self)
    }
    
    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}
