//
//  DataRequest+Extensions.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/3/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire

extension DataRequest {
    
     public func logRequest() -> Self {
        let dr = self as DataRequest
        //log.verbose(dr)
        log.verbose("\(String(describing: dr.request?.httpMethod)) \(String(describing: dr.request?.url?.absoluteString)) \(String(describing: dr.request?.allHTTPHeaderFields)) \(String(describing: dr.request?.httpBody)) ")
        //log.verbose(self)
        return self
    }    
}
