//
//  UserSaveResponse.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

/*{
 
 "status": "success",
 "statusMessage": "Request was successful",
 "data": null
 }
 
 */


import Foundation
import Alamofire
import AlamofireObjectMapper
import ObjectMapper

class UserSaveResponse : Mappable, CustomDebugStringConvertible{
    var status, statusMessage: String!
    
    required init?(map: Map){
    }
    
    init(status: String, statusMessage: String) {
        self.status = status
        self.statusMessage = statusMessage
    }
    
    func mapping(map: Map) {
        status <- map["status"]
        statusMessage <- map["statusMessage"]
    }
    
    var debugDescription: String {
        return String("Status: \(status ?? "BLANK STATUS"). Message: \(statusMessage ?? ""))")
    }
}
