//
//  UserRegStatus.swift
//  LPLChat
//
//  Created by Animesh Ravi Paranur on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireObjectMapper
import ObjectMapper

class UserRegStatusResponse : ServiceResponse<UserRegStatusData>  {
    
}

class ServiceResponse<Data : Mappable> : Mappable, CustomDebugStringConvertible {
    var status, statusMessage: String!
    var data:Data!
    
    required init?(map: Map){
    }
    
    init(status: String, statusMessage: String, data: Data) {
        self.status = status
        self.statusMessage = statusMessage
        self.data = data
    }
    
    func mapping(map: Map) {
        status <- map["status"]
        statusMessage <- map["statusMessage"]
        data <- map["data"]
    }
    
    var debugDescription: String {
        return String("Status: \(status). Message: \(statusMessage) Data: \(data)")
    }
}

class UserRegStatusData: Mappable, CustomDebugStringConvertible {
    var advisorBusinessnumberId, userName, callForwardNumber, fullname, twilioNumber, repId: String!
    var isRegistered: Bool!

    required init?(map: Map){
        
    }
    
    init(advisorBusinessnumberId: String, userName: String, callForwardNumber: String, fullname: String,twilioNumber: String, isRegistered: Bool,repId: String) {
        self.advisorBusinessnumberId = advisorBusinessnumberId
        self.userName = userName
        self.callForwardNumber = callForwardNumber
        self.fullname = fullname
        self.twilioNumber = twilioNumber
        self.isRegistered = isRegistered
    }
    
    func mapping(map: Map) {
        advisorBusinessnumberId <- map["advisorBusinessnumberId"]
        userName <- map["userName"]
        callForwardNumber <- map["callForwardNumber"]
        fullname <- map["fullname"]
        twilioNumber <- map["twilioNumber"]
        isRegistered <- map["isRegistered"]
        repId <- map["repId"]
    }
    
    var debugDescription: String {
        return String("isRegistered :\(isRegistered) , twilioNumber: \(twilioNumber) , fwd: \(callForwardNumber)")
    }
}
//
//{
//    "status": "success",
//    "statusMessage": "Request was successful",
//    "data": {
//        "advisorBusinessnumberId": "00000000-0000-0000-0000-000000000000",
//        "userName": "vigilius.booke",
//        "callForwardNumber": "+1 (123) 456-7890",
//        "fullname": "Vigilius Booke DevInt",
//        "firstName": "Vigilius",
//        "lastName": "Booke",
//        "twilioNumber": "+1 (858) 703-5772",
//        "isRegistered": true,
//        "isActive": false,
//        "repId": "260A"
//    }
//}

