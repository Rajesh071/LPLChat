//
//  ASATStatusResponse.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/27/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireObjectMapper
import ObjectMapper

class ASATStatusResponse : ServiceResponse<ASATStatus>  {
    
}


class ASATStatus: Mappable, CustomDebugStringConvertible {
    
    var hasAccess: Bool!
    
    required init?(map: Map){
        
    }
    
    init(hasAccess: Bool) {
        self.hasAccess = hasAccess
    }
    
    func mapping(map: Map) {
        hasAccess <- map["asatCheck"]
    }
    
    var debugDescription: String {
        return String("hasAccess :\(hasAccess)")
    }
}

/*
 
 {
 "status": "success",
 "statusMessage": "Request was successful",
 "data": {
 "asatCheck": false
 }
 }
 
 */
