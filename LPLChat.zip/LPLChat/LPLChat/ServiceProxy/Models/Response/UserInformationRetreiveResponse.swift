//
//  UserInformationRetreiveResponse.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireObjectMapper
import ObjectMapper

class UserInfoRetrieveResponse: Mappable {
    
    var status: String!
    var statusMessage: String!
    var data: UserInfoRetrieveData!
    
    required init?(map: Map) {
        
    }
    
    init(status: String, statusMessage: String, data: UserInfoRetrieveData) {
        self.status = status
        self.statusMessage = statusMessage
        self.data = data
    }
    
    func mapping(map: Map) {
        status <- map["status"]
        statusMessage <- map["statusMessage"]
        data <- map["data"]
    }    
}

class UserInfoRetrieveData: Mappable {
    var advisorBusinessnumberID: String!
    var userName: String!
    var fullname: String!
    var firstName: String!
    var lastName: String!
    var state: String!
    var city: String!
    var zipCode: String!
    var phoneNumbers: [String]?
    var isRegistered: Bool!
    
    required init?(map: Map){
        
    }
    
    init(advisorBusinessnumberID: String, userName: String, fullname: String,
         firstName: String, lastName: String, state: String, city: String, zipCode: String,
         phoneNumbers: [String], isRegistered: Bool) {
        self.advisorBusinessnumberID = advisorBusinessnumberID
        self.userName = userName
        self.fullname = fullname
        self.firstName = firstName
        self.lastName = lastName
        self.state = state
        self.city = city
        self.zipCode = zipCode
        self.phoneNumbers = phoneNumbers
        self.isRegistered = isRegistered
    }
    
    func mapping(map: Map) {
        advisorBusinessnumberID <- map["advisorBusinessnumberId"]
        userName <- map["userName"]
        fullname <- map["fullname"]
        firstName <- map["firstName"]
        lastName <- map["lastName"]
        state <- map["state"]
        city <- map["city"]
        zipCode <- map["zipCode"]
        phoneNumbers <- map["phoneNumbers"]
        isRegistered <- map["isRegistered"]
    }
}

/*
 Sample
 /*
 {
 "status": "success",
 "statusMessage": "Request was successful",
 "data": {
 "advisorBusinessnumberId": "00000000-0000-0000-0000-000000000000",
 "userName": "vaishali.zachrich",
 "fullname": "Vaishali Zachrich DevInt",
 "firstName": "Vaishali",
 "lastName": "Zachrich",
 "state": "CA",
 "city": "PASADENA",
 "zipCode": "91101-4860",
 "phoneNumbers": [
 "+16267376751",
 "+16266584331",
 "+16266583871",
 "+16267738724",
 "+16262197434"
 ],
 "isRegistered": true
 }
 }
 
 */

 */
