////
////  MessageListResponse.swift
////  LPLChat
////
////  Created by Avinash Rajendran on 3/3/18.
////  Copyright © 2018 LPL. All rights reserved.
////
//
//
//// To parse the JSON
////
////   let messageListResponse = try MessageListResponse(json)
////
//// To parse values from Alamofire responses:
////
////   Alamofire.request(url).responseMessageListResponse{ response in
////     if let messageListResponse = response.result.value {
////       ...
////     }
////   }
//
//import Foundation
//import Alamofire
//
//typealias MessageListResponse = [MessageListResponseElement]
//
//struct MessageListResponseElement: Codable {
//    let messageType, messageID, messageLinkID: JSONNull?
//    let messageDate, messageBody, messageToNumber, messageToName: String
//    let messageFromNumber, messageFromName: String
//    let messageFromCity, messageFromState, messageFromCountry, messageFromZip: JSONNull?
//    let messageIsRead: Bool
//    
//    enum CodingKeys: String, CodingKey {
//        case messageType
//        case messageID = "messageId"
//        case messageLinkID = "messageLinkId"
//        case messageDate, messageBody, messageToNumber, messageToName, messageFromNumber, messageFromName, messageFromCity, messageFromState, messageFromCountry, messageFromZip, messageIsRead
//    }
//}
//
//// MARK: Alamofire response handlers -
//
//extension DataRequest {
//    @discardableResult
//    func responseMessageListResponse(queue: DispatchQueue? = nil, completionHandler: @escaping (DataResponse<MessageListResponse>) -> Void) -> Self {
//        return responseDecodable(queue: queue, completionHandler: completionHandler)
//    }
//}
//
//// MARK: Convenience initializers
//
//extension MessageListResponseElement {
//    init(data: Data) throws {
//        self = try JSONDecoder().decode(MessageListResponseElement.self, from: data)
//    }
//    
//    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
//        guard let data = json.data(using: encoding) else {
//            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
//        }
//        try self.init(data: data)
//    }
//    
//    init(fromURL url: URL) throws {
//        try self.init(data: try Data(contentsOf: url))
//    }
//    
//    func jsonData() throws -> Data {
//        return try JSONEncoder().encode(self)
//    }
//    
//    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
//        return String(data: try self.jsonData(), encoding: encoding)
//    }
//}
//
//extension Array where Element == MessageListResponse.Element {
//    init(data: Data) throws {
//        self = try JSONDecoder().decode(MessageListResponse.self, from: data)
//    }
//    
//    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
//        guard let data = json.data(using: encoding) else {
//            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
//        }
//        try self.init(data: data)
//    }
//    
//    init(fromURL url: URL) throws {
//        try self.init(data: try Data(contentsOf: url))
//    }
//    
//    func jsonData() throws -> Data {
//        return try JSONEncoder().encode(self)
//    }
//    
//    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
//        return String(data: try self.jsonData(), encoding: encoding)
//    }
//}
//
//// MARK: Encode/decode helpers
//
//class JSONNull: Codable {
//    public init() {}
//    
//    public required init(from decoder: Decoder) throws {
//        let container = try decoder.singleValueContainer()
//        if !container.decodeNil() {
//            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
//        }
//    }
//    
//    public func encode(to encoder: Encoder) throws {
//        var container = encoder.singleValueContainer()
//        try container.encodeNil()
//    }
//}

