//
//  RetrieveNumbersResponse.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import AlamofireObjectMapper
import ObjectMapper

class RetrieveNumbersResponse_DELETE : Mappable , CustomDebugStringConvertible{
        var status: String?
        var statusMessage: String?
        var data: [RetrievePhoneNumberData]?
        
        required init?(map: Map){
            
        }
        
        init(status: String?, statusMessage: String?, data: [RetrievePhoneNumberData]?) {
            self.status = status
            self.statusMessage = statusMessage
            self.data = data
        }
        
        func mapping(map: Map) {
            status <- map["status"]
            statusMessage <- map["statusMessage"]
            data <- map["data"]
        }
    
    var debugDescription: String {
        return String("Status: \(status ?? "BLANK STATUS"). Message: \(statusMessage ?? "") Data: \(String(describing: data))")
    }
    
    }

class RetrievePhoneNumberData: Mappable, CustomDebugStringConvertible {
    
    var phoneNumber: String?
    var locality: String?
    var region: String?
    var postalCode: String?
    
    required init?(map: Map){
        
    }
    
    init(phoneNumber: String?, locality: String?, region: String?, postalCode: String?) {
        self.phoneNumber = phoneNumber
        self.locality = locality
        self.region = region
        self.postalCode = postalCode
    }
    
    func mapping(map: Map) {
        phoneNumber <- map["phone_number"]
        locality <- map["locality"]
        region <- map["region"]
        postalCode <- map["postal_code"]
    }
    
    var debugDescription: String {
        return String("ph :\(String(describing: phoneNumber))")
    }
}
