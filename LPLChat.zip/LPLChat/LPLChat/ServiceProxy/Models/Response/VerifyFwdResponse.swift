//
//  VerifyFwdResponse.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

//
//  UserRegStatus.swift
//  LPLChat
//
//  Created by Animesh Ravi Paranur on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import AlamofireObjectMapper
import ObjectMapper

class VerifyFwdResponse : Mappable{
    var status, statusMessage: String!
    var data:Bool!
    
    required init?(map: Map){
    }
    
    init(status: String, statusMessage: String, data: Bool) {
        self.status = status
        self.statusMessage = statusMessage
        self.data = data
    }
    
    func mapping(map: Map) {
        status <- map["status"]
        statusMessage <- map["statusMessage"]
        data <- map["data"]
    }
}
