//
//  VerifyFwdNumber.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

//{
//    "fwdNumber": "704-000-0000",
//    "verificationCode": "0901"
//}

