//
//  HTTPMethodType.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/27/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum HTTPMethodType: String {
    case get = "GET"
    case post = "POST"
    case put = "PUT"
    case delete = "DELETE"
}

