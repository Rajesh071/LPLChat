//
//  ContactService.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/24/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class ContactService {

    public static func getClients(pageNo: Int, pageSize: Int, searchString: String, completionHandler: @escaping(Int, [Contacts]?, ResponseStatus) -> Void) {
        log.verbose("pageNo: \(pageNo) \(searchString)", context: "ctxPaging")
        var config = Configuration()
        var url = config.environment.baseWebApiUrl + ServiceURL.clientsGet
        if searchString.count > 0 {
           url.append("/\(searchString)")
        }
        url.append("/\(pageNo)/\(pageSize)")
        var allContacts: [Contacts] = []
        let headers = RequestHelper.getHeaders()
        Alamofire.request(url, method: .get, headers: headers).logRequest().responseJSON { response in
            log.verboseResponse(response)
            let respJson = JSON(response.result.value ?? "BLANK")
            let count = respJson["totalRecord"].numberValue
            let prospectListJson = respJson["data"]
            for (_, dict) in prospectListJson {
                allContacts.append(ModelTransformer.convertNewServiceJsonToLPLContact(dict))
            }
            return completionHandler(count.intValue, allContacts, ResponseStatus(.success))
        }
    }
    
    public static func getProspects(pageNo: Int, pageSize: Int, searchString: String, completionHandler: @escaping(Int, [Prospect]?, ResponseStatus) -> Void) {
        log.verbose("pageNo: \(pageNo) \(searchString)", context: "ctxPaging")
        var config = Configuration()
        var urlString = config.environment.baseWebApiUrl + ServiceURL.getProspects
        if searchString.count > 0 {
            urlString.append("/\(searchString)")
        }
        urlString.append("/\(pageNo)/\(pageSize)")
        guard let url = URL(string: urlString) else {
            return
        }
        let request = createURLRequest(url: url, type: "Get")
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let jsonData = data {
                do {
                    let propectsResponse = try JSONDecoder().decode(ProspectResponse.self, from: jsonData)
                    guard let status = propectsResponse.status else {
                        return
                    }
                    if status == "success" {
                        let propects: [Prospect] = propectsResponse.data
                        completionHandler(propects.count, propects, ResponseStatus(.success))
                    } else {
                        completionHandler(0, [Prospect](), ResponseStatus(.fail))
                    }
                } catch {
                    print(error)
                }
            }
        }.resume()
    }
    
    private static func createURLRequest(url: URL, type: String) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = type
        request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
        return request
    }


}
