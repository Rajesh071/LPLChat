//
//  RegistrationService.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/28/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class RegistrationService {
    
    public static func saveDisclaimer (isAccepted:Bool,completionHandler : @escaping(ResponseStatus) -> Void) {
        
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.regSaveDisclaimer
        log.verbose(url)
        
        if EnvOverrides.debugUseDummyData{
            return completionHandler(ResponseStatus(.success))
        }
        
        let param:Parameters = ["accepted":isAccepted]
        log.verbose(param)
        let request =  Alamofire.request(url, method:.post,  parameters:param,  encoding: JSONEncoding.default , headers:RequestHelper.getHeaders()).responseJSON{ response in
            log.verbose(response)
            
            if response.result.value == nil {
                return
            }

            if response.result.isSuccess {
                return completionHandler(ResponseStatus(.success))
            } else {
                return completionHandler(ResponseStatus(.fail))
            }
        }
        
        print (request)
    }
    
    public static func checkRegistration(oldToken:String,
                                         newToken:String,
                                         completionHandler : @escaping(UserRegStatusResponse?,ResponseStatus) -> Void) {
        
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.checkRegistration
        log.verbose(url)
        
//        if EnvOverrides.debugUseDummyData {
//
//            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.5) {
//
//                log.verbose("== DEBUGOVERRIDE == debugUseDummyData")
//                //let returnObj = StaticDataStore.retrieveUserRegStatus()
//                let returnObj: UserRegStatusResponse = StaticDataStore.retrieveUserRegStatusData()
//                return completionHandler(returnObj,ResponseStatus(.success))
//            }
//        }
//        else {
            log.verbose(AppStateData.shared.getCookie())
            
            //Save All the cookies to store first//
            if CookieUtility.getCookies().contains(";z="){
                AppStateData.shared.saveCookie(cookie: CookieUtility.getCookies())
                AppStateData.shared.saveXSRFCookie(cookie: CookieUtility.getCookieValue(key: AppStateFlags.xsrfToken.rawValue))
            }
            
            if !(AppStateData.shared.getCookie().contains(";z=")) {
                 DispatchQueue.main.async{
                log.verbose("z cookie missing")
                return completionHandler(nil,ResponseStatus(.sessionInvalid))
                }
            }
            else {
                var headers = RequestHelper.getHeaders()
              
                headers["oldToken"] = oldToken
                headers["newToken"] = newToken
                
                // if old and new token is same send old token empty
                if oldToken.elementsEqual(newToken) {
                    headers["oldToken"] = ""
                }
                
                print("Reg Service old token = >>> \(oldToken)")
                print("Reg Service new token = >>> \(newToken)")

                log.verbose(headers)
//                print("url = \(url)")
                
//                print("headers = \(headers)")

                Alamofire.request(url,
                                  method:.get,
                                  headers:headers).logRequest().responseObject {
                    (response: DataResponse<UserRegStatusResponse>) in
                    
                                    log.verbose("checkRegistration: \(response)")
                    
                    switch response.result {
                    case .success:
                        
                        log.verbose(response)
                        
                        if let userRegResponse = response.result.value{
                            var status  = ResponseStatus(.success)
                            if userRegResponse.status != "success"{
                                status = ResponseStatus(.fail,userRegResponse.statusMessage!)
                            }
                            return completionHandler(userRegResponse, status)
                        }
                        return completionHandler(nil, ResponseStatus(.fail,"Error checking registraion status. Please try again."))
                        
                    case .failure(let error):
                        log.verbose(error)
                        return completionHandler(nil,ResponseStatus(.fail,"Error checking registration. Please try again."))
                    }
                }
            }
//        }
    }
    
    public static func userRetrieveInformation(completionHandler
        : @escaping(UserInfoRetrieveData?,ResponseStatus) -> Void) {
        
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.userRetrieve
        log.verbose(url)
        var status = ResponseStatus(.success)
        var returnObj:UserInfoRetrieveData?
        
//        if EnvOverrides.debugUseDummyData {
//            log.verbose("== DEBUGOVERRIDE == debugUseDummyData")
//            returnObj = StaticDataStore.retrieveUserRegStatus()
//            return completionHandler(returnObj,status)
//        }
        
        Alamofire.request(url,  method:.get, parameters:RequestHelper.getHeaders()).responseObject
            { (response: DataResponse<UserInfoRetrieveResponse>) in
                log.verbose(response)
                
                switch response.result {
                case .success:
                    let responseObj = response.result.value
                    if responseObj?.status == "success" {
                        returnObj = responseObj!.data
                    }
                    else {
                        status = ResponseStatus(.fail,(responseObj?.statusMessage)!)
                    }
                    break
                case .failure(let error):
                    log.verbose(error)
                    status = ResponseStatus(.fail,"Error to retrieve user information.")
                }
                
                return completionHandler(returnObj,status)
        }
    }
    
    public static func getNumbers(for state:String!,
                                  city:String!,
                                  completionHandler : @escaping([String]?,ResponseStatus) -> Void) {
        
        //url
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.regRetreiveNumbers
        log.verbose(url)
        
        //input
        let params :Parameters = ["state": state,"city": city]
        log.verbose(params)
        
        //output
        var status = ResponseStatus(.success)
        var returnObj:[String]?
        
        Alamofire.request(url,  method:.post, parameters:params,encoding: JSONEncoding.default, headers: RequestHelper.getHeaders()  ).logRequest().responseObject {
            (response: DataResponse<RetrieveNumbersResponse_DELETE>) in
            log.verbose(response)
            
            switch response.result {
            case .success:
                let responseObj = response.result.value
                if responseObj?.status == "success" {
                    returnObj = getPhoneNumberAsStrings(responseObj?.data)
                    
                }else {
                    status = ResponseStatus(.fail,(responseObj?.statusMessage)!)
                }
                break
            case .failure(let error):
                log.verbose(error)
                status = ResponseStatus(.fail,"Unknown Error. Please try again.")
            }
            
            return completionHandler(returnObj,status)
        }
    }
    
    
    static func getPhoneNumberAsStrings(_ phoneDataList:[RetrievePhoneNumberData]? ) -> [String]{
        
        var strings:[String] = []
        
        if let phoneDataList = phoneDataList{
            for data in phoneDataList {
                if let ph = data.phoneNumber{
                    strings.append(ph)
                }
            }
        }
        return strings
    }
    
    public static func SendVerificationCode(to forwardNumber:String!, completionHandler : @escaping(Bool?, ResponseStatus) -> Void) {
        
        //url
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.verifyCallFwd
        
        //input
        let params :Parameters = ["fwdNumber": CustomUtility.removeFormatting(forwardNumber)]
        
        //output
        var status = ResponseStatus(.success)
        var returnObj:Bool?
        
        //DEBUGOVERRIDE
        if EnvOverrides.debugSkipVerificationStep {
            log.verbose("== DEBUGOVERRIDE == debugSkipVerificationStep")
            return completionHandler(true,status)
        }
        //DEBUGOVERRIDE
        if EnvOverrides.debugUseDummyData {
            log.verbose("== DEBUGOVERRIDE == debugUseDummyData")
            return completionHandler(true,status)
        }
        
        //Request
        Alamofire.request(url,  method:.post, parameters:params , encoding:JSONEncoding.default ,
                          headers: RequestHelper.getHeaders()).logRequest().responseObject
            {(response: DataResponse<VerifyFwdResponse>) in
                
                log.verbose(response)
                
                switch response.result {
                case .success:
                    let responseObj = response.result.value
                    if responseObj?.status == "success" {
                        returnObj = responseObj!.data
                    }else {
                        status = ResponseStatus(.fail,(responseObj?.statusMessage)!)
                    }
                    break
                case .failure(let error):
                    log.verbose(error)
                    status = ResponseStatus(.fail,"Unknown Error. Please try again.")
                }
                return completionHandler(returnObj,status)
        }
        
    }
    
    public static func VerifyTokenAndPhoneNumber( forwardNumber:String!,verificationCode:String!, completionHandler : @escaping(Bool?, ResponseStatus) -> Void) {
        
        //url
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.verifyTokenAndPhone
        
        //input
        let params :Parameters = ["fwdNumber": CustomUtility.removeFormatting(forwardNumber),"verificationCode":verificationCode ]
        
        //output
        //var status = ResponseStatus(.success)
        var returnObj:Bool?
        var status = ResponseStatus(.success)
        
        if EnvOverrides.debugUseDummyData || EnvOverrides.debugSkipVerificationStep {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.5) {
                log.verbose("== DEBUGOVERRIDE == debugUseDummyData or debugSkipVerificationStep")
                return completionHandler(true,ResponseStatus(.success))
            }
        } else{
            
            //Request
            Alamofire.request(url,  method:.post, parameters:params, encoding:JSONEncoding.default , headers: RequestHelper.getHeaders())
                .logRequest().responseObject {
                (response: DataResponse<VerifyFwdResponse>) in
                log.verbose(response)
                
                switch response.result {
                case .success:
                    let responseObj = response.result.value
                    if responseObj?.status == "success" {
                        returnObj = responseObj!.data
                    }else {
                        status = ResponseStatus(.fail,(responseObj?.statusMessage)!)
                    }
                    break
                case .failure(let error):
                    log.verbose(error)
                    status = ResponseStatus(.fail,"Unknown Error. Please try again.")
                }
                return completionHandler(returnObj,status)
            }
        }
    }
    
    public static func userInfoSave(callFwdNumber:String,
                                    deviceToken:String,
                                    twilioNumber:String,
                                    completionHandler : @escaping(ResponseStatus) -> Void) {
        
        print("state complete device token = \(deviceToken)")
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.userInfoSave
        
        let twilioNumberActual = twilioNumber
//        if EnvConstants.debugDoOverrideTwilioNumber {
//            twilioNumberActual = EnvConstants.debugOverrideTwilioNumber
//        }
        
        //input
        let params : Parameters = ["callForwardNumber":CustomUtility.removeFormatting(callFwdNumber),
                                   "deviceToken":deviceToken,
                                   "twilioNumber":CustomUtility.removeFormatting(twilioNumberActual)]
        //output
        var status = ResponseStatus(.success)
        
        if EnvOverrides.debugUseDummyData {
            
            return completionHandler(status)
        }
        
        //Request
        Alamofire.request(url,
                          method:.post,
                          parameters:params,
                          encoding:JSONEncoding.default,
                          headers: RequestHelper.getHeaders()).logRequest().responseObject {
                            
            (response: DataResponse<UserSaveResponse>) in
            log.verbose(response)
            
                            Session.updateUser(twilioNumber: twilioNumber, callFwdNumber: callFwdNumber)
                            
            switch response.result {
            case .success:
                let responseObj = response.result.value
                if responseObj?.status == "success" {
                    //returnObj = responseObj!.data
                    //success
                }else {
                    status = ResponseStatus(.fail,(responseObj?.statusMessage)!)
                }
                break
            case .failure(let error):
                log.verbose(error)
                status = ResponseStatus(.fail,"Unknown Error. Please try again.")
            }
            return completionHandler(status)
        }
    }
    
    public static func checkRegistrationDev(completionHandler : @escaping(ResponseStatus) -> Void) {
        return completionHandler(ResponseStatus(.fail))
    }
    
    public static func getStates() ->  [(name:String, abbreviation:String)] {
        
        let states : [(name:String, abbreviation:String)] =
            [( name: "ALABAMA", abbreviation: "AL" ),
             ( name: "ALASKA", abbreviation: "AK" ),
             ( name: "AMERICAN SAMOA", abbreviation: "AS" ),
             ( name: "ARIZONA", abbreviation: "AZ" ),
             ( name: "ARKANSAS", abbreviation: "AR" ),
             ( name: "CALIFORNIA", abbreviation: "CA" ),
             ( name: "COLORADO", abbreviation: "CO" ),
             ( name: "CONNECTICUT", abbreviation: "CT" ),
             ( name: "DELAWARE", abbreviation: "DE" ),
             ( name: "DISTRICT OF COLUMBIA", abbreviation: "DC" ),
             ( name: "FEDERATED STATES OF MICRONESIA", abbreviation: "FM" ),
             ( name: "FLORIDA", abbreviation: "FL" ),
             ( name: "GEORGIA", abbreviation: "GA" ),
             ( name: "GUAM", abbreviation: "GU" ),
             ( name: "HAWAII", abbreviation: "HI" ),
             ( name: "IDAHO", abbreviation: "ID" ),
             ( name: "ILLINOIS", abbreviation: "IL" ),
             ( name: "INDIANA", abbreviation: "IN" ),
             ( name: "IOWA", abbreviation: "IA" ),
             ( name: "KANSAS", abbreviation: "KS" ),
             ( name: "KENTUCKY", abbreviation: "KY" ),
             ( name: "LOUISIANA", abbreviation: "LA" ),
             ( name: "MAINE", abbreviation: "ME" ),
             ( name: "MARSHALL ISLANDS", abbreviation: "MH" ),
             ( name: "MARYLAND", abbreviation: "MD" ),
             ( name: "MASSACHUSETTS", abbreviation: "MA" ),
             ( name: "MICHIGAN", abbreviation: "MI" ),
             ( name: "MINNESOTA", abbreviation: "MN" ),
             ( name: "MISSISSIPPI", abbreviation: "MS" ),
             ( name: "MISSOURI", abbreviation: "MO" ),
             ( name: "MONTANA", abbreviation: "MT" ),
             ( name: "NEBRASKA", abbreviation: "NE" ),
             ( name: "NEVADA", abbreviation: "NV" ),
             ( name: "NEW HAMPSHIRE", abbreviation: "NH" ),
             ( name: "NEW JERSEY", abbreviation: "NJ" ),
             ( name: "NEW MEXICO", abbreviation: "NM" ),
             ( name: "NEW YORK", abbreviation: "NY" ),
             ( name: "NORTH CAROLINA", abbreviation: "NC" ),
             ( name: "NORTH DAKOTA", abbreviation: "ND" ),
             ( name: "NORTHERN MARIANA ISLANDS", abbreviation: "MP" ),
             ( name: "OHIO", abbreviation: "OH" ),
             ( name: "OKLAHOMA", abbreviation: "OK" ),
             ( name: "OREGON", abbreviation: "OR" ),
             ( name: "PALAU", abbreviation: "PW" ),
             ( name: "PENNSYLVANIA", abbreviation: "PA" ),
             ( name: "PUERTO RICO", abbreviation: "PR" ),
             ( name: "RHODE ISLAND", abbreviation: "RI" ),
             ( name: "SOUTH CAROLINA", abbreviation: "SC" ),
             ( name: "SOUTH DAKOTA", abbreviation: "SD" ),
             ( name: "TENNESSEE", abbreviation: "TN" ),
             ( name: "TEXAS", abbreviation: "TX" ),
             ( name: "UTAH", abbreviation: "UT" ),
             ( name: "VERMONT", abbreviation: "VT" ),
             ( name: "VIRGIN ISLANDS", abbreviation: "VI" ),
             ( name: "VIRGINIA", abbreviation: "VA" ),
             ( name: "WASHINGTON", abbreviation: "WA" ),
             ( name: "WEST VIRGINIA", abbreviation: "WV" ),
             ( name: "WISCONSIN", abbreviation: "WI" ),
             ( name: "WYOMING", abbreviation: "WY" )]
        
        return states
    }
}
