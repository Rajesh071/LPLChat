//
//  ASATService.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/27/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Alamofire

typealias ASATCompletionHandler = (ASATStatus, ResponseStatus) -> ()

class ASATService {
    
    public static func checkASAT(completionHandler : @escaping ASATCompletionHandler) {
        
        //url
        var config = Configuration()
        let url = config.environment.baseWebApiUrl + ServiceURL.userASATCheck
        
        //output
        var returnObj = ASATStatus(hasAccess: false)
        var responseStatus = ResponseStatus(.fail)

//        if EnvConstants.debugDoOverrideASATAccess {
//
//            log.verbose("== DEBUGOVERRIDE == debugDoOverrideASATAccess")
//            returnObj = ASATStatus(hasAccess: EnvConstants.debugOverrideASATAccess)
//            responseStatus = ResponseStatus(.success)
//            return completionHandler(returnObj,responseStatus)
//        }
        
            Alamofire.request(url,  method:.get, headers:RequestHelper.getHeaders()).logRequest().responseObject {
                (response: DataResponse<ASATStatusResponse>) in
                
                log.verbose(response)
                
                switch response.result {
                case .success:
                    if let responseResult = response.result.value{
                       
                        if responseResult.status != "success" {
                            responseStatus = ResponseStatus(.fail,responseResult.statusMessage!)
                        }else{
                            responseStatus = ResponseStatus(.success)
                        }
                        returnObj = responseResult.data
                    }else{
                        returnObj = ASATStatus(hasAccess: false)
                        responseStatus = ResponseStatus(.fail,"Error checking ASAT status. Please try again.")
                    }
                    break
                case .failure(let error):
                    log.verbose(error)
                    returnObj = ASATStatus(hasAccess: false)
                    responseStatus = ResponseStatus(.fail,"Error checking ASAT status. Please try again.")
                }
                log.verbose("sending")
                return completionHandler(returnObj,responseStatus)
            }
    }
}

/*
 
 {
 "status": "success",
 "statusMessage": "Request was successful",
 "data": {
 "asatCheck": false
 }
 }
 
 */
