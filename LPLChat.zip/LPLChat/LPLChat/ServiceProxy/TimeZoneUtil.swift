//
//  TimeZoneUtil.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/23/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class TimeZoneUtil: NSObject {

    /// Current discussion will return timezone
    ///
    /// - Returns: String in timezone
    
    class func timezone() -> String {
        let timezone = NSTimeZone.local
        let timezoneName = timezone.localizedName(for: .standard, locale: NSLocale.current)
        
        return timezoneName ?? ""
    }
}
