//
//  CustomLabel.swift
//  StickyHeader
//
//  Created by developer on 3/11/18.
//  Copyright © 2018 Sanjeev Bharti. All rights reserved.
//

import UIKit

@IBDesignable

class CustomLabel: UILabel {
    
    @IBInspectable var isRounded: Bool = false
    @IBInspectable var contentInset: CGFloat = 0.0
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        let insets: UIEdgeInsets = UIEdgeInsets(top: contentInset,
                                                left: contentInset,
                                                bottom: contentInset,
                                                right: contentInset)
        if isRounded {
            self.roundCorner(cornerRadius: self.frame.size.width / 2,
                             borderWidth: 1.0,
                             borderColor: UIColor.clear)
        }
        
        self.numberOfLines = 0
        super.drawText(in: UIEdgeInsetsInsetRect(rect, insets))
    }

}
