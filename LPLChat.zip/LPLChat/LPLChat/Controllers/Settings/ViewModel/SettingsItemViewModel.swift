//
//  BaseSettingsItemViewModel.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum SettingsType{
    case link
    case flag
}

//Section - with header like "Support" and items within section
struct SettingsSection {
    var sectionHeader:String?
    var sectionItems:[BaseSettingsItemViewModel] = []
}

//Base for SettingsItem - look at derived class for more info.
class BaseSettingsItemViewModel {
    var label:String
    var type:SettingsType

    init(label:String, type:SettingsType) {
        self.label = label
        self.type = type
    }
}

