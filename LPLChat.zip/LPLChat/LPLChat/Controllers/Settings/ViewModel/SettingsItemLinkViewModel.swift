//
//  asd.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

typealias TapLinkActionHandler = (LinkType) -> ()

enum LinkType: String {
    case termsOfService = "Terms of Service"
    case editCallForwardNumber = "Change Call Forwarding Number"
    case logOut = "Log Out"
    case emailSupport = "Email Support"
    case callSupport = "Call Support"
}

class LinkTypeManager {
   class func getServiceType (linkType : LinkType) -> Service {
        var service : Service
        switch linkType {
        case .termsOfService:
            service = .termsOfUse
        default:
            service = .termsOfUse
        }
        return service
    }
}

//Eg., Item to display link to open a webpage eg., Terms Of Use
class SettingsItemLinkViewModel : BaseSettingsItemViewModel{
    var linkType: LinkType?
    var actionHandler:TapLinkActionHandler?
    init(label : String) {
        super.init(label: label, type: .link)
    }
}
