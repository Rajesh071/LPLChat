//
//  SettingsItemFlagViewModel.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

typealias ToggleActionHandler = (Bool) -> ()

//Eg., Enable Biometric with on/off flag
class SettingsItemFlagViewModel : BaseSettingsItemViewModel{
    
    var value: Bool
    
    //Closure to call when toggled
    var actionHandler:ToggleActionHandler?
    
    init(label:String, value:Bool) {
        self.value = value
        super.init(label: label, type: .flag)
    }
}
