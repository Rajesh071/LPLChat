//
//  VersionInfo.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/20/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct VersionInfo {
    
    var versionNumber : String
    var buildNumber : String
    var env: String
    
    init(versionNumber:String, buildNumber: String, env:String) {
        self.versionNumber = versionNumber
        self.buildNumber = buildNumber
        self.env = env
    }
}
