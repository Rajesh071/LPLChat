//
//  SettingsViewModel.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import UIKit

typealias LinkPressedHandler = (_ linkType: LinkType) -> ()

typealias LogOutHandler = () -> ()
typealias CallSupportHandler = () -> ()
typealias EmailSupportHandler = () -> ()
typealias DefaultCompletionHandler = () -> ()

//Defines all sections and settingsitems within each section.
//Actions for all the settings are also defined here.
class SettingsViewModel {

    var linkPressedHandler: LinkPressedHandler?
    var logOutHandler: LogOutHandler?
    var callSupportHandler : CallSupportHandler?
    var emailSupportHandler : EmailSupportHandler?
    var defaultCompletionHandler: DefaultCompletionHandler?
    
    //Main model for this VM
    var sections:[SettingsSection] = []
    
    init() {
        sections = setupSections()
    }
   
    //MARK: - Setup
    func getVersionInfo() -> VersionInfo {
        let versionNumber = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
        let buildNumber = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as! String
        var config = Configuration()
        return VersionInfo(versionNumber: versionNumber, buildNumber:buildNumber, env: config.environment.env)
    }
    
    func getAppSection () -> [BaseSettingsItemViewModel] {
        //Enable BioMetrics
        let bioVM: SettingsItemFlagViewModel?
        let deviceType = UIDevice().type
        switch deviceType {
        case .iPhoneX:
            bioVM = SettingsItemFlagViewModel(  label: "Enable FaceID", value: self.returnBiometricButtonStat())
        default:
            bioVM = SettingsItemFlagViewModel(  label: "Enable TouchID", value: self.returnBiometricButtonStat())
        }
        guard let enableBioVM = bioVM else {
            return []
        }
        enableBioVM.actionHandler = enableBioAction
        
        // Edit call forwarding Number
        let editCallForwardNumberVM = SettingsItemLinkViewModel(label: "Change Call Forwarding Number")
        editCallForwardNumberVM.linkType = .editCallForwardNumber
        editCallForwardNumberVM.actionHandler = actionEditCallForward

        // Log out
        let linkLogOutVM = SettingsItemLinkViewModel(label: "Log Out")
        linkLogOutVM.linkType = .logOut
        linkLogOutVM.actionHandler = actionLogOut
        
        return [enableBioVM, editCallForwardNumberVM, linkLogOutVM]
    }
    
    func returnBiometricButtonStat() -> Bool {
        if TouchIDUtility.isTouchIdConfigured() {
            return TouchIDUtility.getBiometricPref()
        }
        return TouchIDUtility.isTouchIdConfigured()
    }
    
    func setupSections() -> [SettingsSection]{
        var items : [SettingsSection] = []
        let sectionAppSettings = SettingsSection(sectionHeader: "ACCOUNT", sectionItems: getAppSection())
        let sectionSupport = SettingsSection(sectionHeader: "SUPPORT", sectionItems:getSupportSection())
        let sectionLegal = SettingsSection(sectionHeader: "LEGAL", sectionItems:getLegalSection())
        items.append(sectionAppSettings)
        items.append(sectionSupport)
        items.append(sectionLegal)
        return items
    }
    
    func getLegalSection () -> [BaseSettingsItemViewModel] {
        let linkTOS = SettingsItemLinkViewModel(label: "Terms of Service")
        linkTOS.linkType = .termsOfService
        linkTOS.actionHandler = actionLink
        return [linkTOS]
    }
    
    func getSupportSection () -> [BaseSettingsItemViewModel] {
        let emailSupportVM = SettingsItemLinkViewModel(label: LinkType.emailSupport.rawValue)
        emailSupportVM.linkType = .emailSupport
        emailSupportVM.actionHandler = actionEmailSupport
        let callSupportVM = SettingsItemLinkViewModel(label: LinkType.callSupport.rawValue)
        callSupportVM.linkType = .callSupport
        callSupportVM.actionHandler = actionCallSupport
        return [emailSupportVM, callSupportVM]
    }
    
    //MARK: - Actions Account
    func enableBioAction(flag:Bool){
        print("Bio Pref \(flag)")
        if TouchIDUtility.isTouchIdConfigured(){
            TouchIDUtility.setBiometricPref(value: flag)
        }
    }
    
    func actionLogOut (_ linkType: LinkType){
        logOutHandler?()
    }
    
    func actionEditCallForward (_ linkType: LinkType){
        defaultCompletionHandler?()
    }
    
    //MARK: - Actions Generic Link
    func actionLink(_ linkType: LinkType){
        linkPressedHandler?(linkType)
    }
    
    //MARK: - Actions Support
    func actionCallSupport (_ linkType: LinkType){
        callSupportHandler?()
    }
    
    func actionEmailSupport (_ linkType: LinkType){
        emailSupportHandler?()
    }

}
