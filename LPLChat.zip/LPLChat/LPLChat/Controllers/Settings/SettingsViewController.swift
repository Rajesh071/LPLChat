//
//  SettingsViewController.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import MessageUI

class SettingsViewController: UITableViewController {

    var settingsViewModel:SettingsViewModel = SettingsViewModel()
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setupNavigationBar()
        setupVm()
        setupTable()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    // MARK: UI
    func setupNavigationBar() {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.barTintColor = UIColor.lPLLightGray
        self.navigationController?.navigationBar.tintColor = UIColor.lPLBlue1
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    // MARK: - Table view
    func setupTable(){
        
        //Setup Footer
        let footerView = SettingsFooterView.build()
        footerView.configure(info: settingsViewModel.getVersionInfo())
        tableView.tableFooterView = footerView
        
        //Setup Header
        let advisorView = AdvisorView.build()
        advisorView.configure(name: Session.user?.fullname ?? "N A", virtualNumber: Session.user?.twilioNumber ?? "--")
        tableView.tableHeaderView = advisorView
        
        //Setup Table
        let nib = UINib(nibName: SettingsSectionHeaderView.nibName, bundle: nil)
        tableView.register(nib, forHeaderFooterViewReuseIdentifier: SettingsSectionHeaderView.Id)
        
        tableView.estimatedRowHeight = 10
        tableView.rowHeight = UITableViewAutomaticDimension
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return settingsViewModel.sections.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let currentSection = settingsViewModel.sections[section]
        return currentSection.sectionItems.count
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let currentSection = settingsViewModel.sections[section]
        let cell = self.tableView.dequeueReusableHeaderFooterView(withIdentifier: SettingsSectionHeaderView.nibName)
        let header = cell as! SettingsSectionHeaderView
        header.configure(currentSection)
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell?
        let currentSectionItem : BaseSettingsItemViewModel = settingsViewModel.sections[indexPath.section].sectionItems[indexPath.row]
        switch currentSectionItem.type {
        case .flag :
            cell = buildFlagCell(tableView, at:indexPath, with:currentSectionItem)
        case .link :
            cell = buildLinkCell(tableView, at:indexPath, with:currentSectionItem)
        }
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let settingType: String = settingsViewModel.sections[indexPath.section].sectionItems[indexPath.row].label
//        switch settingType {
//        case FlagType.bioMetrics.rawValue:
//            print("🤖 bioMetrics selected")
//        case LinkType.editCallForwardNumber.rawValue:
//            print("🤖 editCallForwardNumber selected")
//        case LinkType.logOut.rawValue:
//            print("🤖 logOut selected")
//        case LinkType.support.rawValue:
//            print("🤖 support selected")
////            insertSupportCells(indexPath: indexPath)
//        case LinkType.termsOfService.rawValue:
//            print("🤖 termsOfService selected")
//        default:
//            print("❌ unknown \(settingType) selected")
//        }
    }
    
//    func insertSupportCells(indexPath: IndexPath) {
//        tableView.beginUpdates()
//        tableView.insertRows(at: [indexPath, IndexPath(row: indexPath.row + 1, section: indexPath.section)], with: .automatic)
//        tableView.endUpdates()
//    }
    
    func buildFlagCell(_ tableView :UITableView, at indexPath:IndexPath,with item: BaseSettingsItemViewModel) -> UITableViewCell{
        let flagCell = tableView.dequeueReusableCell(withIdentifier: SettingsFlagTableViewCell.Id, for: indexPath) as! SettingsFlagTableViewCell
        flagCell.configure(item as! SettingsItemFlagViewModel)
        return flagCell
    }
    
    func buildLinkCell(_ tableView :UITableView, at indexPath:IndexPath,with item: BaseSettingsItemViewModel) -> UITableViewCell{
        let linkCell = tableView.dequeueReusableCell(withIdentifier: SettingsLinkTableViewCell.Id, for: indexPath) as! SettingsLinkTableViewCell
        linkCell.configure(item as! SettingsItemLinkViewModel)
        return linkCell
    }
}


//VM related
extension SettingsViewController {
    
    func setupVm(){
        settingsViewModel.linkPressedHandler = linkPressed
        settingsViewModel.logOutHandler = logOutConfirmation
        settingsViewModel.callSupportHandler = callSupport
        settingsViewModel.emailSupportHandler = emailSupport
        settingsViewModel.defaultCompletionHandler = editCallForwarding
    }
    
    func editCallForwarding() {
        let selectCallForwardingVM = SelectCallForwardingViewModel()
        selectCallForwardingVM.selectedVirtualNumber = Session.user?.twilioNumber
        selectCallForwardingVM.configurationType = .edit
        let selectCallForwardingVC = SelectCallForwardingViewController.buildViewController(with: selectCallForwardingVM)
        guard let callForwardingNumberVC = selectCallForwardingVC else {
            return
        }
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        self.navigationController?.pushViewController(callForwardingNumberVC, animated: true)
    }
    
    func logOutConfirmation(){
        
        let alertController = UIAlertController(title: "Log Out",  message: "Do you want to Log Out ?", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.default) { UIAlertAction in
            self.logOut()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) { UIAlertAction in

        }
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func logOut(){
        AppStateData.shared.logout()
        self.view.window?.rootViewController?.dismiss(animated: false, completion: { self.displayLandingScreen() })
    }
    
    //TODO: Move to Router
    func displayLandingScreen() {
        DispatchQueue.main.async {
            let viewController: HybridLoginViewController = HybridLoginViewController.build(with: .root)
            UIApplication.shared.keyWindow?.rootViewController = viewController
            UIApplication.shared.keyWindow?.makeKeyAndVisible()
        }
    }
    
    func callSupport() {
        guard let number = URL(string: "tel://" + "8589097343") else { return }
        UIApplication.shared.open(number)
    }
    
    func linkPressed(_ linkType: LinkType) {
        log.verbose(linkType)
        loadWebViewWith(LinkTypeManager.getServiceType(linkType: linkType))
    }
    
    func loadWebViewWith(_ service: Service) {
        DispatchQueue.main.async {
            let webViewController = WebViewViewController.buildWith(actionType: ActionType.webService, serviceType: service, and: "")
            self.navigationController?.pushViewController(webViewController, animated: true)
        }
    }
}

extension SettingsViewController: MFMailComposeViewControllerDelegate {
    
    func emailSupport() {
        print("🤖 emailSupport")
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients(["InvestorAppMailbox@lpl.com"])
            mail.setSubject("LPL Advisor Messages Support Request")
            mail.setMessageBody("<p>Test email from LPL Advisors Messaging App</p>", isHTML: true)
            present(mail, animated: true)
        } else {
            let alertController = UIAlertController(title: "Email Error", message: "Unable to send email, please make sure you have an email client on this device", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) { UIAlertAction in}
            alertController.addAction(okAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }

    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
    
}




