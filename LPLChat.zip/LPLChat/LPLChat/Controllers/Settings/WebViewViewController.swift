//
//  WebViewViewController.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/27/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import NVActivityIndicatorView


enum ActionType: String {
    // just throw link directly on webview
    case contentManaged = "contentManaged"
    
    // fetch raw string from web service
    case webService = "webService"
}

class WebViewViewController: UIViewController, NVActivityIndicatorViewable, BackButtonDelegate  {
    
    var leftBarButtonItem: UIBarButtonItem!
    
    @IBOutlet weak var webView: UIWebView!
    
    // current action will deide weather to fetch data from webservice, content managed url or raw string
    var type: ActionType?
    
    // api to call like Licensing, Terms of use
    var serviceType: Service!
    
    // url to load if any
    var urlString: String = ""
    
    class func buildWith(actionType: ActionType?,
                         serviceType: Service,
                         and urlString: String? = "") -> WebViewViewController {
        // fetch the view from storyboard
        let controller = "WebViewViewController"
        
        let storyBoard = UIStoryboard.init(name: controller,
                                           bundle: nil)
        
        let webViewController = storyBoard.instantiateViewController(withIdentifier: controller) as! WebViewViewController
        
        webViewController.type = actionType
        webViewController.serviceType = serviceType
        webViewController.urlString = urlString!
        
        return webViewController
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Terms Of Service"
        
        if (self.type == nil) {
            self.type = ActionType.webService
        }
        self.performOperationWRT(action: self.type!)
        
        let backButtonView = BackButtonView.buildWithDelegate(delegate: self)
        leftBarButtonItem = UIBarButtonItem(customView: backButtonView)
        self.navigationItem.leftBarButtonItem = leftBarButtonItem
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.barTintColor = .white
    }

    func performOperationWRT(action: ActionType) {
        switch action.rawValue {
            
        case ActionType.contentManaged.rawValue:
            self.loadContentManagedURL()
            
        case ActionType.webService.rawValue:
            self.fetchDataFromService()
            
        default:
            break
            // load the raw string directly on webview
//            self.webView.loadHTMLString(, baseURL: )
            
        }
    }
    
    func loadContentManagedURL() {
//        load this URL
//        self.webView.loadRequest(URL.init(string: urlString))
    }
    
    func fetchDataFromService() {
        
        // add loader
        self.addLoader()
        
        RawTextService.retriveRawDataFor(serviceType: self.serviceType) { (rawString) in
            
            DispatchQueue.main.async {
                
                // remove loader
                self.stopAnimating()
                self.webView.loadHTMLString(rawString.webViewCompatible(colorHex: "#000000"),
                                            baseURL: nil)
            }
        }
    }
    
    func addLoader() {
        let size = CGSize(width: 35,
                          height: 35)
        startAnimating(size,
                       message: "Loading...",
                       type: NVActivityIndicatorType.ballScaleRippleMultiple)
    }
    
    // MARK: - Service Methods
    
    
    // MARK: - Private Methods
    
    
    // MARK: - Back Button Delegate
    
    func backButtonPressAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
}
