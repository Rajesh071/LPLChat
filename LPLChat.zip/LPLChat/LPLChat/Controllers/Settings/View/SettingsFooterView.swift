//
//  SettingsFooterView.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class SettingsFooterView: UIView {

    @IBOutlet weak var uiLabelTitle: UILabel!
    
    class func build() -> SettingsFooterView {
        return SettingsFooterView.xibView() as! SettingsFooterView
    }
    
    func configure(info:VersionInfo){
        uiLabelTitle.text = "VERSION \(info.versionNumber).\(info.buildNumber) (\(info.env))"
        self.backgroundColor = .lPLLightGray
    }
}
