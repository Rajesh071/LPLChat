//
//  SettingsLinkTableViewCell.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class SettingsLinkTableViewCell: UITableViewCell {

    static let Id = "SettingsLinkTableViewCell"
    
    var vm : SettingsItemLinkViewModel?
    
    @IBOutlet weak var uiLabelTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(_ vm: SettingsItemLinkViewModel){
        self.vm = vm
        uiLabelTitle.text = vm.label
    }

    @IBAction func buttonTapped(_ sender: Any) {
        if let actionHandler = self.vm?.actionHandler{
            actionHandler((self.vm?.linkType)!)
        }
    }
}
