//
//  SettingsSectionHeaderView.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/17/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class SettingsSectionHeaderView: UITableViewHeaderFooterView {
    
    static let nibName = "SettingsSectionHeaderView"
    static let Id = "SettingsSectionHeaderView"
    
    @IBOutlet weak var labelTitle: UILabel!

    func configure(_ section: SettingsSection) {
        self.contentView.backgroundColor = .lPLLightGray
        labelTitle.text = section.sectionHeader
    }
}
