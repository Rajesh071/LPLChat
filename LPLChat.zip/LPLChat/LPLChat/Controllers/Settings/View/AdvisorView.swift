//
//  AdvisorView.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class AdvisorView: UIView {
    
    @IBOutlet weak var uiLabelVirtualNumber: UILabel!
    @IBOutlet weak var uiLabelName: UILabel!
    
    func configure(name:String?, virtualNumber:String){
        uiLabelName.text = name
        let unformattedPhoneNumber = ContactUtility.removeSpecialCharactersFromNumber(virtualNumber)
        let formattedNumber = CustomUtility.format(phoneNumber: unformattedPhoneNumber)
        uiLabelVirtualNumber.text = "My VBN:" + " " + formattedNumber
    }
}

//Build
extension AdvisorView {
    static let nibName = "AdvisorView"
    class func build() -> AdvisorView {
        return AdvisorView.xibView() as! AdvisorView
    }
}
