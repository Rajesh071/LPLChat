//
//  SettingsSwitchTableViewCell.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class SettingsFlagTableViewCell: UITableViewCell {

    static let Id = "SettingsFlagTableViewCell"
    
    var vm : SettingsItemFlagViewModel?
    
    @IBOutlet weak var uiSwitch: UISwitch!
    @IBOutlet weak var uiLabelTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(_ vm: SettingsItemFlagViewModel){
        self.vm = vm
        uiLabelTitle.text = vm.label
        uiSwitch.setOn(vm.value, animated: true)
    }
    
    @IBAction func switchToggled(_ sender: UISwitch) {
        if let actionHandler = self.vm?.actionHandler{
            actionHandler(sender.isOn)
        }
    }
    

}
