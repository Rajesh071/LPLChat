//
//  ChatDetailsViewController.swift
//  LPLChat
//
//  Created by Phillip English on 5/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import Photos
import CoreLocation
import NVActivityIndicatorView

enum chatDetailsSource {
    case chats
    case notification
    case profile
}

//This is so we can update the chat list with local data to show we've sent a message
protocol ChatDetailsDelegate: class {
    func didPost(newChat: ChatModel) 
}

class ChatDetailsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, 
    UITextFieldDelegate,  UINavigationControllerDelegate, UIImagePickerControllerDelegate,
CLLocationManagerDelegate, UISearchBarDelegate, NVActivityIndicatorViewable, TitleViewDelegates {
    
    //outlets
    @IBOutlet weak var headerIntialLbl: UILabel!
    @IBOutlet weak var nameTite: UILabel!
    
    @IBOutlet weak var chatTableView: UITableView!
    @IBOutlet var inputBar: UIView!
    @IBOutlet weak var headerContainer: UIView!
    @IBOutlet weak var headerView: TitleView!

    @IBOutlet var chatTextContainer: UIView!
    
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var headerImage: RoundedImageView!
    
    
//    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    
    //local vars
    var chatItems = [Message]()
    var chatSectionArray = [String]()
    var chatSortedDictionary = [String: [Message]]()
    var dateMessages:[DateMessage] = []
    
    let locationManager = CLLocationManager()
    //var chatItems = [Message]()
    let imagePicker = UIImagePickerController()
    let barHeight: CGFloat = 50
    var currentUser: User?
    var canSendLocation = true
    let textInputBar = ALTextInputBar()
    let keyboardObserver = ALKeyboardObservingView()
    public var chatModel: ChatModel?
    public var toNumber: String = ""
    public var toName: String?
    public var toNameInitials: String?
    var inputViewFrame: CGRect?
    var inputViewFrameWhenAppGoesToBackground: CGRect?
    var appWasPutInBackground = false
    var scrollOnLaunch: Bool = true
    //var isFromProfile :Bool = false
    var source: chatDetailsSource = .chats
    var viewModel = ChatDetailsViewModel()
    weak var delegate: ChatDetailsDelegate?
    
    var contactInfo: Contact?
    
    init(with phoneNumber: String) {
        self.toNumber = phoneNumber
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    override var inputAccessoryView: UIView? {
        get {
            return keyboardObserver
        }
    }
    
    override var canBecomeFirstResponder: Bool {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        
        
        //configureInputBar()
        configureNotificationObservers()
        //TODO: Rename this
        customization()
        
        viewModel.delegate = self
        viewModel.chatDetailsVMDelegate = self 
        viewModel.observeSilentPush()
        
        // fetch all chats by valid mobile number
        publicFetch()
        
        let notificationCenter = NotificationCenter.default
        notificationCenter.post(name: .chatListUpdateKey, object: nil)
        notificationCenter.addObserver(self, selector: #selector(appMovedToBackground), name: Notification.Name.UIApplicationWillResignActive, object: nil)
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    @objc func appMovedToBackground() {
        self.inputViewFrameWhenAppGoesToBackground = textInputBar.frame
        appWasPutInBackground = true
    }

    class func build(with smsData: SMSData?, isProfile: Bool) -> ChatDetailsViewController? {
        
        let controller = UIViewController.build(with: "Main", and: "ChatDetailsViewController") as? ChatDetailsViewController
        guard let viewController = controller else {
            return nil
        }

        return viewController
    }
    
//    @objc func msgStatusChanged(_ notification:Notification) {
//        let msgId = ""
//        let phoneNumber = ""
//        let msgStatusStr = ""
//
//        let msgStatus:MessageStatus = .delivered //ConvertToMessageStatus()
//
//        for dm in dateMessages {
//            if let dmmsgs = dm.messages{
//                for msg in dmmsgs{
//                    if msg.messageId == msgId{
//                        msg.msgStatus = msgStatus
//                        //update tablerow
//                        //find cell in table.
//                    }
//                }
//            }
//        }
//    }
    
    @objc func executeNotification(notification: NSNotification){
        print("notification fired")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        switch source {
        case .profile: 
            self.textInputBar.textView.becomeFirstResponder()
        default:
            break 
        }
        
        self.inputBar.backgroundColor = UIColor.clear
        self.view.layoutIfNeeded()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isHidden = true
        self.configureInputBar()
        self.configureNotificationObservers()
        configureTheTitleViewForNav()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        self.chatTableView.frame = view.bounds
        textInputBar.frame.size.width = view.bounds.size.width
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
        NotificationCenter.default.removeObserver(self)
        viewModel.removeObserver()
    }
    
    func configureClientID() {
        if let contact = self.contactInfo {
            if contact.clientID == nil {
                // fill the clientID from first message, all the messages have same id
                if viewModel.messages.count > 0 {
                    self.viewModel.clientID = viewModel.messages[0].clientID
                } else {
                    print("🛑 no client ID")
                    return
                }
            } else {
                self.viewModel.clientID = contact.clientID
            }
        }
    }
    
    func configureTheTitleViewForNav() {
     
        headerView = TitleView.buildWithDelegate(delegate: self)
        headerView.frame = self.headerContainer.bounds
        
        guard let contact = contactInfo else {
            return
        }
        
        headerView.titleLabel.text = contact.name
        // fix for showing initial
        if let initials = contact.initials , initials != "" {
            headerView.nameInitialLabel.text = initials
            headerView.nameInitialLabel.isHidden = false
            headerView.image.isHidden = true
        } else {
            headerView.nameInitialLabel.isHidden = true
            headerView.image.isHidden = false
        }

        self.headerContainer.addSubview(headerView)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        if segue.identifier == "profileFromChatDetails" {
            let viewController = segue.destination as! ProfileViewController
            
            if viewModel.messages.count > 0 {
                self.contactInfo?.clientID = viewModel.messages[0].clientID
            }
            viewController.profileViewModel.contact = self.contactInfo
            
            guard let name = headerView.titleLabel.text else { return }
            let (cw,ph) = ContactUtility.getClientWorksOrPhoneContact(toNumber,
                                                                      name:name)
            viewController.presentedFromChatDetails = true 
            if let cw = cw {
                viewController.cwContact = cw
                return
            }

            if let ph = ph {
                viewController.phoneContact = ph
                return
            }
        }
    }

    func alert(_ msg: String) {
        let alert = UIAlertController(title: "Info", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    private func configureNotificationObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardFrameChanged(notification:)), name: NSNotification.Name(rawValue: ALKeyboardFrameDidChangeNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardDidShow(_:)), name: NSNotification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardDidHide(_:)), name: NSNotification.Name.UIKeyboardDidHide, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(fetchData(_:)),
                                               name: Notification.Name.myNotificationKey, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(fetchData(_:)),
                                               name: .UIApplicationWillEnterForeground, object: UIApplication.shared)
    }
    
    func configureInputBar() {
        //let leftButton  = UIButton(frame: CGRect(x: 0, y: 0, width: 44, height: 44))
        let rightButton = UIButton(frame: CGRect(x: 0, y: 0, width: 44, height: 44))
        
        //leftButton.setImage(UIImage(named:"cameraIcon"), for: .normal)
        rightButton.setImage(UIImage(named:"sendImage"), for: .normal)
        rightButton.addTarget(self, action: #selector(ChatDetailsViewController.sendMessageOrSaveNote), for: .touchUpInside)
        keyboardObserver.isUserInteractionEnabled = false
        textInputBar.showTextViewBorder = true
        textInputBar.leftView = nil
        textInputBar.rightView = rightButton
        if appWasPutInBackground {
            if let frame = inputViewFrameWhenAppGoesToBackground {
                textInputBar.frame.origin.y = frame.minY
                textInputBar.textView.becomeFirstResponder()
            }
        } else {
            textInputBar.frame = CGRect(x: 0, y: view.frame.size.height - textInputBar.defaultHeight, width: view.frame.size.width, height: textInputBar.defaultHeight)
        }
        self.inputViewFrame = textInputBar.frame
        textInputBar.backgroundColor = UIColor(white: 0.95, alpha: 1)
        textInputBar.keyboardObserver = keyboardObserver
        
        view.addSubview(textInputBar)
        log.verbose("textInputBar added")
    }
    
    func customization() {
        
        self.imagePicker.delegate = self
        self.chatTableView.estimatedRowHeight = self.barHeight
        self.chatTableView.rowHeight = UITableViewAutomaticDimension
        self.chatTableView.contentInset.bottom = self.barHeight
        self.chatTableView.scrollIndicatorInsets.bottom = self.barHeight
        self.locationManager.delegate = self
        
        let tapper = UITapGestureRecognizer(target: self, action:#selector(endEditing))
        tapper.cancelsTouchesInView = false
        self.chatTableView.addGestureRecognizer(tapper)
    }
    
    @objc func endEditing() {
        self.textInputBar.textView.resignFirstResponder()
    }
    
    @objc func fetchData(_ notification : Notification) {
        self.publicFetch()
    }
    
    @objc func publicFetch() {
        var prependedNumber  =  ContactUtility.removeSpecialCharactersFromNumber(self.toNumber)
        if prependedNumber.utf16.count == 10 {
            prependedNumber = "1" + "\(prependedNumber)"
        }
        viewModel.fetchChatDetails(phoneNumber: prependedNumber)
    }

    @objc func keyboardDidShow(_ notification: NSNotification) {
        var info = notification.userInfo
        let frame = info![UIKeyboardFrameEndUserInfoKey] as! CGRect
        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, (frame.height), 0.0)
        self.chatTableView.contentInset = contentInsets
        self.chatTableView.scrollIndicatorInsets = contentInsets
        
        //TODO: Make this D.R.Y. by extracting to its own function - Phil
        guard viewModel.allMessages.count > 0 else {return}
        DispatchQueue.main.async {
            
            let lastRow: Int = self.chatTableView.numberOfRows(inSection: 0) - 1
            let indexPath = IndexPath(row: lastRow, section: 0)
            //self.chatTableView.scrollToRow(at: indexPath, at: .top, animated: true)
            self.chatTableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
        }
        
    }
    
    @objc func keyboardDidHide(_ notification: NSNotification) {
        UIView.animate(withDuration: 0.3, animations: {
            self.chatTableView.contentInset = .zero
            self.chatTableView.scrollIndicatorInsets = .zero
        })
        
    }
    
    
    @objc func keyboardFrameChanged(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let frame = userInfo[UIKeyboardFrameEndUserInfoKey] as! CGRect
            textInputBar.frame.origin.y = frame.origin.y
            
        }
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if notification.userInfo != nil {
            if self.chatItems.count > 0 {
                
            }
        }
        
        guard viewModel.allMessages.count > 0 else {return}
        DispatchQueue.main.async {
            
            let lastRow: Int = self.chatTableView.numberOfRows(inSection: 0) - 1
            let indexPath = IndexPath(row: lastRow, section: 0)
            self.chatTableView.scrollToRow(at: indexPath, at: .top, animated: false)
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if let userInfo = notification.userInfo {
            let frame = userInfo[UIKeyboardFrameEndUserInfoKey] as! CGRect
            textInputBar.frame.origin.y = frame.origin.y
            }
    }
    
    func checkLocationPermission() -> Bool {
        var state = false
        switch CLLocationManager.authorizationStatus() {
        case .authorizedWhenInUse:
            state = true
        case .authorizedAlways:
            state = true
        default: break
        }
        return state
    }
    
    func animateExtraButtons(toHide: Bool)  {
        switch toHide {
        case true:
            self.bottomConstraint.constant = 0
            UIView.animate(withDuration: 0.3) {
                self.inputBar.layoutIfNeeded()
            }
        default:
            self.bottomConstraint.constant = -50
            UIView.animate(withDuration: 0.3) {
                self.inputBar.layoutIfNeeded()
            }
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    private func formatDateString(from date: Date, messageString: String, fromSender: Bool) ->
        NSMutableAttributedString {
        var dateString: String
        var textColor: UIColor
        let paragraphStyle = NSMutableParagraphStyle()
        
            switch fromSender {
            case true:
                textColor = UIColor.white
                paragraphStyle.alignment = .right
            case false:
                textColor = UIColor.black
                paragraphStyle.alignment = .left
            }
        
        if Calendar.current.isDateInToday(date) {
            dateString = "\n \(date.toString(dateFormat: "h:mm a"))"
        } else {
            dateString = "\n \(date.toString(dateFormat: "E MMM d, h:mm a"))"
        }
        
        let dateStringAttributes: [NSAttributedStringKey: Any] = [
            .foregroundColor: UIColor.lightGray,
            .font: UIFont(name: "helvetica", size: 10.0)!,
            .paragraphStyle: paragraphStyle
        ]
        
        let messageStringAttributes: [NSAttributedStringKey: Any] = [
            .foregroundColor: textColor,
            .font: UIFont(name: "helvetica", size: 17.0)!,
            .paragraphStyle: paragraphStyle
        ]
        
        let mutableMessageString = NSMutableAttributedString(string: messageString,
                                                             attributes: messageStringAttributes)
        
        let mutableDateString = NSMutableAttributedString(string: dateString,
                                                          attributes: dateStringAttributes)
        mutableMessageString.append(mutableDateString)
        return mutableMessageString
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.allMessages.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let msg = viewModel.allMessages[indexPath.row]
        
        guard let currentType = msg?.messageType else {
            return UITableViewCell()
        }

        switch currentType {
        case .messageIn:
            
            guard let messageIn = msg as? MessageDetail else {
                return UITableViewCell()
            }
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "Receiver", for: indexPath) as! ReceiverCell
            cell.clearCellData()
            if let messageBody = messageIn.messageBody, let date = messageIn.messageDate {
                cell.message.attributedText =  formatDateString(from: date, messageString: messageBody, fromSender: false)
            }
            
            return cell
        case .messageOut:

            guard let messageOut = msg as? MessageDetail else {
                return UITableViewCell()
            }

            let cell = tableView.dequeueReusableCell(withIdentifier: "Sender", for: indexPath) as! SenderCell
            cell.clearCellData()
            if let messageBody = messageOut.messageBody, let date = messageOut.messageDate {
                cell.message.attributedText =  formatDateString(from: date, messageString: messageBody, fromSender: true)
            }
            if viewModel.isLastMessageOut(messageID: messageOut.messageId) {
                //TODO: Change name of label to status
                cell.uiLabelTime.text = messageOut.messageStatus
            }
            
            return cell
        case .advisorNote:
            
            guard let advisorNote = msg as? AdvisorNote else {
                return UITableViewCell()
            }

            let cell = tableView.dequeueReusableCell(withIdentifier: "NoteCell", for: indexPath) as! NoteCell
            
            if let dateString = advisorNote.dateString, let noteString = advisorNote.noteText {
                cell.configureCell(with: dateString, noteText: noteString)
            }
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.inputTextField.resignFirstResponder()
        
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
    }
    
    private func scrollToBottom() {
        guard self.viewModel.allMessages.count > 0 else {
            return
        }
        DispatchQueue.main.async {
            let indexPath = IndexPath(row: self.viewModel.allMessages.count - 1, section: 0)
            self.chatTableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
        }
    }
    
    //MARK: IBAction Methods
    @IBAction func backClicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func callClicked(_ sender: Any) {
        guard let toNumber = chatModel?.toNumber else {return}
        guard let number = URL(string: "tel://" + (toNumber)) else { return }
        UIApplication.shared.open(number)
    }
    
    @IBAction func showOptions(_ sender: Any) {
        
        self.animateExtraButtons(toHide: false)
        
    }
    
    @objc func sendMessageOrSaveNote() {
        
        guard let text = self.textInputBar.textView.text else {
            return
        }
        
        if (self.viewModel.savingType == .note) {
            if !text.hasWhiteSpaceOnly() {
                self.saveNote(with: text)
            }
        } else {
            self.sendMessage(with: text)
        }
    }
    
    private func sendMessage(with text: String) {
        
        if text.count > 0 {
            let messageText = self.textInputBar.textView.text ?? ""
            let messageTextFormatted = messageText.stringByRemovingEmoji()
            let fromNumber = Session.getUser()?.twilioNumber ?? ""
            let fromNumberFormatted = CustomUtility.removeFormatting(fromNumber)
            let receiverNumber = self.toNumber
            let receiverNumberFormatted = CustomUtility.removeFormatting(receiverNumber)
            //TODO: Do we need a full name or do we send "Advisor?"
            let fromName = KeychainUtility.retrieveCredentials()?.userName ?? "name not available"
            
            //Create a dummy message model to display until we get backend update. The ChatID can't be nil, because we need it for equatability/hashability, but we send it as 0 and then filter for 0 id.
            //                if viewModel.messages.count == 0 {
            //                    let uniqueID = UUID()
            //                    let timeUTCString = (String(describing: Date()))
            //                    let chat = ChatModel(chatId: "0", messageId: uniqueID.uuidString, fromNumber: fromNumber, toNumber: receiverNumber, toName: ContactUtility.mapName(to: receiverNumber), time: timeUTCString, body: timeUTCString, totalUnread: 0, hasUnread: false)
            //                    delegate?.didPost(newChat: chat)
            //
            //                }
            
            viewModel.postMsg(fromNumber: NumberUtil.add1OrPlus1ToValidNumber(fromNumberFormatted),
                              fromName: fromName,
                              receiverNumber: NumberUtil.add1OrPlus1ToValidNumber(receiverNumberFormatted),
                              messageText: messageTextFormatted)
//            headerView.activityView.isHidden = false
            headerView.noteView.isHidden = true
            self.textInputBar.textView.text = ""
            self.textInputBar.textView.textViewDidChange()
        }
    }
    
    private func saveNote(with text: String) {
        
        if let contact = self.contactInfo {
            if contact.clientID == nil {
                // fill the clientID from first message, all the messages have same id
                if viewModel.messages.count > 0 {
                    self.contactInfo?.clientID = viewModel.messages[0].clientID
                } else {
                    // there is no clientID
                    print("🛑 Without client ID we can't save note")
                    AlertUtil.showAlert(with: "", message: "Sorry, request can't be completed this time", onController: self)
                    
                    return
                }
            }
        }
        print("🛑 client ID = \(String(describing: self.contactInfo?.clientID))")
        
        let note = Note(noteText: self.textInputBar.text, investorName: self.contactInfo?.name, clientId: self.contactInfo?.clientID)
        
        headerView.activityView.isHidden = false
        headerView.noteView.isHidden = true
        
        self.viewModel.save(note: note) { (result) in
            
            self.showActivityIndicator(value: false)
            
            switch result {
            case .success(_):
                DispatchQueue.main.async {
                    self.headerView.notesButton.isSelected = !self.headerView.notesButton.isSelected
                    self.configureNotesUI()
                    self.viewModel.fetchNotes()
                }
            case let .failure(error):
                print(error)
            }
        }
    }
    
    private func showActivityIndicator(value: Bool) {
        DispatchQueue.main.async {
            self.headerView.activityView.isHidden = !value
            
            // display notes option if the contact is a clientworks contact else never display this option.
            if let contact = self.contactInfo {
                if contact.contactType == .clientWorks {
                    self.headerView.noteView.isHidden = value
                } else {
                    self.headerView.noteView.isHidden = true
                }
            }
        }
    }
    
    @IBAction func showMessage(_ sender: Any) {
        
        self.animateExtraButtons(toHide: true)
        
    }
    
    //MARK : - Search Protocol
    
    internal func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool{
        
        searchBar.resignFirstResponder()
        return true 
    }
    
    internal func searchBarTextDidEndEditing(_ searchBar: UISearchBar){
        
        searchBar.resignFirstResponder()
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar){
        
        searchBar.resignFirstResponder()
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    
    
    // MARK: - Titleview Delegates
    
    func backButtonPressed() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func profilePressed() {
        self.performSegue(withIdentifier: "profileFromChatDetails",
                          sender: nil)
    }
    
    func noteButtonPressed() {
        self.configureNotesUI()
    }
    
    func configureNotesUI() {
        
        self.textInputBar.textView.text = ""

        if self.viewModel.savingType == .note {
            self.viewModel.savingType = .message
            self.textInputBar.currentType = .message
            self.textInputBar.textView.placeholder = "Type Messages"
        } else {
            self.viewModel.savingType = .note
            self.textInputBar.currentType = .note
            self.textInputBar.textView.placeholder = "Type Notes"
            self.textInputBar.textView.becomeFirstResponder()
        }
        self.textInputBar.textView.textViewDidChange()
    }
    
}


extension ChatDetailsViewController: ViewModelDelegate {
    func viewModelDidSetData() {
        DispatchQueue.main.async {
            self.chatTableView.reloadData()
            self.scrollToBottom()
        }
    }
    
    func viewModelDidFinishOperation() {
        self.showActivityIndicator(value: false)
        DispatchQueue.main.async {
            self.chatTableView.reloadData()
        }
    }
    
    func viewModelDidThrowError(error: Error) {
        //TODO: - Find and implement expected means of handling this error
        print(error)
        self.showActivityIndicator(value: false)
    }
    
    func updateTabBarItemBadge(unreadMessages: Int) {
    
    }
}

extension ChatDetailsViewController: ChatDetailsViewModelDelegate {
    func viewModelDidPostMessage() {
        DispatchQueue.global().asyncAfter(deadline: .now() + 4) {
            self.publicFetch()
        }
    }
}

