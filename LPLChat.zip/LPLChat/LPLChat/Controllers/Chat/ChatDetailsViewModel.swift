//
//  ChatDetailsViewModel.swift
//  LPLMessages
//
//  Created by Phillip English on 5/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum SavingTypeEnum {
    case message
    case note
}

final class ChatDetailsViewModel {
    
    weak var delegate: ViewModelDelegate?
    weak var chatDetailsVMDelegate: ChatDetailsViewModelDelegate?
    var savingType: SavingTypeEnum = .message

    var clientID: String?
    var notes: [AdvisorNote] = []
    
    private var statusCallCounter: Int = 0
    
    private(set) var allMessages: [ChatDetailsDataType?] = [] {
        didSet {
            DispatchQueue.main.async {
                self.delegate?.viewModelDidFinishOperation()
                self.delegate?.viewModelDidSetData()
            }
        }
    }
    
    private(set) var messages: [MessageDetail] = []
    
    func observeSilentPush() {
        NotificationCenter.default.addObserver(self, selector: #selector(updateDeliveryStatusFromPush(notification:)),
                                               name: Notification.Name.silentPushNotificationKey, object: nil)
    }
    
    func removeObserver() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func updateDeliveryStatusFromPush(notification: NSNotification) {
        guard let userInfo = notification.userInfo else {return}
        guard let id = userInfo["identifier"] as? String else {return}
        guard let status = userInfo["status"] as? String else {return}
        let filteredMessages = messages.filter{$0.messageId == id}
        if let messageWithID = filteredMessages.first {
            if status == "delivered" || status == "failed" {
            messageWithID.messageStatus = status
            delegate?.viewModelDidFinishOperation()
            }
        }
    }
    
    func isLastMessageOut(messageID: String) -> Bool {
        let senderMessages = messages.filter{$0.messageType == .messageOut}
        if senderMessages.last?.messageId == messageID {
            return true
        } else {
            return false 
        }
    }
    
    private func updateLastSentMessageStatus(flattennedMessageArray: [MessageDetail]) {
        let flatSenderMessages = flattennedMessageArray.filter{$0.messageType == .messageOut}
        guard let lastMessage = flatSenderMessages.last else {return}
        let filteredMessages = messages.filter{$0.messageId == lastMessage.messageId}
        guard let messageToUpdate = filteredMessages.first else {return}
        
        if lastMessage.messageStatus == nil && statusCallCounter < 4 {
            statusCallCounter += 1
            chatDetailsVMDelegate?.viewModelDidPostMessage()
            return
        }

        if lastMessage.messageStatus == "queued" && statusCallCounter < 4 {
            statusCallCounter += 1
            chatDetailsVMDelegate?.viewModelDidPostMessage()
            return
        }
        
        if lastMessage.messageStatus == "delivered" || lastMessage.messageStatus == "failed" {
        messageToUpdate.messageStatus = lastMessage.messageStatus
        }
        
        
        statusCallCounter = 0 
    }
    
    //private var chatDetails: [ChatDetails] = []
    
    private func formatMessagesCollection(from chatCollection: [ChatDetails]?) {
        guard let chatCollection = chatCollection else {return}
        var messagesToAppend: [[MessageDetail]] = []
        
        for chatDetail in chatCollection {
            messagesToAppend.append(chatDetail.messages)
        }
        var flattenedMessageArray = messagesToAppend.flatMap{$0}
        flattenedMessageArray.sort(by: {$0.messageDate?.compare($1.messageDate!) == .orderedAscending})
        if flattenedMessageArray.last == messages.last {
            updateLastSentMessageStatus(flattennedMessageArray: flattenedMessageArray)
            self.delegate?.viewModelDidFinishOperation()
            return}
        
        //let filteredMessages = messages.filter{$0.messageId != "0"}
        let messagesToSort = Set(messages + flattenedMessageArray).sorted(by: {$0.messageDate?.compare($1.messageDate!) == .orderedAscending})
        
        messages = messagesToSort
    }
    
    private func addLocalMessage(fromNumber: String, fromName: String, receiverNumber: String, messageText: String, id: String) {
        let dateString = Date().toISO8601String()
        //set temp internal msg id - until server returns back actual msg id
        //let internalMessageId = UUID().uuidString
        let message = MessageDetail(messageType: .messageOut, messageId: id, messageDateString: dateString, messageBody: messageText, messageToNumber: receiverNumber, messageToName: nil, messageFromName: nil, messageFromNumber: fromNumber, messageIsRead: nil, messageStatus: "Sent", timezone: nil, statusTime: "time", clientid: "")
        messages.append(message)
        //Cache the message so we have it locally
        //ChatDetailsCache.shared.cache
    }
    
    func postMsg(fromNumber: String, fromName: String, receiverNumber: String, messageText: String) {
        
        RemoteDataManager.postChatMessage(fromNumber, fromName: fromName, receiverNumber: receiverNumber, messageText: messageText) { (result) in
            switch result {
            case let .success(responseData):
                //MessageID comes to us as a single string keyed by "data". No need for decoding, just parse the string
                do {
                    let stringDic = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String : Any]
                    guard let id = stringDic!["data"] as? String else {return}
                    print("********MESSAGEID********:::::::::: \(id)")
                    self.addLocalMessage(fromNumber: fromNumber, fromName: fromName, receiverNumber: receiverNumber, messageText: messageText, id: id)
                    NotificationCenter.default.post(name: .chatListUpdateKey, object: nil)
                    self.chatDetailsVMDelegate?.viewModelDidPostMessage()
                } catch let error {
                    self.delegate?.viewModelDidThrowError(error: error)
                }

            case let .failure(error):
                self.delegate?.viewModelDidThrowError(error: error)
            }
        }
    }
    
    //TODO: make single generic and DRY decoding at this level if possible - PE
    private func decodeResponseData(data: Data) -> [PostChatResponse]? {
        let decoder = JSONDecoder()
        do {
            let serviceResponse =  try
                decoder.decode(ServiceResponseCodable<[PostChatResponse]>.self, from: data)
            
            if let postChatResponse = serviceResponse.data {
                return postChatResponse
            }
        } catch let error {
            delegate?.viewModelDidThrowError(error: error)
        }
        return nil
    }
    
    private func decodeChatData(data: Data) {
        let decoder = JSONDecoder()
        do {
            let serviceResponse =  try decoder.decode(ServiceResponseCodable<[ChatDetails]>.self, from: data)
            if let decodedChat = serviceResponse.data {
                self.formatMessagesCollection(from: decodedChat)
            }
        } catch let error {
            delegate?.viewModelDidThrowError(error: error)
        }
    }
    
    //TODO: handle pagination
    func fetchChatDetails(phoneNumber: String, pageNo: Int = 1, pageSize: Int = 10000) {
        
        RemoteDataManager.retrieveChatDetails(phoneNumber, pageNo: pageNo, pageSize: pageSize) { (result) in
            switch result {
            case let .success(chatCollection):
                self.decodeChatData(data: chatCollection)
                if self.messages.count > 0 {
                    self.clientID = self.messages[0].clientID
                }
                if self.clientID == "0" || self.clientID == "" {
                    self.allMessages = self.messages
                } else {
                    self.fetchNotes()
                }
            case .failure(_):
                self.fetchNotes()
            }
//            for (index, message) in self.allMessages.enumerated() {
//                if let messageDetail = message as? MessageDetail, messageDetail.messageId == "007" {
//                    self.allMessages.remove(at: index)
//                    print("🤖 messageID = \(messageDetail.messageId): messageBody = \(String(describing: messageDetail.messageBody))")
 //            }
        }
    }
    
    func save(note: Note, completionHandler: @escaping GenericCompletionHandler<Int>) {
        ServiceManager.save(note: note, completionHandler)
    }
    
    func fetchNotes() {
        
        guard let clientID = self.clientID else {
            return
        }

        ServiceManager.fetchNotes(with: clientID, pageNumber: 1, pageSize: 200) { (result) in
            switch result {
            case let .success(value):
                guard let value = value else {
                    return
                }
                self.notes = value
                self.mergeMessageAndNotesData()
                
            case let .failure(error):
                self.delegate?.viewModelDidThrowError(error: error)
                print(error)
            }
        }
    }
    
    func mergeMessageAndNotesData() {
        
        var allElements: [ChatDetailsDataType] = []
        
        allElements.append(contentsOf: messages)
        allElements.append(contentsOf: notes)
        self.allMessages = allElements.sorted { ($0.messageDate! < $1.messageDate!)}
    }
    
}
