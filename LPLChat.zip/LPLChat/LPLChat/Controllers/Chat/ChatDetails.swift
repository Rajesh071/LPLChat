//
//  ChatDetails.swift
//  LPLMessages
//
//  Created by Phillip English on 5/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum MessageSenderType: String, Codable {
    case messageOut = "MESSAGE_OUT"
    case messageIn = "MESSAGE_IN"
    case advisorNote = "ADVISOR_NOTE"
}

//enum MessageStatus: String {
//    case delivered = "Delivered"
//    case failed = "Failed"
//}

protocol ChatDetailsDataType {
    var messageType: MessageSenderType? {get set}
    var messageDate: Date? {get}
}
    
struct ChatDetails: Codable {
    //Should know the sender and to whom
    let date: String
    let messageCount: String
    let messages: [MessageDetail]
    
    private enum CodingKeys: String, CodingKey {
        case date = "Date"
        case messages = "Message"
        case messageCount = "messageCount"
    }
}

final class MessageDetail: Codable, Hashable, Comparable, ChatDetailsDataType {
    var messageDate: Date?
    
    var messageType: MessageSenderType?
    
    var hashValue: Int {
        //create hash value using bitwise XOR operation from unique propertiesx
    return messageId.hashValue ^ messageDateString.hashValue
    }
    
    let messageId: String
    let messageDateString: String
    let messageBody: String?
    let messageBodyFormatted: String?
    let messageToNumber: String?
    let messageToName: String?
    let messageFromNumber: String?
    let messageFromName: String?
    let messageIsRead: Bool?
    var messageStatus: String?
    let timezone: String?
    let statusTime: String?
    let clientID: String?
    
    private enum CodingKeys: String, CodingKey {
        case messageType = "messageType"
        case messageId = "messageId"
        case messageDateString = "messageDate"
        case messageBody = "messageBody"
        case messageToNumber = "messageToNumber"
        case messageToName = "messageToName"
        case messageFromNumber = "messageFromNumber"
        case messageFromName = "messageFromName"
        case messageIsRead = "messageIsRead"
        case messageStatus = "messageStatus"
        case timezone = "timezone"
        case statusTime = "statustime"
        case clientID = "clientid"
    }
    
    init(messageType: MessageSenderType, messageId: String, messageDateString: String, messageBody: String?, messageToNumber: String?, messageToName: String?, messageFromName: String?, messageFromNumber: String?, messageIsRead: Bool?, messageStatus: String?, timezone: String?, statusTime: String?, clientid: String?) {
        self.messageType = messageType
        self.messageId = messageId
        self.messageDateString = messageDateString
        self.messageBody = messageBody
        self.messageDate = messageDateString.convertToDate()
        self.messageBodyFormatted = messageBody?.stringByRemovingEmoji()
        self.messageToNumber = messageToNumber
        self.messageToName = messageToName
        self.messageFromNumber = messageFromNumber
        self.messageFromName = messageFromName
        self.messageIsRead = messageIsRead
        self.messageStatus = messageStatus
        self.timezone = timezone
        self.statusTime = statusTime
        self.clientID = clientid
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        messageType = try container.decode(MessageSenderType.self, forKey: .messageType)
        messageId = try container.decode(String.self, forKey: .messageId)
        messageBody = try container.decode(String.self, forKey: .messageBody)
        messageDateString = try container.decode(String.self, forKey: .messageDateString)
        messageToNumber = try container.decode(String.self, forKey: .messageToNumber)
        messageToName = try container.decode(String.self, forKey: .messageToName)
        messageFromNumber = try container.decode(String.self, forKey: .messageFromNumber)
        messageFromName = try container.decode(String.self, forKey: .messageFromName)
        messageIsRead = try container.decode(Bool.self, forKey: .messageIsRead)
        messageStatus = try container.decode(String.self, forKey: .messageStatus)
        timezone = try container.decode(String.self, forKey: .timezone)
        statusTime = try container.decode(String.self, forKey: .statusTime)
        clientID = try container.decode(String.self, forKey: .clientID)
        messageDate = messageDateString.convertToDate()
        messageBodyFormatted = messageBody?.stringByRemovingEmoji()
    }
    
    static func == (lhs: MessageDetail, rhs: MessageDetail) -> Bool {
        return lhs.messageId == rhs.messageId
    }
    
    static func < (lhs: MessageDetail, rhs: MessageDetail) -> Bool {
        return lhs.messageDate! < rhs.messageDate!
    }
    
}

struct ChatCollection<T: Codable> {
    var chats: [T]?
}
