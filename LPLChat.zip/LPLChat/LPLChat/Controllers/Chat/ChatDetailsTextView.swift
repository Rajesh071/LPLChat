//
//  ChatDetailsTextView.swift
//  LPLMessages 
//
//  Created by Phillip English on 6/21/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import Foundation

class ChatDetailsTextView: UITextView {

    override public func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return false
    }
}


