//
//  PostChatResponse.swift
//  LPLMessages
//
//  Created by Phillip English on 5/20/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct PostChatResponse: Codable {
//    "sid": “D5D79C10-BA75-408E-95DB-81B9DFC77FCA”,
//    "status": “queued”,
//    "message": “test”
    let sid: String?
    let status: String?
    let message: String?

}
