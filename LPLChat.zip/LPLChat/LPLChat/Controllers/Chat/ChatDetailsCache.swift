//
//  ChatDetailsCache.swift
//  LPLMessages
//
//  Created by Phillip English on 5/21/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct ChatDetailsCache {
    static let shared = ChatDetailsCache()
    
    var cache = NSCache<NSString, MessageDetail>()
}
