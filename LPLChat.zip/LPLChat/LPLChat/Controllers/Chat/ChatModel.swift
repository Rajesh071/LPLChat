//
//  ChatModel.swift
//  LPLMessages
//
//  Created by Phillip English on 5/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
/*
 {
 "chatId": "271aae5a-aecd-4242-9b23-e78f16044b5b",
 "messageId": "45e89745-ac05-469f-b374-924fb85b97ee",
 "fromNumber": "+1 (602) 491-0539",
 "toNumber": "+1 (321) 615-4362",
 "toName": "NA",
 "time": "2018-05-17T15:41:11.873",
 "body": "Hello again ",
 "totalUnread": 0
 },
 */

struct ChatModel: Codable, Hashable {
    var hashValue: Int {
        //create hash value using bitwise XOR operation from unique properties
        return chatId.hashValue ^ messageId.hashValue
    }
    
    let chatId: String
    let messageId: String
    let fromNumber: String?
    let toNumber: String?
    let toName: String?
    let time: String
    let timeDate: Date
    let body: String?
    let totalUnread: Int
    let hasUnread: Bool
    
    var contactType: ContactTypeEnum {
        get {
            guard let name = toName else {
                return .unknown
            }
            if name.elementsEqual("NA") {
                return .unknown
            } else {
                return .clientWorks
            }
        }
    }
    
    private enum CodingKeys: String, CodingKey {
        case chatId = "chatId"
        case messageId = "messageId"
        case fromNumber = "fromNumber"
        case toNumber = "toNumber"
        case toName = "toName"
        case time = "time"
        case body = "body"
        case totalUnread = "totalUnread"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        chatId = try container.decode(String.self, forKey: .chatId)
        messageId = try container.decode(String.self, forKey: .messageId)
        fromNumber = try container.decode(String.self, forKey: .fromNumber)
        toNumber = try container.decode(String.self, forKey: .toNumber)
        toName = try container.decode(String.self, forKey: .toName)
        time = try container.decode(String.self, forKey: .time)
        timeDate = time.convertToDate()
        body = try container.decode(String.self, forKey: .body)
        totalUnread = try container.decode(Int.self, forKey: .totalUnread)
        if totalUnread > 0 {
            hasUnread = true
        } else {
            hasUnread = false
        }
        
    }
    
    init(chatId: String = "0", messageId: String, fromNumber: String, toNumber: String, toName: String, time: String, body: String, totalUnread: Int = 1, hasUnread: Bool = true) {
        self.chatId = chatId
        self.messageId = messageId
        self.fromNumber = fromNumber
        self.toNumber = toNumber
        self.toName = toName
        self.time = time
        self.timeDate = time.convertToDate()
        self.body = body
        self.totalUnread = totalUnread
        self.hasUnread = hasUnread
    }
    
    static func == (lhs: ChatModel, rhs: ChatModel) -> Bool {
        return lhs.chatId == rhs.chatId && lhs.messageId == rhs.messageId
    }

}

struct CodableChatsCollection: Codable {
    let chat: [ChatModel]
    let messageCount: String
    
    private enum CodingKeys: String, CodingKey {
        case chat = "Chat"
        case messageCount = "messageCount"
    }
}

