//
//  ChatsViewController.swift
//  LPLChat
//
//  Created by Phillip English on 5/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import NVActivityIndicatorView

protocol MessagesNavigationDelegate {
    func didSelect(profile:Profile)
}

class ChatsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, NVActivityIndicatorViewable {
    
    @IBOutlet weak var chatsTable: UITableView!
    @IBOutlet weak var lplHeaderView: LPLHeaderView!
    
    var selectedToNumber: String?
    var isCallingSecondTime: Bool = false
    var chatDetailSource : chatDetailsSource = .chats
    let viewModel: ChatViewModel = ChatViewModel()
    var shouldShowSpinner = true
    var translucentNavigationBar = false
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var contactsVC: UIViewController?
    

    
    // MARK: - Factory Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        if self.navigationController != nil && self.navigationController!.navigationBar.isTranslucent {
            translucentNavigationBar = true
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        setUI()
        self.configureNotifications()
        self.updateDataFromService()
        if translucentNavigationBar {
            lplHeaderView.setYposition(offset: topDistance, height: topDistance, translucent: true)
        } else {
            lplHeaderView.setYposition(offset: topDistance, height: 0, translucent: false)
        }
    }
    
    
    // MARK - UI
    func setUI() {
        self.view.backgroundColor = .lPLLightGray
        setupNavigationBar()
        lplHeaderView.searchBar?.showsCancelButton = false
        setupChatsTable()
        customizeSearchBar()
    }

    func setupNavigationBar() {
        self.title = "Messages"
        self.navigationController?.navigationBar.barTintColor = .lPLLightGray
        self.navigationController?.navigationBar.tintColor = .lPLBlue1
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }

    func setupChatsTable() {
        chatsTable.backgroundColor = .clear
        self.chatsTable.isHidden = true
        self.chatsTable.tableFooterView = UIView()
    }
    
    func customizeSearchBar() {
        // SearchBar text
        let textFieldInsideUISearchBar = lplHeaderView.searchBar?.value(forKey: "searchField") as? UITextField
        textFieldInsideUISearchBar?.textColor = .lPLBlue4
        textFieldInsideUISearchBar?.font = textFieldInsideUISearchBar?.font?.withSize(14)
        
        // SearchBar placeholder
        let textFieldInsideUISearchBarLabel = textFieldInsideUISearchBar!.value(forKey: "placeholderLabel") as? UILabel
        textFieldInsideUISearchBarLabel?.textColor = .lPLMediumGray
        textFieldInsideUISearchBar?.font = textFieldInsideUISearchBar?.font?.withSize(14)
    }
    
    func configureNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(fetchDataFromService), name: .UIApplicationWillEnterForeground, object: UIApplication.shared)
        NotificationCenter.default.addObserver(self, selector: #selector(fetchDataFromService), name: Notification.Name.myNotificationKey, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateDataFromService), name: Notification.Name.chatListUpdateKey, object: nil)
    }
    
    @objc func updateDataFromService() {
        shouldShowSpinner = false
        fetchDataFromService()
    }
    
    @objc func fetchDataFromService()  {
        if shouldShowSpinner {
          Loader.shared.add(to: self.view)
        }
        viewModel.fetchChats()
        shouldShowSpinner = true
    }
    
   
    //MARK: - Tableview Delegates and Datasource
    
    internal func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        let sectionCount = index - 1
        if sectionCount < 0 {
            tableView.contentOffset = CGPoint(x: 0.0, y: -tableView.contentInset.top)
            return NSNotFound
        }
        return sectionCount
    }
    
    internal func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    internal func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return viewModel.chats.count
    }
    
    internal func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        //TODO: Clean up all these bangs - Phil
        let smsCell : MessagesTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "SMSCell", for: indexPath) as! MessagesTableViewCell)
        //Hide label when dequeing to prevent label slipping
        smsCell?.chatIntialLbl.isHidden = true
        smsCell?.customerView.isHidden = false 
        smsCell?.customerView.image =  UIImage(named: "ContactsIcon")
        let chat = viewModel.chats[indexPath.row]
        if var name = chat.toName {
            // If a contact name is not present in phone book treat is unkown
            if chat.contactType == .unknown, let number = chat.toNumber {
                name = ContactUtility.mapName(to: number)
            }
            smsCell?.nameLbl.text = name
            // set initials accrodingly
            let initials = ContactUtility.retrieveInitials(from: name)
            if initials.count > 0 {
                smsCell?.chatIntialLbl.isHidden = false
                smsCell?.customerView.isHidden = true
                smsCell?.chatIntialLbl.text = initials
            }
        } else {
            smsCell?.nameLbl.text = ""
        }
        if let body = chat.body {
            smsCell?.messageLbl.text = body
        } else {
            smsCell?.messageLbl.text = ""
        }
        if let messageLines = smsCell?.messageLbl.calculateMaxLines(), messageLines > 2 {
            smsCell?.messageLbl.numberOfLines = 1
            smsCell?.messageLbl.lineBreakMode = .byTruncatingTail
        } else {
            smsCell?.messageLbl.numberOfLines = 2
        }
//        print("🤖 smsCell?.messageLbl.text = \(String(describing: smsCell?.messageLbl.text))")
//        print("🤖 smsCell?.messageLbl number of lines = \(String(describing: smsCell?.messageLbl.calculateMaxLines()))")
//        print("🤖 -------------------------------------------- ")
        smsCell?.timeLbl.text = chat.timeDate.ConvertDateToReadableString()
        smsCell?.unreadCountLabel.text = String(chat.totalUnread)
        switch chat.hasUnread {
        case true:
            smsCell?.unreadCountLabel.isHidden = false
            smsCell?.blueCircleView?.isHidden = false
            smsCell?.blueCircleView?.layer.cornerRadius = 11
            smsCell?.unreadCountLabel.text = String(chat.totalUnread)
            if chat.totalUnread > 99 {
                smsCell?.unreadCountLabel.text = "99+"
            } else if chat.totalUnread > 9 {
                smsCell?.blueCircleView?.layer.cornerRadius = 10
            }
        case false:
            smsCell?.unreadCountLabel.isHidden = true
            smsCell?.blueCircleView?.isHidden = true
        }
        return smsCell!
    }
    
    internal func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        self.selectedToNumber = viewModel.chats[indexPath.row].toNumber //self.latestSMSData[rowCount]
        let contact = self.viewModel.prepareContactInfoFrom(chat: self.viewModel.chats[indexPath.row])
        goToChatDetails(from: .chats, contactInfo: contact)
    }
    
    func goToChatDetails(from source:chatDetailsSource, contactInfo:Contact? = nil){
        guard let toNumber = selectedToNumber else {
            return
        }
        DispatchQueue.main.async {
            let controller = UIViewController.build(with: "Main", and: "ChatDetailsViewController") as? ChatDetailsViewController
            guard let viewController = controller else {
                return
            }
            viewController.contactInfo = contactInfo
            viewController.toNumber = toNumber
            viewController.delegate = self.viewModel
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    
    // MARK: - SearchBar delegates
    internal func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool{
        searchBar.resignFirstResponder()
        return true
    }
    
    internal func searchBarTextDidEndEditing(_ searchBar: UISearchBar){
        searchBar.resignFirstResponder()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar){
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        print("🤖 searchText = \(searchText)")
        searchChats(searchText)
    }

    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
        // ❕TODO: Why are we searching when the cancel button is clicked?
        searchChats("")
        lplHeaderView.searchBar?.text = ""
        lplHeaderView.searchBar?.resignFirstResponder()
    }
    
    //TODO: This logic is a quickfix for search. It is not truly MVVM. Extract data manipulation to the viewmodel to conform to MVVM. Further, there's probably a more ellegant, less costly solution than copying the entire array - Phil
    func searchChats(_ searchString: String) {
        if searchString == "" {
            if let fullChats = viewModel.fullChatHolder {
                viewModel.chats = fullChats
            }
        }
        else{
            //TODO: also expensive- move the toName mapping to the model itself
            viewModel.chats = viewModel.chats.filter{$0.toNumber != nil}.filter{ContactUtility.mapName(to: $0.toNumber!).contains(searchString)}
        }
        DispatchQueue.main.async {
            self.chatsTable.reloadData()
        }
    }
}

//MARK: - MessagesNavigationDelegate implementation
extension ChatsViewController : MessagesNavigationDelegate {
    //MARK: MessagesNavigationDelegate implementation
    func didSelect(profile:Profile) {
        if profile.phoneNumbers.count >= 1 {
            self.contactsVC?.dismiss(animated: false, completion: nil)
            self.performSegue(withIdentifier: "chatDetails", sender: self)
        } else {
            log.error("no number")
            AlertUtil.showAlert(with: "Error", message: "Contact does not have any phone number")
        }
    }
    
    func showContactsSelector(segue: UIStoryboardSegue){
        let nav = segue.destination as! UINavigationController
        let contactsVC = nav.childViewControllers[0] as! ContactsViewController
        contactsVC.setNewMessageMode()
        self.contactsVC = contactsVC
        contactsVC.msgsNavigationDelegate = self
    }
}

// MARK: - ViewModelDelegate
extension ChatsViewController: ViewModelDelegate {
    func viewModelDidSetData() {
        self.chatsTable.reloadData()
        self.chatsTable.isHidden = false
        Loader.shared.remove()
    }
    
    func viewModelDidFinishOperation() {
        Loader.shared.remove()
    }
    
    func viewModelDidThrowError(error: Error) {
        Loader.shared.remove()
        print(error)
    }
    
    func updateTabBarItemBadge(unreadMessages: Int) {
        if unreadMessages > 0 {
            DispatchQueue.main.async {
                if let tabItems = self.tabBarController?.tabBar.items as NSArray?
                {
                    // In this case we want to modify the badge number of the third tab:
                    let tabItem = tabItems[0] as! UITabBarItem
                    
                    if unreadMessages > 99 {
                         tabItem.badgeValue = "99+"
                    } else  {
                        tabItem.badgeValue = "\(unreadMessages)"
                    }
                }
            }
        } else if unreadMessages == 0 {
            DispatchQueue.main.async {
                if let tabItems = self.tabBarController?.tabBar.items as NSArray?
                {
                    // In this case we want to modify the badge number of the third tab:
                    let tabItem = tabItems[0] as! UITabBarItem
                    tabItem.badgeValue = nil
                }
            }
        }
    }
}

// MARK: - Scrolling
extension ChatsViewController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        view.endEditing(true)
        if scrollView == chatsTable {
            let offset = scrollView.contentOffset.y
            if translucentNavigationBar {
                lplHeaderView.setYposition(offset: 0, height: topDistance, translucent: true)
            } else {
                lplHeaderView.setYposition(offset: offset, height: 0, translucent: false)
            }
        }
    }
    
    public var topDistance: CGFloat{
        get{
            if translucentNavigationBar {
                if let height = self.navigationController?.navigationBar.frame.size.height {
                    return height
                } else {
                    return 0
                }
            } else {
                return 0
            }
        }
    }
    
}
