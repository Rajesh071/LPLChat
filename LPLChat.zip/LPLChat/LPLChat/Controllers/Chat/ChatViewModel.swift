    //
//  ChatViewModel.swift
//  LPLMessages
//
//  Created by Phillip English on 5/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
    

final class ChatViewModel {
    
    weak var delegate: ViewModelDelegate?
    var fullChatHolder: [ChatModel]?
     var chats: [ChatModel] = [] {
        didSet {
            DispatchQueue.main.async {
                self.delegate?.viewModelDidSetData()
            }
        }
    }
    
    func decodeDataAndUpdateChats(data: Data) {
        let decoder = JSONDecoder()
        do {
            let serviceResponse =  try decoder.decode(ServiceResponseCodable<CodableChatsCollection>.self, from: data)
            if let decodedChat = serviceResponse.data?.chat {
                
//                guard decodedChat.last != chats.last else {
//                    self.delegate?.viewModelDidFinishOperation()
//                    return}
                //TODO: fix Set creation to allow for updating a pre-existing chat with new unread count - PE
                //self.chats = self.chats.filter({$0.chatId == "0"})
               // var arrayToSort = Array(Set(self.chats + decodedChat))
                //arrayToSort.sort(by: {$0.timeDate.compare($1.timeDate) == .orderedDescending})
                
                //self.chats = arrayToSort
                self.chats = decodedChat
                self.fullChatHolder = self.chats
                Session.unreadMessagesInTheApp = calculateAllUnreadMessagesInApp(chatsArray: self.chats)
            }
        } catch let error {
            delegate?.viewModelDidThrowError(error: error)
        }
    }
    
    func fetchChats(pageNo: Int = 1, pageSize: Int = 100) {
        RemoteDataManager.retrieveChatsAll(pageNo, pageSize: pageSize) { (result) in
            
            switch result {
            case .success(let chatData):
                self.decodeDataAndUpdateChats(data: chatData)
                
            case .failure(let error):
                self.delegate?.viewModelDidThrowError(error: error)
            }
            
        }
    }
    
    func calculateAllUnreadMessagesInApp(chatsArray: [ChatModel]) -> Int {
        var appUnreadMessageTotal = 0
        for chatModel in chatsArray {
            appUnreadMessageTotal += chatModel.totalUnread
        }
        UserDefaults.init(suiteName: Constants.appGroup)?.setValue(appUnreadMessageTotal, forKey: Constants.appBadgeCount)
        delegate?.updateTabBarItemBadge(unreadMessages: appUnreadMessageTotal)
        return appUnreadMessageTotal
    }
    
    func prepareContactInfoFrom(chat: ChatModel) -> Contact {
        
        var contactName: String = ""
        
        if chat.contactType == .unknown {
            if let phoneNumber = chat.toNumber {
                contactName = ContactUtility.mapName(to: phoneNumber)
            }
        } else {
            if let name = chat.toName {
                contactName = name
            }
        }
        
        var contactNumber: String = ""
        if let phoneNumber = chat.toNumber {
            contactNumber = phoneNumber
        }
        
        return Contact(contactName: contactName,
                              contactNumber: contactNumber,
                              contactType: chat.contactType,
                              clientID: nil)
    }
    
}

extension ChatViewModel: ChatDetailsDelegate {
    func didPost(newChat: ChatModel) {
        chats.append(newChat)
    }
    
}
