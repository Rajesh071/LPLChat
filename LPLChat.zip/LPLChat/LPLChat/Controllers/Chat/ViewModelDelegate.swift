//
//  ViewModelDelegate.swift
//  LPLMessages
//
//  Created by Phillip English on 5/15/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

protocol ChatDetailsViewModelDelegate: class {
    func viewModelDidPostMessage() 
}

protocol ViewModelDelegate: class {
    func viewModelDidFinishOperation()
    func viewModelDidSetData()
    func viewModelDidThrowError(error: Error)
    func updateTabBarItemBadge(unreadMessages: Int)
}
