//
//  GenericHeaderView.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/18/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit


class GenericHeaderView: UIView {

    @IBOutlet weak var titleLabel: UILabel!
    
    class func build(with title: String,
                     textAlignment: NSTextAlignment? = NSTextAlignment.left) -> GenericHeaderView {
        let genericView = GenericHeaderView.xibView() as! GenericHeaderView
        genericView.titleLabel.text = title
        genericView.titleLabel.textAlignment = textAlignment!

        return genericView
    }
    
    func configure(with title: String,
                   textAlignment: NSTextAlignment? = NSTextAlignment.left) {
        self.titleLabel.text = title
        self.titleLabel.textAlignment = textAlignment!
    }

}
