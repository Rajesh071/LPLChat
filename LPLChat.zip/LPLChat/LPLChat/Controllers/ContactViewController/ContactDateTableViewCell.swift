//
//  ContactDateTableViewCell.swift
//  LPLMessages
//
//  Created by Kent Franks on 7/3/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class ContactDateTableViewCell: UITableViewCell {

    @IBOutlet weak var dateType: UILabel!
    @IBOutlet weak var dateValue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    func configureCellWith(profile: Profile?, indexPath: IndexPath) -> ContactDateTableViewCell{
        switch indexPath.row {
        case 0:
            if let profile = profile, let birthday = profile.birthday {
                self.dateType.text = DateType.birthday.rawValue
                self.dateValue.text = birthday
            } else if let profile = profile, let anniversary = profile.anniversary {
                self.dateType.text = DateType.anniversary.rawValue
                self.dateValue.text = anniversary
            }
        case 1:
            if let profile = profile, let anniversary = profile.anniversary {
                self.dateType.text = DateType.anniversary.rawValue
                self.dateValue.text = anniversary
            }
        default:
            return self
        }
        return self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
