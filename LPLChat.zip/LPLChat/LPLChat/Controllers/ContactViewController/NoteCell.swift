//
//  NoteCell.swift
//  LPLMessages
//
//  Created by Phillip English on 7/12/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class NoteCell: UITableViewCell {
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var noteLabel: UILabel!
    
    func configureCell(with dateString: String, noteText: String) {
        self.dateLabel.text = dateString
        self.noteLabel.text = noteText
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        self.selectionStyle = .none
    }

}
