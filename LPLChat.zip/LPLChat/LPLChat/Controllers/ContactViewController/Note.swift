//
//  Note.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 8/1/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct Note: Codable {
    
    let noteText: String?
    let investorName: String?
    let clientID: String?
    
    init(noteText: String?, investorName: String?, clientId: String?) {
        self.noteText = noteText
        self.investorName = investorName
        self.clientID = clientId
    }
    
}
