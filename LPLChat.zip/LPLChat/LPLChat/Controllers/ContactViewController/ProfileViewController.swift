//
//  ProfileViewController.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/20/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import ContactsUI

enum StickyHeaderViewSize: CGFloat {
    case large = 240
    case small = 120
}

enum SectionType: Int {
    case phones = 0
    case emails = 1
    case addresses = 2
    case dates = 3
}

enum DateType: String {
    case birthday
    case anniversary
}

class ProfileViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate {

    @IBOutlet weak var initialLbl: UILabel!
    @IBOutlet weak var imageView: RoundedImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var marketValueLbl: UILabel!
    @IBOutlet weak var asOfDateLbl: UILabel!
    @IBOutlet weak var stickyHeaderContainer: UIView!
    @IBOutlet weak var tableViewContainer: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var nameInitialLabel: CustomLabel!
    @IBOutlet weak var superStackView: UIStackView!
    @IBOutlet weak var headerInitialView: UIView!
    @IBOutlet weak var callBtn: UIButton!
    @IBOutlet weak var messageBtn: UIButton!
    @IBOutlet weak var contactTableView: UITableView!
    @IBOutlet weak var notesTableView: UITableView!
    @IBOutlet weak var scrollView: UIScrollView!

    // MARK: - Constraints
    @IBOutlet weak var contactTableHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var lplHeaderViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var messageButtonConstraint: NSLayoutConstraint!
    @IBOutlet weak var callButtonConstraint: NSLayoutConstraint!
    @IBOutlet weak var initialsAvatarHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var nameLabelTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var initialsTopConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var notesTableHeightConstraint: NSLayoutConstraint!
    @IBOutlet var notesLabel: UILabel!

    var mobileNumber : String!
    var workNumber : String!
    var selectedContact : Contacts!
    var nameText : String!
    var initialText : String!
    var imageName : String!
    var selectedNumber : String!
    var phoneContact : CNContact!
    var presentedFromChatDetails: Bool = false
    var cwContact : Contacts!
    var profile : Profile! // Model for this view.
    var contentOffset:CGFloat = 0.0
    var sectionsCount:Int = 0
    var contactTableHeightConstant = 0
    
    var profileViewModel = ProfileViewModel()

    
    // MARK: - View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        headerView.backgroundColor = .lPLLightGray
        scrollView.backgroundColor = .lPLLightGray
        prepareContact()
        if cwContact != nil {
            self.marketValueLbl.isHidden = false
            self.asOfDateLbl.isHidden = false
            self.marketValueLbl.text = CustomUtility.returnFormattedCurrency(cwContact.amountValue)
            self.asOfDateLbl.text = CustomUtility.calculateStringForDate(cwContact.asOfDate!)
            lplHeaderViewHeightConstraint.constant = 240
        } else {
            self.marketValueLbl.isHidden = true
            self.asOfDateLbl.isHidden = true
            messageButtonConstraint.isActive = false
            messageButtonConstraint = messageBtn.topAnchor.constraint(equalTo: nameLbl.bottomAnchor)
            messageButtonConstraint.constant = 20
            messageButtonConstraint.isActive = true
            callButtonConstraint.isActive = false
            callButtonConstraint = callBtn.topAnchor.constraint(equalTo: nameLbl.bottomAnchor)
            callButtonConstraint.constant = 20
            callButtonConstraint.isActive = true
            lplHeaderViewHeightConstraint.constant = 200
        }
        self.nameLbl.text = self.profile.name
        self.nameInitialLabel?.text = self.initialText //CustomUtility.returnStringInitials(self.initialText)
        configureUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationItem.largeTitleDisplayMode = .never
        self.updateRoundCornersOfNameInitialLabel()
        self.fetchNotes()
    }
    
    private func fetchNotes() {
        
        shouldDisplayNotes(value: true)
        // fetch notes for clientwork's contact only
        guard let clientID = self.profileViewModel.contact?.clientID else {
            notesTableHeightConstraint.constant = 0.0
            return
        }
        
        self.profileViewModel.fetchAllNotes(with: clientID) {
            DispatchQueue.main.async {
                if self.profileViewModel.notes.count > 0 {
                    self.notesTableHeightConstraint.constant = 300.0
                    self.notesTableView.reloadData()
                    self.shouldDisplayNotes(value: false)
                } else {
                    self.notesTableHeightConstraint.constant = 0.0
                }
            }
        }
    }
    
    func shouldDisplayNotes(value: Bool) {
        notesLabel.isHidden = value
        self.notesTableView.isHidden = value
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.updateRoundCornersOfNameInitialLabel()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    // MARK: - UISetup
    func setupNavigationBar() {
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.navigationController?.navigationBar.barTintColor = UIColor.lPLLightGray
        self.navigationController?.navigationBar.tintColor = UIColor.lPLBlue1
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }

    func configureUI() {
        self.view.backgroundColor = .lPLLightGray
        enableOrDisableMessageAndCallButton()
        configureSectionCount()
        registerTableCells()
        calculateContactsTableHeight()
        setupNavigationBar()
    }
    
    func enableOrDisableMessageAndCallButton() {
        if self.profile.phoneNumbers.count == 0 {
            self.callBtn.disabledState()
            self.messageBtn.disabledState()
        } else {
            self.callBtn.enabledState()
            self.messageBtn.enabledState()
        }
    }

    func updateRoundCornersOfNameInitialLabel() {
        self.nameInitialLabel.roundCorner(cornerRadius: self.nameInitialLabel.frame.size.width / 2, borderWidth: 0, borderColor: UIColor.groupTableViewBackground)
    }
    
    // MARK: - Setup Contact Table
    func configureSectionCount() {
        var dateSection = 0
        if let _ = self.profile.birthday {
            dateSection += 1
        }
        if let _ = self.profile.anniversary {
            dateSection += 1
        }
        sectionsCount = Int((self.profile?.phoneNumbers.count)!) + (self.profile?.emails.count)! + (self.profile?.addresses.count)! + dateSection
    }
    
    func registerTableCells() {
        self.registerCellWith(identifier: Constants.contactNumberTableViewCell)
        self.registerCellWith(identifier: Constants.addressInfoTableViewCell)
        self.registerCellWith(identifier: Constants.contactDateTableViewCell)
        self.registerCellWith(identifier: "ProfileNoteCell")
    }
    
    func registerCellWith(identifier: String) {
        self.contactTableView.register(UINib.init(nibName: identifier, bundle: nil), forCellReuseIdentifier: identifier)
    }
    
    // MARK: - Prepare contacts
    func prepareContact() {
        if self.phoneContact != nil {
            preparePhoneContact()
        } else {
            prepareCwContact()
        }
    }

    func prepareCwContact(){
        self.profile = self.cwContact.profile
        if let profile = self.cwContact.profile {
            self.profile = profile
        } else{
             self.profile = Profile(name: cwContact.nameValue, phoneNumbers: [PhoneNumber(displayValue: cwContact.phoneNumber ?? "", label: "Mobile", isFav: false)], emails: [], addresses: [], birthday: nil, anniversary: nil, amountValue: 0, variationValue: 0, asOfDateStr: Date().toISO8601String())
        }

        if self.cwContact.imageName.isEmpty{
            self.imageName = "N.A."
            self.initialText = CustomUtility.returnStringInitials(self.cwContact.nameValue!)
        }
        else{
            self.imageName =  self.cwContact.imageName!
            self.initialText = ""
        }
    }

    func preparePhoneContact(){
        self.profile = ContactUtility.convertToProfile(phoneContact: self.phoneContact)
        let formatter = CNContactFormatter()
        self.nameText = formatter.string(from: self.phoneContact)
        if self.phoneContact.phoneNumbers.count > 1 {
            self.mobileNumber = self.phoneContact.phoneNumbers.first?.value.stringValue
            self.workNumber = self.phoneContact.phoneNumbers[1].value.stringValue
        }
        else {
            self.mobileNumber = self.phoneContact.phoneNumbers.first?.value.stringValue
        }
        self.imageName  =  "N.A."
        if let contact = self.phoneContact {
            if let name = formatter.string(from: contact) {
                self.initialText = CustomUtility.returnStringInitials(name)
            }
        }
    }
    
    // MARK: - Invoke actions
    func invokeNativeCall(_ number: String) {
        guard let number = URL(string: "tel://" + number) else { return }
        UIApplication.shared.open(number)
    }

    func invokeChat(_ number: String) {
       // self.selectedNumber = number
        DispatchQueue.main.async {
            let controller = UIViewController.build(with: "Main", and: "ChatDetailsViewController") as? ChatDetailsViewController
            guard let viewController = controller else {
                return
            }
            //📌 TODO:- number, name and initials should come from contact not floating properties. Need a cleanup story
            viewController.toNumber = number
            viewController.toName = self.nameLbl.text
            viewController.toNameInitials = self.nameInitialLabel.text
            var clientID: String = ""
            if (self.cwContact != nil) {
                if let id = self.cwContact.clientID {
                    clientID = id
                }
            }
            let contact = Contact(contactName: self.nameLbl.text, contactNumber: number, contactType: clientID.count > 0 ? .clientWorks : .phoneBook, clientID: clientID.count > 0 ? clientID : nil)
            viewController.contactInfo = contact
            viewController.source = .profile
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    //MARK: - Tableview Delegates and Datasource
    internal func numberOfSections(in tableView: UITableView) -> Int {
        let sectionCount: Int
        
        switch tableView.tag {
            case ProfileTableViewEnum.contactDetail.hashValue:
                sectionCount = self.sectionsCount
            case ProfileTableViewEnum.notes.hashValue:
                sectionCount = 1
            default:
                sectionCount = 0
        }

        return sectionCount
    }
    
    // TODO: Continue Configuring contactTableHeightConstant
    internal func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var rowCount = 0
        
        if tableView.tag == ProfileTableViewEnum.contactDetail.hashValue {
            switch section {
            case SectionType.phones.rawValue:
                rowCount = (self.profile?.phoneNumbers.count)!
                contactTableHeightConstant += 80 * (self.profile?.phoneNumbers.count)!
            case SectionType.emails.rawValue:
                rowCount = (self.profile?.emails.count)!
                contactTableHeightConstant += 80 * (self.profile?.emails.count)!
            case SectionType.addresses.rawValue:
                rowCount = (self.profile?.addresses.count)!
                contactTableHeightConstant += 174 * (self.profile?.addresses.count)!
            case SectionType.dates.rawValue:
                var dateRowCount = 0
                if let _ = self.profile.birthday {
                    dateRowCount += 1
                }
                if let _ = self.profile.anniversary {
                    dateRowCount += 1
                }
                contactTableHeightConstant += 80 * dateRowCount
                rowCount = dateRowCount
            default:
                break
            }
        } else if (tableView.tag == ProfileTableViewEnum.notes.hashValue) {
            rowCount = self.profileViewModel.notes.count
        }
        
        return rowCount
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        var cell = UITableViewCell()
        
        if tableView.tag == ProfileTableViewEnum.contactDetail.hashValue {
            switch indexPath.section {
            case SectionType.phones.rawValue:
                cell = self.configurePhoneNumberCell(at: indexPath,  for: tableView)
            case SectionType.emails.rawValue:
                cell = self.configureEmailCell(at: indexPath, for: tableView)
            case SectionType.addresses.rawValue:
                cell = self.configureAddressCell(at: indexPath, for: tableView)
            case SectionType.dates.rawValue:
                cell = self.configureContactDataCell(at: indexPath, for: tableView)
            default:
                break
            }
        } else if (tableView.tag == ProfileTableViewEnum.notes.hashValue) {
        
            let notesCell = self.configureNoteCell(at: indexPath)
            guard let noteCell = notesCell else {
                return cell
            }
            
            return noteCell
        }
            
        return cell
    }
    
    func configureNoteCell(at indexPath: IndexPath) -> ProfileNoteCell? {
        
        let contactCell = notesTableView.dequeueReusableCell(withIdentifier: "ProfileNoteCell", for: indexPath) as? ProfileNoteCell
        guard let advisorNote = self.profileViewModel.notes[indexPath.row] else {
            return contactCell
        }
        
        contactCell?.configure(with: advisorNote.monthAndDateOnly, time: advisorNote.timeOnly, message: advisorNote.noteText, isCreatedByApp: advisorNote.isCreatedByPhoneApp ?? false, indexPath: indexPath)
        
        return contactCell
    }

    func configurePhoneNumberCell(at indexPath: IndexPath, for tableView:UITableView) -> ContactNumberTableViewCell {
        let contactCell = tableView.dequeueReusableCell(withIdentifier: Constants.contactNumberTableViewCell, for: indexPath) as! ContactNumberTableViewCell
        let phoneNumber: PhoneNumber = (self.profile?.phoneNumbers[indexPath.row])!
        let labelValue = self.phoneContact != nil ? phoneNumber.label :  phoneNumber.label.lowercased()
        contactCell.configureCellWith(header: labelValue!, phoneNumber: phoneNumber.displayValue)
        return contactCell
    }
    
    func configureEmailCell(at indexPath: IndexPath, for tableView:UITableView) -> ContactNumberTableViewCell {
        let emailCell = tableView.dequeueReusableCell(withIdentifier: Constants.contactNumberTableViewCell, for: indexPath) as! ContactNumberTableViewCell
        let email: Email = (self.profile?.emails[indexPath.row])!
        let labelValue = email.label.lowercased()
        emailCell.configureCellWith(header: labelValue, phoneNumber: email.value)
        return emailCell
    }
    
    func configureAddressCell(at indexPath: IndexPath, for tableView:UITableView) -> AddressInfoTableViewCell {
        let addressInfoCell = tableView.dequeueReusableCell(withIdentifier: Constants.addressInfoTableViewCell, for: indexPath) as! AddressInfoTableViewCell
        let address: Address = (self.profile?.addresses[indexPath.row])!
        addressInfoCell.configureCellWith(address: address)
        return addressInfoCell
    }
    
    private func configureContactDataCell(at indexPath: IndexPath, for tableView:UITableView) -> ContactDateTableViewCell {
        let contactDateCell = tableView.dequeueReusableCell(withIdentifier: Constants.contactDateTableViewCell, for: indexPath) as! ContactDateTableViewCell
        return contactDateCell.configureCellWith(profile: self.profile, indexPath: indexPath)
    }

    internal func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        if tableView.tag == ProfileTableViewEnum.contactDetail.hashValue {
            
            // if section is phone number section
            if indexPath.section == SectionType.phones.rawValue {
                let phoneNumber = self.profile.phoneNumbers[indexPath.row]
                if let phoneValue = phoneNumber.value {
                    guard let number = URL(string: "tel://" + phoneValue) else {
                        print("error : didSelectRow - phoneValue")
                        return
                    }
                    UIApplication.shared.open(number)
                }
            }
            tableView.deselectRow(at: indexPath, animated: false)
        } else {
            return
        }
    }
    
    private func calculateContactsTableHeight() {

        // TODO:🔥 This code shouldn't be there, tableview should be able to handle the hieght dynamically - SB
        if let phonesCount = self.profile?.phoneNumbers.count {
            contactTableHeightConstant += 70 * phonesCount
        }
        if let emailsCount = self.profile?.emails.count {
            contactTableHeightConstant += 70 * emailsCount
        }
        if let addressesCount = self.profile?.addresses.count {
            contactTableHeightConstant += 130 * addressesCount
        }
        if let _ = self.profile.birthday {
            contactTableHeightConstant += 70
        }
        if let _ = self.profile.anniversary {
            contactTableHeightConstant += 70
        }
        contactTableHeightConstraint.constant = CGFloat(contactTableHeightConstant)
    }
    
    //MARK: - UIScrollview - Strechy Header Method
    func scrollViewDidScroll(_ scrollView: UIScrollView) {

        if cwContact == nil {
            let scrollAmount = contentOffset + scrollView.contentOffset.y
            print("🤖 lplHeaderViewHeightConstraint.constant = \(lplHeaderViewHeightConstraint.constant)")
            if contentOffset >= scrollView.contentOffset.y {
                guard lplHeaderViewHeightConstraint.constant < StickyHeaderViewSize.large.rawValue else {return}
                lplHeaderViewHeightConstraint.constant -= scrollAmount
            } else {
                guard lplHeaderViewHeightConstraint.constant > StickyHeaderViewSize.small.rawValue else {return}
                lplHeaderViewHeightConstraint.constant -= scrollAmount
            }
            print("🤖 lplHeaderViewHeightConstraint.constant = \(lplHeaderViewHeightConstraint.constant)")
            
            if lplHeaderViewHeightConstraint.constant < 140 {
                initialsAvatarHeightConstraint.constant = 0
                nameLabelTopConstraint.constant = 0
                initialsTopConstraint.constant = 0
            } else {
                initialsAvatarHeightConstraint.constant = 80
                nameLabelTopConstraint.constant = 8
                initialsTopConstraint.constant = 5
            }
            if lplHeaderViewHeightConstraint.constant > StickyHeaderViewSize.large.rawValue {
                lplHeaderViewHeightConstraint.constant = StickyHeaderViewSize.large.rawValue
            } else if lplHeaderViewHeightConstraint.constant < StickyHeaderViewSize.small.rawValue {
                lplHeaderViewHeightConstraint.constant = StickyHeaderViewSize.small.rawValue
            }
            print("🤖 lplHeaderViewHeightConstraint.constant = \(lplHeaderViewHeightConstraint.constant)")
            print("🤖 -----------------------------------")
        }
        
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        self.updateRoundCornersOfNameInitialLabel()
    }

    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        self.updateRoundCornersOfNameInitialLabel()
    }

    //MARK: - IBAction Methods
    @IBAction func callBtnClicked(_ sender: Any) {
        if  self.profile.phoneNumbers.count == 0 {
            //no number to call
        } else if  self.profile.phoneNumbers.count == 1 {
            self.invokeNativeCall(self.profile.phoneNumbers[0].value)
        } else {
            let optionMenu = UIAlertController(title: nil, message: "Call Mobile", preferredStyle: .actionSheet)
            for phoneNumber in self.profile.phoneNumbers {
                if let phoneType = phoneNumber.label, let rawPhoneNumber = phoneNumber.displayValue {
                    let title = "\(phoneType) : \(CustomUtility.format(phoneNumber: rawPhoneNumber))"
                    let callAction = UIAlertAction(title: title, style: .default, handler: { (alert: UIAlertAction!) -> Void in
                        self.invokeNativeCall(phoneNumber.value)
                    })
                    optionMenu.addAction(callAction)
                }
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { (alert: UIAlertAction!) -> Void in
                print("Cancelled")
            })
            optionMenu.addAction(cancelAction)
            self.present(optionMenu, animated: true, completion: nil)
        }
    }

    @IBAction func smsBtnClicked(_ sender: Any) {

        guard presentedFromChatDetails == false else {
            if let navController = self.navigationController, navController.viewControllers.count >= 2 {
                let chatDetailsVC = navController.viewControllers[navController.viewControllers.count - 2] as! ChatDetailsViewController
                chatDetailsVC.source = .profile
            }
            self.navigationController?.popViewController(animated: true)
            return
        }

        if self.profile.phoneNumbers.count == 0 {
            //no number to call
        } else if  self.profile.phoneNumbers.count == 1 {
            self.invokeChat(self.profile.phoneNumbers![0].value)
        } else {
            let optionMenu = UIAlertController(title: nil, message: "Message mobile", preferredStyle: .actionSheet)
            for phoneNumber in self.profile.phoneNumbers {
                if let phoneType = phoneNumber.label, let rawPhoneNumber = phoneNumber.displayValue {
                    let title = "\(phoneType) : \(CustomUtility.format(phoneNumber: rawPhoneNumber))"
                    let callAction = UIAlertAction(title: title, style: .default, handler:
                    {
                        (alert: UIAlertAction!) -> Void in
                        self.invokeChat(phoneNumber.value)
                    })
                    optionMenu.addAction(callAction)
                }
            }

            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { (alert: UIAlertAction!) -> Void in
                print("Cancelled")
            })
            optionMenu.addAction(cancelAction)
            self.present(optionMenu, animated: true, completion: nil)
        }
    }
    
}
