//
//  AddressInfoTableViewCell.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class AddressInfoTableViewCell: UITableViewCell {

    @IBOutlet weak var stackView: UIStackView!

    @IBOutlet weak var addressTypeLabel: UILabel!
    @IBOutlet weak var addressLine1Label: UILabel!
    @IBOutlet weak var addressLine2_3Label: UILabel!
    @IBOutlet weak var city_State_ZipLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    
    
    func configureCellWith(address: Address, isClientWorks: Bool? = false) {
        let labelValue: String = address.label.lowercased()
        self.addressTypeLabel.text = labelValue
        if !address.line1.isEmpty {
            self.addressLine1Label.text = address.line1
        } else {
            self.addressLine1Label.isHidden = true
        }
        if !(address.line2.isEmpty) {
            self.addressLine2_3Label.text = address.line2 + " " + address.line3
        } else {
            self.addressLine2_3Label.isHidden = true
        }
        if !(address.city.isEmpty) || !(address.state.isEmpty) || !(address.zipCode.isEmpty) {
            self.city_State_ZipLabel.text = "\(address.city) \(address.state) \(address.zipCode)"
        } else {
            self.city_State_ZipLabel.isHidden = true
        }
        //Note: Country is hardcoded to USA for now cause not returned by web-api.
        self.countryLabel.text = "United States"
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
