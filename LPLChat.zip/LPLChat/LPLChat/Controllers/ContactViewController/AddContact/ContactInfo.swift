//
//  ContactInfo.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 7/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

struct ContactInfo {
    
    var firstName: String
    var lastName: String
    var mobileNumber: String
    var email: String
    
    init(firstName: String, lastName: String, mobileNumber: String, email: String) {
        
        self.firstName = firstName
        self.lastName = lastName
        self.mobileNumber = mobileNumber
        self.email = email
    }
}
