//
//  CreateContactCell.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 6/28/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

protocol BasicContactInfoDelegate {
    func fields(_ validated: Bool, with contactInfo: ContactInfo?)
}

class BasicContactInfoTableCell: UITableViewCell, UITextFieldDelegate {
    
    var eventHandler: ((Bool)->())?
    
    // IBoutlets
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var mobileNumber: UITextField!
    @IBOutlet weak var email: UITextField!
    
    var delegate: BasicContactInfoDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        self.selectionStyle = .none
    }
    
    //MARK: - Private Methods
    
    /// Below discussion validate weather all the necessary fields has data or not
    ///
    /// - Returns: true if all the required fields are filled else return false
    private func validate() {
        
        let contactInfo = ContactInfo(firstName: firstName.text!, lastName: lastName.text!, mobileNumber: mobileNumber.text!, email: email.text!)
        
        // all required fields
        let requiredFields: [UITextField] = [firstName, lastName, mobileNumber]
        var isValid = true
       
        for currentField in requiredFields {
            
            let text = currentField.text!
            if text.hasWhiteSpaceOnly() {
                isValid = false
                break
            }
        }
        
        // If all the fields have valid data call completion handler which will notify respective controller
        self.delegate?.fields(isValid, with: contactInfo)
    }
    
    
    //MARK: - Action Methods
    
    @IBAction func validateAllMandatory() {
        validate()
    }
    
    
    //MARK - Textfield Delegates
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        validate()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
