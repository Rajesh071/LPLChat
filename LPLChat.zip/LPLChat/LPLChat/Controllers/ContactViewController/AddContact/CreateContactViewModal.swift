//
//  CreateContactViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 6/28/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Contacts

enum ContactType {
    case prospect
    case phone
}

struct CreateContactViewModel {
    
    var contactInfo: ContactInfo?
    var contactType: ContactType = .phone
    
    func saveProspectToClientWorks(handler : @escaping ((String?)->())) {
        
        guard let contactInfo = self.contactInfo else {
            return
        }
        
        // display activity indicator
        Loader.shared.add()
        
        ServiceManager.saveProspectToClientWorks(with: contactInfo) { (result) in
            
            Loader.shared.remove()

            switch result {
            case .success(_):
                    handler(nil)
                case let .failure(error):
                    handler(error.localizedDescription)
                }
        }
    }
    
}
