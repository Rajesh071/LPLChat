//
//  CreateContactViewController.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 6/29/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import Contacts


class CreateContactViewController: UITableViewController, BasicContactInfoDelegate {

    @IBOutlet weak var rightBarItem: UIBarButtonItem!
    @IBOutlet weak var leftBarItem: UIBarButtonItem!
    
    var viewModel: CreateContactViewModel?
        
    //MARK:- Factory Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        self.navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    
    //MARK:- Public Methods
    
    static func build(with contactType: ContactType) -> CreateContactViewController? {
        let storyboard = UIStoryboard(name: "Main",
                                      bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"CreateContactViewController") as? CreateContactViewController
        viewController?.viewModel = CreateContactViewModel()
        viewController?.viewModel?.contactType = contactType
        
        return viewController
    }
    
    
    // MARK: - IBAction Methods
    
    @IBAction func dismissMe() {
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func donePressed() {
        
        // dismiss keyboard
        self.view.endEditing(true)
        
        self.viewModel?.contactType == .phone ? self.saveToPhoneLocally() : self.saveToProspect()
    }
    
    
    // MARK: - Private Methods
    
    private func saveToPhoneLocally() {
        // if user forcibly turns permissions of in contacts then display error message
        if !ContactUtility.hasPermissionToAccessDeviewContacts() {
            ContactUtility.displayAccessToDeviceContactsAlert(on: self)
            
            return
        }
        
        guard let contactInfo = self.viewModel?.contactInfo else {
            return
        }
        
        // fetch all the fields from list
        let contact = ContactUtility.createContact(with: contactInfo.firstName,
                                                   lastName: contactInfo.lastName,
                                                   mobileNumber: contactInfo.mobileNumber,
                                                   emailAddress: contactInfo.email)
        
        if ContactUtility.save(contact: contact) {
            self.showSuccessAlert(with: "Contact saved locally")
        } else {
            self.showFaiureAlert()
        }
    }
    
    private func showSuccessAlert(with message: String) {
        AlertUtil.showAlert(with: "",
                            message: message,
                            constructiveButtonTitle: "Ok",
                            destructiveButtonTitle: nil,
                            constructiveActionHandler: {
                                self.dismissMe()},
                            destructiveActionHandler: nil,
                            onController: self)
    }
    
    private func showFaiureAlert() {
        AlertUtil.showAlert(with: "Error",
                            message: "Unable to Save Contact",
                            onController: self)
    }
    
    private func saveToProspect() {
        
        self.viewModel?.saveProspectToClientWorks(handler: { (error) in
            
            if error != nil {
                self.showFaiureAlert()
            } else {
                self.showSuccessAlert(with: "Contact saved to ClientWorks")
            }
        })
    }
    
    private func configure() {
        
        self.rightBarItem.isEnabled = false
        
        self.navigationController?.navigationBar.prefersLargeTitles = false
        
        self.tableView.tableFooterView = UIView()
        
        self.tableView.register(UINib(nibName: "BasicContactInfoTableCell", bundle: nil),
                                forCellReuseIdentifier: "BasicContactInfoTableCell")
    }
    
    
    // MARK: - Tableview Methods
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let basicInfoCell = tableView.dequeueReusableCell(withIdentifier: "BasicContactInfoTableCell", for: indexPath) as! BasicContactInfoTableCell
        
        basicInfoCell.delegate = self
        
        return basicInfoCell
    }
    
    
    // MARK: - BasicInfoTableCell Delegate
    
    func fields(_ validated: Bool, with contactInfo: ContactInfo?) {
        
        guard let contactInfo = contactInfo else {
            return
        }
        self.viewModel?.contactInfo = contactInfo
        
        DispatchQueue.main.async {
            self.rightBarItem.isEnabled = validated
        }
    }
}
