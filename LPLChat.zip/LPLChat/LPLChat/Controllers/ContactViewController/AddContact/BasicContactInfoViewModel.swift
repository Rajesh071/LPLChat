//
//  CreateCellViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 6/29/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct BasicContactInfoViewModel {
    
}// class ending here
