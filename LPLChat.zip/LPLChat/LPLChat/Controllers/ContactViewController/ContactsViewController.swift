 //
//  ContactsViewController.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import ContactsUI
import NVActivityIndicatorView

class ContactsViewController: SettingsAccessViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, NVActivityIndicatorViewable, UITextFieldDelegate, UIActionSheetDelegate {

    @IBOutlet weak var portfolioLblHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var uiButtonCancel: UIBarButtonItem!
    @IBOutlet weak var contactsTableView: UITableView!
    @IBOutlet weak var lplHeaderView: LPLHeaderView!
    @IBOutlet weak var righBarButton: UIBarButtonItem!

    var currentUser: User?
    
    //CW contact
    let defaultPageSize: Int = 200
    let minCharactersToSearch: Int = 3
    var pageNo: Int = 0
    var cwSectionArray = [String]()
    var cwSortedDictionary = [String: [Contacts]]()
    var selectedCWContact: Contacts!
    var totalRecords: Int?
    var isFetchingCW: Bool = false
    var hasMorePages: Bool = true
    var allClientWorkContacts:[Contacts] = [] // This will keep track of all the contacts returned from by WebAPI for client works

    //Phone Contact
    var phoneContacts = [CNContact]()
    var phoneSectionArray = [String]()
    var phoneSortedDictionary = [String: [CNContact]]()
    var completePhoneContact = [CNContact]()
    var selectedPhoneContact: CNContact!
    var translucentNavigationBar = false

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        log.verbose("DIDLOAD",context:"ctxCD")
        self.contactsTableView.isHidden = true
        lplHeaderView.searchBar?.delegate = self
        self.currentUser = StaticDataStore.getCurrentUser()
        self.isNewMessageMode ? self.showCancel() : self.hideCancel()
        self.contactsTableView.estimatedRowHeight = 40
        self.contactsTableView.rowHeight = UITableViewAutomaticDimension
        lplHeaderView.searchBar?.showsCancelButton = false
        self.contactsTableView.tableFooterView = UIView()
        switchSearchbarPlaceholder()
        lplHeaderView.lplHeaderDelegate = self
        if self.navigationController != nil && self.navigationController!.navigationBar.isTranslucent {
            translucentNavigationBar = true
        }

        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
        let textFieldInsideUISearchBar = lplHeaderView.searchBar?.value(forKey: "searchField") as? UITextField
        let placeholderLabel = textFieldInsideUISearchBar?.value(forKey: "placeholderLabel") as? UILabel
        placeholderLabel?.font = UIFont.systemFont(ofSize: 14.0)
        placeholderLabel?.textColor = UIColor.lPLDarkGray
        setUI()
        resetCwContacts()
        fetchNextPage()
        reloadPage() { () in }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        log.verbose("viewWillAppear",context:"ctxCD")
//        setUI()
        if translucentNavigationBar {
            lplHeaderView.setYposition(offset: topDistance, height: topDistance, translucent: true)
        } else {
            lplHeaderView.setYposition(offset: topDistance, height: 0, translucent: false)
        }

    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.async { [unowned self] in
            self.contactsTableView.reloadData(){}
        }
    }
    
    // MARK - UI
    func setUI() {
        self.view.backgroundColor = .lPLLightGray
        setupNavigationBar()
        customizeSearchBar()
    }
    
    func setupNavigationBar() {
        self.title = "Contacts"
        navigationItem.largeTitleDisplayMode = .always
        self.navigationController?.navigationBar.barTintColor = .lPLLightGray
        self.navigationController?.navigationBar.tintColor = .lPLBlue1
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    func customizeSearchBar() {
        lplHeaderView.searchBar?.showsCancelButton = false
        // SearchBar text
        let textFieldInsideUISearchBar = lplHeaderView.searchBar?.value(forKey: "searchField") as? UITextField
        textFieldInsideUISearchBar?.textColor = .lPLBlue4
        textFieldInsideUISearchBar?.font = textFieldInsideUISearchBar?.font?.withSize(14)
        
        // SearchBar placeholder
        let textFieldInsideUISearchBarLabel = textFieldInsideUISearchBar!.value(forKey: "placeholderLabel") as? UILabel
        textFieldInsideUISearchBarLabel?.textColor = .lPLMediumGray
        textFieldInsideUISearchBar?.font = textFieldInsideUISearchBar?.font?.withSize(14)
    }

    
    // MARK: - Update UI
    private func displayAlertSheet() {
        var actions: [(String, UIAlertActionStyle)] = []
        actions.append(("Prospect", UIAlertActionStyle.default))
        actions.append(("Local Phone", UIAlertActionStyle.default))
        actions.append(("Cancel", UIAlertActionStyle.cancel))
        AlertUtil.showActionsheet(viewController: self, title: "Create Contact", message: nil, actions: actions) { (index) in
            switch (index) {
                case ContactType.prospect.hashValue:
                    self.displayPageToSave(contactType: .prospect)
                case ContactType.phone.hashValue:
                    if !ContactUtility.hasPermissionToAccessDeviewContacts() {
                        ContactUtility.displayAccessToDeviceContactsAlert(on: self)
                        return
                    }
                    self.displayPageToSave(contactType: .phone)
                default:
                    break
            }
        }
    }
    

    
    func displayPageToSave(contactType: ContactType) {
        DispatchQueue.main.async {
            guard let viewController = CreateContactViewController.build(with: contactType) else {
                return
            }
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    func reloadPage(completion: @escaping () -> Void) {
        if lplHeaderView.segmentedControl?.selectedSegmentIndex == 2 {
            phoneSectionArray.removeAll()
            phoneSortedDictionary.removeAll()
            self.getPermissionForContacts()
            DispatchQueue.main.async { [unowned self] in
                self.contactsTableView.reloadData() {
                    completion()
                }
            }
        } else {
            // check if searchbar is empty, get contacts from client works
            if lplHeaderView.searchBar?.text?.count == 0 && self.allClientWorkContacts.count > 0 {
                Session.contacts = self.allClientWorkContacts
            }
            self.generateCWWordsDict(){ () in
                completion()
            }
        }
        lplHeaderView.searchBar?.text = ""
        lplHeaderView.searchBar?.resignFirstResponder()
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        lplHeaderView.searchBar?.text = ""
        searchContacts("")
        return true
    }

    // MARK: - Fetch Data
    func fetchNextPage(_ fromSearch: Bool? = false) {
        hasMorePages = true
        if let totalRecordsValue = totalRecords { // initial load or new search
            if totalRecordsValue <= Session.contacts.count { //reached max server records count
                hasMorePages = false
            }
        }
        if hasMorePages {
            pageNo += 1
            if fromSearch! {
                fetchContactsFromService(pageNo: pageNo, fromSearch: true)
                fetchProspects(pageNo: pageNo, fromSearch: true)
            } else {
                fetchContactsFromService(pageNo: pageNo)
                fetchProspects(pageNo: pageNo)
            }
            generatePhoneWordsDict()
        }
    }

    func fetchContactsFromService(pageNo: Int, fromSearch: Bool? = false) {
        isFetchingCW = true
        //TODO : SAN animation in corner of page
        let size = CGSize(width: 35, height: 35)
        startAnimating(size, message: "Fetching...", type: NVActivityIndicatorType.ballScaleRippleMultiple)
        log.verbose("isFetching \(pageNo)", context: ctx.Paging.rawValue)
        let searchString = lplHeaderView.searchBar?.text ?? ""
        ContactService.getClients(pageNo: pageNo, pageSize: defaultPageSize, searchString: searchString) { (totalRecords, contactsFromService, status) in
            
            //TODO : SAN Stop animation in corner of page
            self.stopAnimating()
            self.isFetchingCW = false
            guard status.statusType == .success else {
                AlertUtil.showAlert(with: "Error", message: status.statusMessage, onController: self)
                return
            }

            if pageNo == 1 { //reset the contacts
                Session.contacts = contactsFromService!
            } else { //Append contacts
                if let contactsFromService = contactsFromService {
                    for contact in contactsFromService {
                        Session.contacts.append(contact)
                    }
                }
            }

            // all the contacts returned from service and not coming from search path
            
            if !(fromSearch!)  {
                if let contacts = contactsFromService  {
                    self.allClientWorkContacts = contacts
                }
            }
            
            self.totalRecords = totalRecords
            self.generateCWWordsDict(){}
        }
    }
    
    func fetchProspects(pageNo: Int, fromSearch: Bool? = false) {
        isFetchingCW = true
        startAnimating(CGSize(width: 35, height: 35), message: "Fetching...", type: NVActivityIndicatorType.ballScaleRippleMultiple)
        log.verbose("isFetching \(pageNo)", context: ctx.Paging.rawValue)
        let searchString = lplHeaderView.searchBar?.text ?? ""
        ContactService.getProspects(pageNo: pageNo, pageSize: defaultPageSize, searchString: searchString) { (totalRecords, returnedPropects, status) in
            self.stopAnimating()
            self.isFetchingCW = false
            guard status.statusType == .success else {
                AlertUtil.showAlert(with: "Error", message: status.statusMessage, onController: self)
                return
            }
            guard let propects = returnedPropects else {
                return
            }
            if pageNo == 1 { //reset the contacts
                Session.propects = propects
            } else {
                for propect in propects {
                    Session.propects.append(propect)
                }
            }
//            if let searchPerformed = fromSearch, !searchPerformed {
//                self.allClientWorkContacts = propects
//            }
            self.totalRecords = totalRecords
        }
    }

    func generatePhoneWordsDict() {

        // remove previously stored objects
        phoneSectionArray.removeAll()
        phoneSortedDictionary.removeAll()
        
        for contact in self.phoneContacts {
            let firstName = contact.givenName
            if !(firstName.isEmpty) {
                let firstChar: String = "\(firstName[firstName.startIndex])"
                if firstChar != "" || firstChar != " " {
                    var upperCaseName = firstChar.uppercased()
                    let letters = NSCharacterSet.letters
                    let range = upperCaseName.rangeOfCharacter(from: letters)
                    if range == nil {
                        upperCaseName = "#"
                    }
                    if var wordValues = phoneSortedDictionary[upperCaseName] {
                        wordValues.append(contact)
                        phoneSortedDictionary[upperCaseName] = wordValues
                    } else {
                        phoneSortedDictionary[upperCaseName] = [contact]
                    }
                }
            } else if (contact.phoneNumbers.count > 0) {
                // if contact has no name but numbers only
                let mutableContact:CNMutableContact = contact.mutableCopy() as! CNMutableContact
                mutableContact.givenName = contact.phoneNumbers[0].value.stringValue
                if var wordValues = phoneSortedDictionary["#"] {
                    wordValues.append(mutableContact)
                    phoneSortedDictionary["#"] = wordValues
                } else {
                    phoneSortedDictionary["#"] = [mutableContact]
                }
            }
        }

        self.phoneSectionArray = [String](phoneSortedDictionary.keys)
        self.phoneSectionArray = self.phoneSectionArray.sorted()
        if (self.phoneSectionArray.count != 0) && (self.phoneSectionArray[0] == "#") {

            self.phoneSectionArray.remove(at: 0)
            self.phoneSectionArray.append("#")
        }

        DispatchQueue.main.async { [unowned self] in
            self.contactsTableView.isHidden = false
            self.contactsTableView.reloadData() { }
        }

    }

    func resetCwContacts(){
        pageNo = 0
        totalRecords = nil
        Session.contacts.removeAll()
        self.cwSectionArray.removeAll()
        self.cwSortedDictionary.removeAll()
        generateCWWordsDict(){}
    }
    
    func generateCWWordsDict(completion: @escaping () -> Void) {
        self.cwSectionArray = []
        self.cwSortedDictionary = [:]
        for contact in Session.contacts {
            let firstName = contact.nameValue
            if !((firstName?.isEmpty)!) {
                let firstChar: String = "\(firstName![(firstName?.startIndex)!])"
                if firstChar != "" || firstChar != " " {
                    var upperCaseName = firstChar.uppercased()
                    let letters = NSCharacterSet.letters
                    let range = upperCaseName.rangeOfCharacter(from: letters)
                    if range == nil {
                        upperCaseName = "#"
                    }
                    if var wordValues = cwSortedDictionary[upperCaseName] {
                        wordValues.append(contact)
                        cwSortedDictionary[upperCaseName] = wordValues
                    } else {
                        cwSortedDictionary[upperCaseName] = [contact]
                    }
                }
            }
        }
        self.cwSectionArray = [String](cwSortedDictionary.keys)
        self.cwSectionArray = self.cwSectionArray.sorted()
        DispatchQueue.main.async { [unowned self] in
            self.contactsTableView.reloadData() {
                completion()
            }
        }
    }

    
    // MARK: - TableView DataSource And Delegates
    internal func numberOfSections(in tableView: UITableView) -> Int {
        let sectionsCount = lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 ? self.cwSectionArray.count : self.phoneSectionArray.count
        return sectionsCount + 1
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var rowHeight = UITableViewAutomaticDimension
        if indexPath.section == 0 {
            rowHeight = 80
        } else {
            rowHeight = lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 ? 80 : 44
        }
        return rowHeight
    }
    
    internal func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        let headerHeight: CGFloat = section == 0 ? 0 : 50
        return headerHeight
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        var sectionHeaderView: UIView!
        if section != 0 {
            if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
                sectionHeaderView = GenericHeaderView.build(with: self.cwSectionArray[section - 1])
            } else if lplHeaderView.segmentedControl?.selectedSegmentIndex == 1 {
                sectionHeaderView = UIView()
            } else {
                sectionHeaderView = GenericHeaderView.build(with: self.phoneSectionArray[section - 1])
            }
        }
        if sectionHeaderView == nil {
            sectionHeaderView = UIView()
        }
        sectionHeaderView.backgroundColor = .lPLLightGray
        return sectionHeaderView
    }

    internal func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var rowCount = 0
        if section == 0 {
            rowCount = 1
        } else if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
            let wordKey = self.cwSectionArray[section - 1]
            if let values = self.cwSortedDictionary[wordKey] {
                rowCount = values.count
            }
        } else if lplHeaderView.segmentedControl?.selectedSegmentIndex == 1 {
            rowCount = 0
        } else {
            let wordKey = self.phoneSectionArray[section - 1]
            if let values = self.phoneSortedDictionary[wordKey] {
                rowCount = values.count
            }
        }
        return rowCount
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            let advisorContactCell: ContactsTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: Constants.advisorContactCell, for: indexPath) as! ContactsTableViewCell)
            advisorContactCell?.nameLbl.text = self.currentUser?.name
            let unformattedPhoneNumber = ContactUtility.removeSpecialCharactersFromNumber((self.currentUser?.number)!)
            let formattedNumber = CustomUtility.format(phoneNumber: unformattedPhoneNumber)
            advisorContactCell?.amountLbl.text = "My VBN:" + " " + formattedNumber
            advisorContactCell?.isUserInteractionEnabled = false
            return advisorContactCell!
        } else {
            if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
                let cWContactCell: ContactsTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: Constants.cWContactsCell, for: indexPath) as! ContactsTableViewCell)
                updateCell(cWContactCell, indexPath: indexPath)
                if isFetchingCW == false {
                    let isEnd = hasReachedEnd(indexPath: indexPath)
                    if isEnd {
                        if hasMorePages {
                        fetchNextPage()
                        }
                    }
                }
                return cWContactCell!
            } else if lplHeaderView.segmentedControl?.selectedSegmentIndex == 1 {
                let prospectContactCell: ContactsTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: Constants.localContactCell, for: indexPath) as! ContactsTableViewCell)
                prospectContactCell?.nameLbl.text = ""
                return prospectContactCell!
            } else {
                let localContactCell: ContactsTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: Constants.localContactCell, for: indexPath) as! ContactsTableViewCell)
                let wordKey = self.phoneSectionArray[indexPath.section - 1]
                let values = self.phoneSortedDictionary[wordKey]
                let formatter = CNContactFormatter()
                localContactCell?.nameLbl.text = formatter.string(from: values![indexPath.row])
                return localContactCell!
            }
        }
    }

    func hasReachedEnd(indexPath: IndexPath) -> Bool {
        //Sections 1 (mynumber) + characters
        var isEnd = false
        let wordKey = self.cwSectionArray[indexPath.section - 1]
        let values = self.cwSortedDictionary[wordKey]
        if let values = values {
            if indexPath.section == cwSectionArray.count { // last section
                if values.count - 1 == indexPath.row { // last item in the last section
                    isEnd = true
                    log.verbose(" is end \(wordKey) \(indexPath.row) \(indexPath.section)", context: "ctxPaging")
                }
            }
        }
        return isEnd
    }
    
    func updateCell(_ cWContactCell: ContactsTableViewCell?, indexPath: IndexPath) {
        // ClientWorks
        guard cwSectionArray.count > indexPath.section - 1 else {
            log.error("ERROR - cwSectionArray not in sync", context: "TABLEVIEW")
            return
        }
        let wordKey = self.cwSectionArray[indexPath.section - 1]
        let values = self.cwSortedDictionary[wordKey]
        let cwContact = values![indexPath.row]
        cWContactCell?.asOfDateLbl.text  = cwContact.asOfDate?.toString(dateFormat: "M/d/yy")
        cWContactCell?.asOfDateLbl.isHidden = false
        cWContactCell?.nameLbl.text = (cwContact.nameValue.count > 0 && cwContact.nameValue != " ") ? cwContact.nameValue : "N.A"
        let amountValueFloat = Float(truncating: cwContact.amountValue)
        let amountValueRoundedUp = NSNumber(value: amountValueFloat.rounded(.up))
        cWContactCell?.amountLbl.text = CustomUtility.returnFormattedCurrency(amountValueRoundedUp)
    }

    
    //Warning:- Indexing for client work contacts has removed as per new requirement. If in future it comes back just uncomment this code - SB
    internal func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
            return []
        } else if lplHeaderView.segmentedControl?.selectedSegmentIndex == 1 {
            return []
        } else if lplHeaderView.segmentedControl?.selectedSegmentIndex == 2 {
            return self.phoneSectionArray
        } else {
            return []
        }
    }

    func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
            guard let index = cwSectionArray.index(of: title) else {
                return -1
            }
            return index
        } else {
            guard let index = phoneSectionArray.index(of: title) else {
                return -1
            }
            return index
        }
    }

    internal func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if indexPath.section == 0 {
            return
        } else {
            if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
                let wordKey = self.cwSectionArray[indexPath.section - 1]
                let values = self.cwSortedDictionary[wordKey]
                self.selectedCWContact = values![indexPath.row]
            } else {
                let wordKey = self.phoneSectionArray[indexPath.section - 1]
                let values = self.phoneSortedDictionary[wordKey]
                self.selectedPhoneContact = values![indexPath.row]
            }
            if isNewMessageMode {
                let profile: Profile?
                if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
                    profile = self.selectedCWContact.profile
                } else {
                    profile = ContactUtility.convertToProfile(phoneContact: self.selectedPhoneContact)
                }
                self.msgsNavigationDelegate?.didSelect(profile: profile!)
            } else {
                self.performSegue(withIdentifier: "ProfileFromContacts", sender: self)
            }
        }
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        log.verbose(segue.identifier ?? "")
        if !isNewMessageMode {
            let viewController = segue.destination as! ProfileViewController
            if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
                viewController.cwContact = self.selectedCWContact
            } else {
                viewController.phoneContact = self.selectedPhoneContact
            }
        }
    }
    
    // MARK: - SearchBar Delegates
    private func switchSearchbarPlaceholder() {
        switch lplHeaderView.segmentedControl?.selectedSegmentIndex {
        case 0:
            lplHeaderView.searchBar?.placeholder = "Search- minimum 3 characters"
        case 1:
            lplHeaderView.searchBar?.placeholder = "Search"
        default:
            break
        }
    }

    internal func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        searchBar.resignFirstResponder()
        return true
    }

    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }

    internal func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        let searchText = searchBar.text ?? ""
        if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
            searchContacts(searchText)
        }
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
        lplHeaderView.searchBar?.text = ""
        lplHeaderView.searchBar?.resignFirstResponder()
        DispatchQueue.main.async {
            if self.lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
                Session.contacts = self.allClientWorkContacts
                self.generateCWWordsDict(){}
            } else {
                self.phoneContacts = self.completePhoneContact
                self.generatePhoneWordsDict()
            }
        }
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
            // if seachbar is empty, show all the contacts previously fetched from Client Works API
            if searchText.count == 0 {
                DispatchQueue.main.async {
                    Session.contacts = self.allClientWorkContacts
                    self.generateCWWordsDict(){}
                }
            }
        } else {            
            guard let text = searchBar.text else {
                return
            }
            searchContacts(text)
        }
    }

    @objc func searchContacts(_ string: String) {
        if lplHeaderView.segmentedControl?.selectedSegmentIndex == 0 {
            if string.count >= minCharactersToSearch {
                //string.count == 0  - cancelled or cleared searchtext.
                resetCwContacts()
                fetchNextPage(true)
            }
        } else {
            var filteredPhoneContacts = [CNContact]()
            self.phoneContacts = self.completePhoneContact
            if string == "" {
        } else if string.isNumber {
                for contact in self.phoneContacts {
                    let unformatEnteredString = string.removeWhiteListedCharacters()
                    let listOfPhoneNumbers: [CNLabeledValue] = contact.phoneNumbers
                    for phoneNumberLabel in listOfPhoneNumbers {
                        let unformattedNumber = phoneNumberLabel.value.stringValue.removeWhiteListedCharacters()
                        if unformattedNumber.contains(unformatEnteredString) {
                            filteredPhoneContacts.append(contact)
                            break
                        }
                    }
                }
                self.phoneContacts = filteredPhoneContacts
        } else {
                for contact in self.phoneContacts {
                    let nameStr = contact.givenName + " " + contact.familyName
                    if nameStr.localizedCaseInsensitiveContains(string) {
                        filteredPhoneContacts.append(contact)
                    }
                }
                self.phoneContacts = filteredPhoneContacts
            }
            self.generatePhoneWordsDict()
        }
    }

    func getPermissionForContacts() {
        self.completePhoneContact = ContactUtility.deviceContacts()
        self.phoneContacts.removeAll()
        self.phoneContacts.append(contentsOf: self.completePhoneContact)
        self.generatePhoneWordsDict()
    }

    func FetchContacts() {
        // memory for this object has already allocated, don't allocate a new memory address
        self.phoneContacts.removeAll()
        self.completePhoneContact.removeAll()
        let store = CNContactStore()
        let keysToFetch = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName), CNContactPhoneNumbersKey, CNContactImageDataKey, CNContactEmailAddressesKey, CNContactPostalAddressesKey] as [Any]
        let request = CNContactFetchRequest(keysToFetch: keysToFetch as! [CNKeyDescriptor])
        do {
            try store.enumerateContacts(with: request) {
                (contact, cursor) -> Void in
                if (!contact.phoneNumbers.isEmpty) {
                }
                if (!contact.emailAddresses.isEmpty) {
                }
                
                self.completePhoneContact.append(contact)
            }
        } catch let error {
            NSLog("Fetch contact error: \(error)")
        }
        self.generatePhoneWordsDict()
    }


    //MARK: Showing popup from New Message flow
    var isNewMessageMode: Bool = false
    var msgsNavigationDelegate: MessagesNavigationDelegate?

    func setNewMessageMode() {
        self.showCancel()
        self.isNewMessageMode = true
    }

    func setContactsMode() {
        self.isNewMessageMode = false
        self.hideCancel()
    }

    func showCancel() {
        uiButtonCancel.isEnabled = true
        uiButtonCancel.tintColor = .blue
    }

    func hideCancel() {
        uiButtonCancel.isEnabled = false
        uiButtonCancel.tintColor = .clear
    }

    // MARK: - Actions
    @IBAction func uiButtonCancel_TouchUpInside(_ sender: Any) {
        self.hideCancel()
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func rightBarButtonPress() {
        displayAlertSheet()
    }

}
 
// MARK: - Segmented Control
 extension ContactsViewController: LPLHeaderDelegate {

    func searchStarted(withSearchString: String) {
        print("🤖 searchStarted")
    }
    
    @IBAction func segmentedControlChanged(withIndex: Int) {
        UIView.animate(withDuration: 2) {
            self.lplHeaderView.selectedSegmentBar.isHidden = true
        }
        switchSearchbarPlaceholder()
        reloadPage() {
            UIView.animate(withDuration: 2) {
                self.lplHeaderView.selectedSegmentBar.isHidden = false
            }
        }
    }
}
 
 extension UITableView {
    func reloadData(completion: @escaping ()->()) {
        UIView.animate(withDuration: 0, animations: { self.reloadData() }) {
            _ in completion()
        }
    }
 }

 // MARK: - Scrolling
 extension ContactsViewController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        view.endEditing(true)
        if scrollView == contactsTableView {
            let offset = scrollView.contentOffset.y
            if translucentNavigationBar {
                lplHeaderView.setYposition(offset: 0, height: topDistance, translucent: true)
            } else {
                lplHeaderView.setYposition(offset: offset, height: 0, translucent: false)
            }
        }
    }
    
    public var topDistance: CGFloat{
        get{
            if translucentNavigationBar {
                if let height = self.navigationController?.navigationBar.frame.size.height {
                    return height
                } else {
                    return 0
                }
            } else {
                return 0
            }
        }
    }
    
 }
 
 
