//
//  ProfileViewModel.swift
//  LPLMessaging
//
//  Created by Sanjeev Bharati on 8/23/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum ProfileTableViewEnum {
    case contactDetail
    case notes
}

class ProfileViewModel {

    var contact: Contact?
    var notes: [AdvisorNote?] = []
    
    func fetchAllNotes(with clientID: String, completionHandler:@escaping ()->()) {
        ServiceManager.fetchNotes(with: clientID, pageNumber: 1, pageSize: 200, isAppOnly: false) { (result) in
            
            switch result {
            case let .success(value):
                if let notes = value {
                    self.notes = notes
                }
            case let .failure(error):
                print(error)
            }
            
            completionHandler()
        }
    }
    
}
