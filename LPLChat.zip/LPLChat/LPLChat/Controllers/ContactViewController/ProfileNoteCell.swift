//
//  ProfileNoteCell.swift
//  LPLMessaging
//
//  Created by Sanjeev Bharati on 8/23/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class ProfileNoteCell: UITableViewCell {

    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet var messageContentLabel: UILabel!
    
    @IBOutlet var dateAndTimeView: UIView!
    @IBOutlet var messageDetailView: UIView!
    
    @IBOutlet var noteImageView: UIImageView!

    func configure(with date: String?, time: String?, message: String?, isCreatedByApp: Bool, indexPath: IndexPath) {
        self.dateLabel.text = date
        self.timeLabel.text = time
        self.messageContentLabel.text = message
        self.noteImageView.isHidden = !isCreatedByApp
         indexPath.row % 2 == 0 ? self.configureBackground(with: .lplLightSky) : self.configureBackground(with: .white)
    }
    
    func configureBackground(with color: UIColor) {
        self.dateAndTimeView.backgroundColor = color
        self.messageDetailView.backgroundColor = color
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        self.selectionStyle = .none
    }

}
