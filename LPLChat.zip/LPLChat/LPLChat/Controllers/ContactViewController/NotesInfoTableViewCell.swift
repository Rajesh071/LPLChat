//
//  NotesInfoTableViewCell.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class NotesInfoTableViewCell: UITableViewCell {

    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var notesTextLabel: UILabel!
    
    func configureCellWith(header: String,
                           text: String) {
        self.headerLabel.text = header
        self.notesTextLabel.text = text
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        self.selectionStyle = .none
    }
    
}
