//
//  ContactNumberTableViewCell.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

// Notes:-  This cell is being reused for both email and contact number
class ContactNumberTableViewCell: UITableViewCell {

    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    
    func configureCellWith(header: String, phoneNumber: String) {
        self.headerLabel.text = header
//        TODO: Temp fix for email: SB
        if phoneNumber.contains("@") {
            self.phoneNumberLabel.text = phoneNumber
        } else {
            self.phoneNumberLabel.text = CustomUtility.format(phoneNumber: phoneNumber)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
