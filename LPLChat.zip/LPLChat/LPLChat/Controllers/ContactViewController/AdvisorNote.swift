//
//  NotesResponse.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 8/7/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

/*
 data: [{
 "noteId": 117,
 "groupId": 14554154,
 "noteType": {
 "noteTypeId": 1,
 "noteTypeName": "Note"
 },
 "noteTitle": "Test_Today",
 "noteText": "Test_Today",
 "entryDateTime": "2018-07-31T06:04:55-07:00",
 "userName": "vigilius.booke",
 "fullName": "Vigilius Booke DevInt",
 
 "isCreatedByPhoneApp": false
 }]

 */

struct AdvisorNote: Codable, Hashable, Comparable, ChatDetailsDataType {
    
    var messageType: MessageSenderType? {
        get {
            return .advisorNote
        }
        set {
            self.messageType = .advisorNote
        }
    }
    
    var hashValue: Int {
        //create hash value using bitwise XOR operation from unique properties
        guard let noteId = noteId, let entryDateTime = entryDateTime else {
            let date = Date()
            return Int(date.timeIntervalSinceReferenceDate)
        }
        return noteId.hashValue ^ entryDateTime.hashValue
    }
    
    let noteId: Int?
    let groupId: Int?
    
    let noteTitle: String?
    let noteText: String?
    let entryDateTime: String?
    let userName: String?
    let fullName: String?
    let isCreatedByPhoneApp: Bool?
    
    let noteType: NoteType?
    
    var messageDate: Date? {
        if let dateString = entryDateTime {
            return dateString.convertToPDTDateFormat()
        }
        return nil
    }
    
    var monthAndDateOnly: String? {
        if let date = messageDate {
            return date.monthAndDateOnly()
        }
        return nil
    }
    
    var timeOnly: String? {
        if let date = messageDate {
            return date.timeOnly()
        }
        return nil
    }
    
    var dateString: String? {
        if let dateString = entryDateTime {
            guard let date = dateString.convertToPDTDateFormat() else {
                return nil
            }
            let formattedDateString = date.toString(dateFormat: "EEE, MMM d, h:mm a")
            if formattedDateString.count > 0 {
                return formattedDateString
            }
    }
        
        return nil
    }
    
    static func == (lhs: AdvisorNote, rhs: AdvisorNote) -> Bool {
        return lhs.noteId == rhs.noteId
    }
    
    static func < (lhs: AdvisorNote, rhs: AdvisorNote) -> Bool {
        return lhs.messageDate! < rhs.messageDate!
    }
}

struct NoteType: Codable {
    let noteTypeId: Int?
    let noteTypeName: String?
}
