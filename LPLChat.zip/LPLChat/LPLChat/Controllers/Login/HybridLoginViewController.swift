//
//  HybridLoginViewController.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 5/2/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import Reachability

class HybridLoginViewController: UIViewController {

    // MARK: - IBOutlets
    @IBOutlet weak var loginWebView: LoginWebView!
    
    // View Models
    var hybridLoginViewModel: HybridLoginViewModel!
    
    // MARK: - Factory Methods

    override func viewDidLoad() {
        super.viewDidLoad()

        // basic settings
        self.configure()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Register to receive network back notifications
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.reloadPageIfNeeded),
                                               name: connectionAvailableNotification,
                                               object: nil)

    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // configure old user name if any
        self.configureOldUserNameIfAny()
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.checkInternetConnection), name: .UIApplicationWillEnterForeground, object: UIApplication.shared)
        
        NotificationCenter.default.post(name: NSNotification.Name.StopIdleTimeOut,
                                        object: nil)
    }
    
    @objc func reloadPageIfNeeded() {
        
        // if user is on the login page
        if !isLoginPage() {
            return
        }
        
        self.configureLogin()
    }
    
    @objc func checkInternetConnection() {

        DispatchQueue.main.async {
            self.configureLogin()
        }
        
        let reachability = Reachability(hostName: "google.com")
        if let isReachable = reachability?.isReachable() {
            if !isReachable {
                
                // reconfigure login page if user is on the login page on webview else don't do anything
                if isLoginPage() {
                    self.configureLogin()
                }
            }
        }

    }
    

    // MARK: - Public Methods
   
    class func build(with option: LoginDisplayOptionsEnum) -> HybridLoginViewController {
        
        let storyboard = UIStoryboard(name: "HybridLoginViewController",
                                      bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"HybridLoginViewController") as! HybridLoginViewController
        
        viewController.hybridLoginViewModel = HybridLoginViewModel()
        viewController.hybridLoginViewModel.currentLoginOption = option
        
        return viewController
    }

    
    // MARK: - Private Methods
    
    private func configure() {
        
        // safecheck to instantiate view model
        if hybridLoginViewModel == nil {
            hybridLoginViewModel = HybridLoginViewModel()
        }
        
        // configure login webview
        self.configureLogin()
    }
    
    private func configureOldUserNameIfAny() {
        // display userName if any
        guard let credentials = KeychainUtility.retrieveCredentials() else {
            return
        }
        
        self.hybridLoginViewModel.oldUserName = credentials.userName
    }
    
    private func isSameUser() -> Bool {
        
        guard let userName = self.hybridLoginViewModel.oldUserName else {
            return true
        }
        
        // check if the old and new users are same or not
        // display userName if any
        guard let credentials = KeychainUtility.retrieveCredentials() else {
            return false
        }
        
        if credentials.userName.lowercased().elementsEqual(userName.lowercased()) {
            return true
        }
        
        return false
    }
    
    @objc func configureLogin() {
        
        // if user is on 2FA page don't refresh contents
        if self.is2FAPage() {
            return
        }
        
        if (self.loginWebView != nil) {
            self.loginWebView.removeFromSuperview()
        }
        
        loginWebView = LoginWebView.build(completionHandler: { (event) in
            // handler completion
            DispatchQueue.main.async {
                self.performActionOnBasisWebviewOperation(event: event)
            }
        })
        
        loginWebView.frame = self.view.bounds
        if let webview = loginWebView.loginWebView {
            webview.scrollView.bounces = false
        }
        
        self.view.addSubview(loginWebView)
        
    }
    
    func performActionOnBasisWebviewOperation(event: LoginStateEnum) {
        
        if event.rawValue.elementsEqual(LoginStateEnum.inProcess.rawValue) {
            // Login webpage url has loaded successfully in webview perform next option
//            print("login page has loaded successfully")
            
            if (TouchIDUtility.isTouchIdConfigured() && TouchIDUtility.getBiometricPref()) && !AppStateData.shared.logoutState() && self.isUserAvailable() && !self.is2FAPage() {
                
                // display Biometric prompt
                
                if !self.hybridLoginViewModel.hideTouchIdTemporarily {
                    
                    TouchIDUtility.displayTouchIdAlert { (status) in
                        
                        if status == TouchIDAuthenticationStatus.success {
                            self.hybridLoginViewModel.hideTouchIdTemporarily = true
                            print("touchID success")
                            // autofill user name and password in webview
                            self.loginWebView.submitLogin()
                        } else {
                            // navigate to manual login
                            self.hybridLoginViewModel.hideTouchIdTemporarily = true
                            print("touchID fail")
                            
                                }
                            }
                        }
                }
            
            // display userName if any
            guard let credentials = KeychainUtility.retrieveCredentials() else {
                return
            }
            
            self.loginWebView.configureUserName(credentials.userName)
            
        } else if event.rawValue.elementsEqual(LoginStateEnum.success.rawValue) {

            // remove activity indicator
            Loader.shared.remove()

            // successful login
            print("Login is successful")
            
            // start listening for idle timeout
            Router.observeIdleTimeout()
            
            /*  1. display touch id enable or disable alert if not shown earlier
             2. if Touch id is disabled earlier send user to user registration status call
             */
            
            if self.hybridLoginViewModel.currentLoginOption == .modal && self.isSameUser() {
                self.dismiss(animated: true,
                             completion: nil)
                return
            }
            
            // if login is displayed modally dismiss it.
            if self.hybridLoginViewModel.currentLoginOption == .modal && TouchIDUtility.getBiometricPref() && TouchIDUtility.isTouchIdConfigured() {
                self.dismiss(animated: true,
                             completion: nil)
            } else {
                self.checkRegistrationStatus()
            }
            
        } else {
            // failure due to any reason
            
            let reachability = Reachability(hostName: "google.com")
            if let isReachable = reachability?.isReachable() {
                
                if !isReachable {
                    self.showAlert(with: self)
                }
            }
            
            print("Login has failed")
        }
    }
    
    private func is2FAPage() -> Bool {
        
        if self.loginWebView == nil {
            return false
        }
        
        guard let webPageText = self.loginWebView.loginWebView.stringByEvaluatingJavaScript(from: "document.documentElement.outerHTML") else {
            return false
        }
        
        if webPageText.lowercased().contains("The code you receive is valid for 5 minutes".lowercased()) {
            // 2FA page is loaded
            return true
        } else {
            return false
        }
    }
    
    private func isLoginPage() -> Bool {
        
        guard let webPageText = self.loginWebView.loginWebView.stringByEvaluatingJavaScript(from: "document.documentElement.outerHTML") else {
            return false
        }
        
        if webPageText.lowercased().contains("Please enter your ClientWorks username and password".lowercased()) {
            // 2FA page is loaded
            return true
        } else {
            return false
        }
    }
    
    func showAlert(with controller: UIViewController) {
        
        DispatchQueue.main.async {
            
            let reachability = Reachability(hostName: "google.com")
            
            if let isReachable = reachability?.isReachable() {
                if isReachable && self.isLoginPage() {
                    self.configureLogin()
                    return
                }
            }
            
            AlertUtil.showAlert(with: "Sorry",
                                   message: "You are not connected to internet",                                   constructiveButtonTitle: "retry", destructiveButtonTitle: nil, constructiveActionHandler: {
                                    self.showAlert(with: controller)},
                                   destructiveActionHandler: nil,
                                   onController: controller)
        }
    }
    
    private func checkRegistrationStatus() {
        
        Loader.shared.add()

        self.hybridLoginViewModel.checkRegistrationStatus { (user,
            status) in
            
            switch(status.statusType) {
            case .sessionInvalid:
                print("Handle user session has expiration")
                // doing fallthrough this time because need directions here
                fallthrough
                
            case .fail:
                AlertUtil.showAlert(with: "Cancel",
                                        message: status.statusMessage)
                
                print("Handle, API call is fail scenarios")
                Loader.shared.remove()
                
            case .success:
                
                // reset isLogout flag
                AppStateData.shared.setLogoutState(to: false)
                
                // get user here
                if user == nil {
                    // display failuer message because user can't be nil here, display error message for now
                    //                        TODO: - Need directions to handle this case if user is nil here.
                    
                    print("missing user info")
                }
                
                // save z cookie
                self.saveZCookie()
            
                self.checkIfAdvisorIsAuthorizedToUseApp()
            }
        }
    }

    private func saveZCookie() {
        //Save All the cookies to store first//
        if CookieUtility.getCookies().contains(";z="){
            AppStateData.shared.saveCookie(cookie: CookieUtility.getCookies())
            AppStateData.shared.saveXSRFCookie(cookie: CookieUtility.getCookieValue(key: AppStateFlags.xsrfToken.rawValue))
        }
    }
    
    private func checkIfAdvisorIsAuthorizedToUseApp() {
        
        self.hybridLoginViewModel.checkAppUseAuthentication { (asatStatus,
            apiResponseStatus) in
            Loader.shared.remove()
            
            DispatchQueue.main.async {
                
                guard asatStatus.hasAccess else {
                    // if ASAT flag is enabled send user to Not authorized screen and return from here
                    print("display ASAT screen")
                    self.displayUnauthorizedScreen()
                    return
                }
                
                // display alert for very first time user come to application, touch id is disabled and if last user is changed or first time user
                var isSameUser:Bool = false
                if let credentials = KeychainUtility.retrieveCredentials() {
                    if (self.hybridLoginViewModel.oldUserName?.lowercased().elementsEqual(credentials.userName.lowercased()))! {
                        isSameUser = true
                    }
                }
                
                if (!TouchIDUtility.isTouchIdConfigured() && TouchIDUtility.getBiometricPref()) && self.isUserAvailable() && !isSameUser {
                    
                    self.displayBiometericAuthenticationAlert()
                    
                } else {
                    // User has not selected TouchID option for login, so send user directly to main or registration flow
                    self.navigateUserToRegistrationOrMainApp()
                }
            }// closure closed here
        }
    }
    
    //Check for user Availability
    func isUserAvailable() -> Bool {
        
        let defaults = UserDefaults.standard
        if defaults.value(forKey: "username") != nil {
            
            return true
        }
        
        return false
    }
    
    private func displayUnauthorizedScreen() {
            let storyboard = UIStoryboard(name: "LandingScreen", bundle: nil)
            let asatController = storyboard.instantiateViewController(withIdentifier: "ASATViewController")
            let window = UIApplication.shared.delegate!.window!!
            window.rootViewController = asatController
            UIView.transition(with: window, duration: 0.4, options: [.transitionCrossDissolve], animations: nil, completion: nil)
    }
    
    private func navigateToMain() {

            let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Main") as UIViewController
            
            if let tab = viewController as? UITabBarController {
                tab.selectedIndex = 0 //Select Contacts
            }
            self.present(viewController, animated: true, completion: nil)
    }
    
    private func navigateUserToRegistrationOrMainApp() {
        
        guard let user = self.hybridLoginViewModel.userRegStatusResponse else {
            //not able to fetch user information. Probably we need to display an alert message here with reason why not able to fetch the data.
            return
        }
        
        guard user.data.twilioNumber != nil else {
            RegistrationRouter.navigate(to: .disclaimer)
            return
        }
        
        guard user.data.callForwardNumber != nil else {
            RegistrationRouter.navigate(to: .callForward)
            return
        }
        
        guard user.data.isRegistered else {
            RegistrationRouter.navigate(to: .disclaimer)
            return
        }
        
        self.navigateToMain()
    }
    
    private func displayBiometericAuthenticationAlert() {
        
        // navigate user to registration or main app after success
        let navigateToMainOrRegistration:()->() = {
            DispatchQueue.main.async {
                self.navigateUserToRegistrationOrMainApp()
            }
        }
        
        // get the current biometric type
        let type = TouchIDUtility().biometricType()
                
        if (type.count > 0) {
            
            let alertController = UIAlertController(title: "\(type)",
                message: "Do you want to enable \(type)?", preferredStyle: UIAlertControllerStyle.alert)
            
            let okAction = UIAlertAction(title: "Enable",
                                         style: UIAlertActionStyle.default) { UIAlertAction in
                                            TouchIDUtility.enbableTouchId(value: true)
                                            navigateToMainOrRegistration()
            }
            
            let cancelAction = UIAlertAction(title: "No",
                                             style: UIAlertActionStyle.cancel) { UIAlertAction in
                                                TouchIDUtility.disableTouchIDFeature(value: false)
                                                navigateToMainOrRegistration()
            }
            
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController,
                         animated: true,
                         completion: nil)
            
        } else {
            
            navigateToMainOrRegistration()
        }
    }
}
