//
//  LoginWebView.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 5/2/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

@IBDesignable


class LoginWebView: UIView, UIWebViewDelegate {

    @IBOutlet var loginWebView: UIWebView!
    var viewModel = LoginWebviewModel()
    
    // callback to caller
    var completionHandler: LoginCompletionHandler?
    var config = Configuration()
    
    
    //MARK: - Factory Methods
    
    public class func build(completionHandler: @escaping LoginCompletionHandler) -> LoginWebView {
        let view = LoginWebView.xibView() as! LoginWebView
        view.completionHandler = completionHandler
        view.loginWebView.delegate = view

        return view
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.clearWebCookies()
        self.loadLogin()
        self.customJavaScriptManipulation()
    }
    
    
    //MARK: - Public Methods
    
    func submitLogin() {
        
        // fill form with user name and password before submitting login form
        self.retrieveCredentialsForLogin()
        
        
        self.configureUserName(self.viewModel.userName)
        self.configurePassword(self.viewModel.password)
        
        // prepare submit action
        let submitAction = "document.getElementById(\"loginForm\").submit()"
        
        // submit
        self.loginWebView.performSelector(onMainThread: #selector(UIWebView.stringByEvaluatingJavaScript(from:)),
                                          with: submitAction,
                                          waitUntilDone: true)
    }
    
    func configureUserName(_ userName: String?) {
        if let userName = userName {
            let js = "document.getElementById(\"username\").value = \"\(userName)\""
            self.loginWebView.performSelector(onMainThread: #selector(UIWebView.stringByEvaluatingJavaScript(from :) ),
                                              with: js,
                                              waitUntilDone: false)
        }
    }
    
    //MARK: - Private Methods
    
    private func retrieveCredentialsForLogin() {
        
        guard let credentials = KeychainUtility.retrieveCredentials() else {
            return
        }
        self.viewModel.userName = credentials.userName
        self.viewModel.password = credentials.password
    }
    
    private func configurePassword(_ password: String?) {
        let js = "document.getElementById(\"password\").value = \"\(password!)\""
        self.loginWebView.performSelector(onMainThread: #selector(UIWebView.stringByEvaluatingJavaScript(from:)),
                                          with: js,
                                          waitUntilDone: false)
    }
    
    
    // Webview manipulations
    private func customJavaScriptManipulation() {
        
        var js:[String] = []
        
        //Login page
        js += updateLogo(element: "document.getElementById(\"loginform-cw-header\")")
        
        //udpate text
        js.append( "document.getElementById(\"loginform-group-input-label\").innerHTML = \"Please enter your ClientWorks username and password\";")
        
        //hide forgot
        js.append( "document.getElementById(\"havingTroubleLink\").style.display =\"none\";")
        
        //hide on the go
        js.append("document.getElementById(\"loginform-panel-pii-mask\").style.display =\"none\";")
        
        //Page 2: Intermediate page
        js.append("document.getElementById('aa-mfaform-cw-logo').src = \"\";")
        js += updateLogo(element: "document.getElementById(\"aa-mfaform-cw-logo-div\")")
        
        //Page 3:2FA PAGE
        //logo
        js += updateLogo(element: "document.getElementById(\"aa-mfaform-cw-header\")")
        
        // Checkbox - select and disable - change text to my device
        //4/22 - Dont programatically disable TFA
        //js.append( "document.getElementById(\"deviceBinding\").checked = true;")
        //js.append("document.getElementById(\"deviceBinding\").disabled = true;")
        js.append("document.getElementById('aa-mfaform-devicebinding-label').innerHTML = ' I use this device often.';")
        
        //hide footer for TFA page
        js.append("document.getElementById(\"aa-mfaform-footer\").style.display = \"none\";")
        
        // hide footer view on login page
        js.append("document.getElementsByClassName(\"cwfooter-text\")[0].style.display = \"none\";")
        
        self.viewModel.pageChanges = js
    }
    
    private func updateLogo(element:String) -> [String] {
        
        var js: [String] = []
        js.append( "\(element).style.backgroundImage    =\"none\";")
        js.append( "\(element).innerHTML                = \"<span>LPL Messages</span><sup style='top:-1.5em;font-size:35%;line-height:0;vertical-align:baseline'>TM</sup>\";")
        js.append( "\(element).style.color              =\"white\";")
        js.append( "\(element).style.verticalAlign      =\"middle\";")
        js.append( "\(element).style.textAlign          =\"center\";")
        js.append( "\(element).style.lineHeight         =\"82px\";")
        js.append( "\(element).style.fontSize           =\"x-large\";")
        
        return js
    }
    
    private func displayWebViewAfterManipulation() {
        for jsItem in self.viewModel.pageChanges {
            loginWebView.performSelector(onMainThread: #selector(UIWebView.stringByEvaluatingJavaScript(from:)), with: jsItem, waitUntilDone: true)
        }
    }
    
    private func retrieveAndSaveCredentials() {
        
        let userNameJs =  "document.getElementById('username').value"
        let passwordJs =  "document.getElementById('password').value"
        
        if let username = execJs(js: userNameJs) {
            if !username.isEmpty {
                self.viewModel.userName = username
            }
        }
        
        if let pass = execJs(js: passwordJs) {
            if !pass.isEmpty {
                self.viewModel.password = pass
            }
        }
    }
    
    private func checkUserStatus() {
        
        if let storedUser = UserDefaults.standard.value(forKey: "username") {
            
            if (storedUser as? String) != self.viewModel.userName {
                
                KeychainUtility.removeCredentials(username: (storedUser as? String)!)
                TouchIDUtility.setBiometricPref(value: true)
                TouchIDUtility.enbableTouchId(value: false)
                
            }
        }
    }
    
    private func saveUserNameAndPassword() {
        // Store values if both user name and password
        if let userName = self.viewModel.userName, let pass = self.viewModel.password {
            if !userName.isEmpty && !pass.isEmpty {
                
                // save user name and password to keychain
                KeychainUtility.save(username: userName,
                                     password: pass) { (isSuccess) in
                                        if !isSuccess {
                                            print("credentials saving error")
                                        } else {
                                            print("credentials = \(String(describing: KeychainUtility.retrieveCredentials()))")
                                        }
                }
            }
        }
    }
    
    private func execJs(js:String) -> String? {
        let result = loginWebView.stringByEvaluatingJavaScript(from: js)
        
        return result
    }
    
    private func loadLogin() {
        // Execute login request with login url
//        loginWebView.loadRequest(URLRequest(url: URL(string: EnvConstants.urlLogin)!))
        loginWebView.loadRequest(URLRequest(url: URL(string: config.environment.urlLogin)!))
    }
    
    
    //MARK: WebView Delegates
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        
//        print("webViewDidFinishLoad url = \(String(describing: webView.request?.url?.absoluteString))")

        self.displayWebViewAfterManipulation()
        
        // Check for success URL, once login request execute successfully we will enter to different experiences on the app. Like ASAT, registration and main
        if webView.request?.url?.absoluteString.lowercased().range(of: config.environment.urlLogin.lowercased()) != nil {
            
            guard let completion = self.completionHandler else {
                return
            }
            completion(.inProcess)
        }
        
        Loader.shared.remove()
    }
    
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        
        print("webview shouldStartLoadWith request: \(String(describing:  request.url?.absoluteString))")
        
        Loader.shared.add(to: self.loginWebView)
        
        if (request.url?.absoluteString.contains("resume/as/authorization.ping"))!{
            // Once login service execute fetch user name and password from webpage and store them to keychain

            self.retrieveAndSaveCredentials()
        }
        
        //Storing the credentials if it is a successful login
        if request.url?.absoluteString == config.environment.urlSuccess {
            DispatchQueue.main.async {
                
                // after successful response stop webview loading
                self.loginWebView.stopLoading()
                
                //Check for existing username
                self.checkUserStatus()
                
                // save username and password
                self.saveUserNameAndPassword()
                
                guard let completion = self.completionHandler else {
                    return
                }
                
                completion(.success)
            }
            
            return false
        }
        
        return true
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        
        Loader.shared.remove()
        guard let completion = self.completionHandler else {
            return
        }
        completion(.failure)
    }
    
    
    //MARK: - TODO: - Take out this code once Phill's utility would be in
    
    private func clearWebCookies(){
        
        // Delete any associated cookies
        CookieUtility.clearCookies()
    }
    
}
