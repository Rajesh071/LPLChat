//
//  HybridLoginViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 5/2/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

/*
 This enum will decide weather login to display as popover or display at root.
 if LoginDisplayOptionsEnum is root that means thats fresh launch of application.
 if LoginDisplayOptionsEnum is modal means login is dummy after login need dismiss that screen.
 */
enum LoginDisplayOptionsEnum: Int {
    case root = 0
    case modal = 1
}

typealias RegistrationCompletionHandler = (UserRegStatusResponse?, ResponseStatus) -> ()

class HybridLoginViewModel: NSObject {
    
    var currentLoginOption: LoginDisplayOptionsEnum? = .root
    var userRegStatusResponse: UserRegStatusResponse?
    var oldUserName: String? = ""

    /* hide touchID temporarily if there is failure case to login. So far there are two case encountered
     1. Login Failure
     2. Touch Id Failure */
    var hideTouchIdTemporarily = false
    
    
    //MARK: - Webapi Calls
    
    public func checkRegistrationStatus(completionHandler : @escaping RegistrationCompletionHandler) {
        
            let oldToken = DeviceTokenHelpers.getTokenFromStore()
            let currentToken = DeviceTokenHelpers.getTokenFromApp()
            
            RegistrationService.checkRegistration(oldToken:oldToken ?? "",
                                                  newToken:currentToken ?? "" ,
                                                  completionHandler: { (user, status) in
                                                    
                                                    if let newToken = currentToken {
                                                        DeviceTokenHelpers.saveToken(token: newToken)
                                                    }
                                                    
                                                    if status.statusType == .success {
                                                        
                                                        self.userRegStatusResponse = user
                                                        
                                                        // save user's data
                                                        Session.saveUser(user?.data)
                                                    }
                                                    
                                                    completionHandler(user,
                                                                      status)
            })
        }
    
    public func checkAppUseAuthentication(completionHandler : @escaping ASATCompletionHandler) {
        ASATService.checkASAT(completionHandler: completionHandler)
    }

}
