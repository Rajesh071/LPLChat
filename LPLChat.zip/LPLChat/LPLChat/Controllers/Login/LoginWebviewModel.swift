//
//  LoginWebviewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 5/2/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

enum LoginStateEnum: String {
    case inProcess = "LoginURLHasLoaded"
    case success = "LoginIsSuccessful"
    case failure = "LoginIsFailed"
}

typealias LoginCompletionHandler = (LoginStateEnum) -> ()

class LoginWebviewModel: NSObject {
    var userName: String? = ""
    var password: String? = ""
    var pageChanges:[String] = []
}
