//
//  ContactsViewController.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import ContactsUI
import NVActivityIndicatorView

class ContactsViewController: SettingsAccessViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, NVActivityIndicatorViewable {

    @IBOutlet weak var portfolioLbl: UILabel!
    @IBOutlet weak var portfolioLblHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var uiButtonCancel: UIBarButtonItem!
    @IBOutlet weak var contactsTable: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var segmentControl: UISegmentedControl!

    var currentUser: User?

    //CW contact
    let defaultPageSize: Int = 20
    let minCharactersToSearch: Int = 3
    var pageNo: Int = 0
    var cwSectionArray = [String]()
    var cwSortedDictionary = [String: [Contacts]]()
    var selectedCWContact: Contacts!
    var totalRecords: Int?
    var isFetchingCW: Bool = false
    var hasMorePages: Bool = true

    //Phone Contact
    var phoneContacts = [CNContact]()
    var phoneSectionArray = [String]()
    var phoneSortedDictionary = [String: [CNContact]]()
    var completePhoneContact = [CNContact]()
    var selectedPhoneContact: CNContact!

    override func viewDidLoad() {
        super.viewDidLoad()

        //fetchNextPage()

        self.contactsTable.isHidden = true
        self.searchBar.delegate = self
        self.segmentControl.selectedSegmentIndex = 0
        self.segmentControl.frame = CGRect(x: self.segmentControl.frame.origin.x, y: self.segmentControl.frame.origin.y, width: self.segmentControl.frame.size.width, height: 18)
        self.portfolioLbl.text = "Portfolio Value/Unrealized G/L"
        self.currentUser = StaticDataStore.getCurrentUser()
        //self.hideCancel()
        log.verbose("DIDLOAD",context:"ctxCD")

    }

    override func viewWillAppear(_ animated: Bool) {

        super.viewWillAppear(animated)
        log.verbose("viewWillAppear",context:"ctxCD")

        resetCwContacts()
        fetchNextPage()
        
        self.contactsTable.tableFooterView = UIView()
        self.contactsTable.tableHeaderView = UIView()
//        self.contactsTable.reloadData()
//        self.contactsTable.isHidden = false
       
    }

    @IBAction func segmentvalueChanged(_ sender: Any) {
       reloadPage()
    }
    
    func reloadPage(){
        if self.segmentControl.selectedSegmentIndex == 1 {
            
            self.portfolioLbl.isHidden = true
            self.portfolioLbl.text = ""
            self.phoneSectionArray = []
            self.phoneSortedDictionary = [:]
            self.getPermissionForContacts()
            self.contactsTable.reloadData()
        } else {
            self.portfolioLbl.isHidden = false
            self.portfolioLbl.text = "Portfolio Value/Unrealized G/L"
            self.generateCWWordsDict()
        }
        self.searchBar.text = ""
        self.searchBar.resignFirstResponder()
    }

    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
        self.searchBar.text = ""

        searchContacts("")
        self.searchBar.resignFirstResponder()
    }

    func fetchNextPage() {

        hasMorePages = true
        if let totalRecordsValue = totalRecords { // initial load or new search
            if totalRecordsValue <= Session.contacts.count { //reached max server records count
                hasMorePages = false
            }
        }

        if hasMorePages {
            pageNo += 1
            fetchContactsFromService(pageNo: pageNo)
            generatePhoneWordsDict()
        }

    }

    func alert(_ msg: String) {
        let alert = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    func fetchContactsFromService(pageNo: Int) {
        isFetchingCW = true
        //TODO : SAN animation in corner of page

        let size = CGSize(width: 35, height: 35)
        startAnimating(size, message: "Fetching...", type: NVActivityIndicatorType.ballScaleRippleMultiple)
        
        log.verbose("isFetching \(pageNo)", context: ctx.Paging.rawValue)
        let searchString = searchBar.text ?? ""

        ContactService.getClients(pageNo: pageNo, pageSize: defaultPageSize, searchString: searchString) { (totalRecords, contactsFromService, status) in

            //TODO : SAN Stop animation in corner of page
            self.stopAnimating()
            self.isFetchingCW = false
            guard status.statusType == .success else {
                self.alert(status.statusMessage)
                return
            }

            if pageNo == 1 { //reset the contacts
                Session.contacts = contactsFromService!
            } else { //Append contacts
                if let contactsFromService = contactsFromService {
                    for c in contactsFromService {
                        Session.contacts.append(c)
                    }
                }
            }

            self.totalRecords = totalRecords
            self.generateCWWordsDict()
        }
    }

    func generatePhoneWordsDict() {

        self.phoneSectionArray = []
        self.phoneSortedDictionary = [:]

        for contact in self.phoneContacts {

            let firstName = contact.givenName
            if !(firstName.isEmpty) {

                let firstChar: String = "\(firstName[firstName.startIndex])"
                if firstChar != "" || firstChar != " " {

                    var upperCaseName = firstChar.uppercased()
                    let letters = NSCharacterSet.letters
                    let range = upperCaseName.rangeOfCharacter(from: letters)

                    if range == nil {

                        upperCaseName = "#"
                    }

                    if var wordValues = phoneSortedDictionary[upperCaseName] {

                        wordValues.append(contact)
                        phoneSortedDictionary[upperCaseName] = wordValues

                    } else {

                        phoneSortedDictionary[upperCaseName] = [contact]
                    }

                }
            }

        }

        self.phoneSectionArray = [String](phoneSortedDictionary.keys)
        self.phoneSectionArray = self.phoneSectionArray.sorted()
        if (self.phoneSectionArray.count != 0) && (self.phoneSectionArray[0] == "#") {

            self.phoneSectionArray.remove(at: 0)
            self.phoneSectionArray.append("#")
        }


        DispatchQueue.main.async { [unowned self] in
            self.contactsTable.reloadData()
            self.contactsTable.isHidden = false
        }


    }

    func resetCwContacts(){
        pageNo = 0
        totalRecords = nil
        Session.contacts = []
        self.cwSectionArray = []
        self.cwSortedDictionary = [:]
        generateCWWordsDict()
    }
    
    func generateCWWordsDict() {

        self.cwSectionArray = []
        self.cwSortedDictionary = [:]

        for contact in Session.contacts {

            let firstName = contact.nameValue
            if !((firstName?.isEmpty)!) {

                let firstChar: String = "\(firstName![(firstName?.startIndex)!])"
                if firstChar != "" || firstChar != " " {

                    var upperCaseName = firstChar.uppercased()
                    let letters = NSCharacterSet.letters
                    let range = upperCaseName.rangeOfCharacter(from: letters)

                    if range == nil {

                        upperCaseName = "#"
                    }

                    if var wordValues = cwSortedDictionary[upperCaseName] {

                        wordValues.append(contact)
                        cwSortedDictionary[upperCaseName] = wordValues

                    } else {
                        cwSortedDictionary[upperCaseName] = [contact]
                    }

                }
            }

        }

        self.cwSectionArray = [String](cwSortedDictionary.keys)
        self.cwSectionArray = self.cwSectionArray.sorted()
        //TODO: SAN - Shouldn't server return sorted values ?
        // TableView reloaddata is flickering -since we are inserting rows in between (A,B,#) - > (A,B,C,#)
        //        if (self.cwSectionArray.count != 0) && (self.cwSectionArray[0] == "#"){
        //
        //            self.cwSectionArray.remove(at: 0)
        //            self.cwSectionArray.append("#")
        //        }


        DispatchQueue.main.async { [unowned self] in
            self.contactsTable.reloadData()
        }


    }


    internal func numberOfSections(in tableView: UITableView) -> Int {

        if self.segmentControl?.selectedSegmentIndex == 0 {

            return self.cwSectionArray.count + 1
        } else {

            return self.phoneSectionArray.count + 1
        }
    }

    internal func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

        if section == 0 {

            return 0
        } else {

            return 28
        }
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        if section == 0 {

            return UIView()
        }
        if section != 0 {

            let myLabel = UILabel()
            myLabel.frame = CGRect(x: 15, y: 4, width: 30, height: 20)
            myLabel.font = UIFont.boldSystemFont(ofSize: 16)
            myLabel.textColor = UIColor(red: 67 / 255, green: 67 / 255, blue: 67 / 255, alpha: 1.0)

            if self.segmentControl?.selectedSegmentIndex == 0 {

                myLabel.text = self.cwSectionArray[section - 1]
            } else {

                myLabel.text = self.phoneSectionArray[section - 1]

            }
            let headerView = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 20))
            headerView.backgroundColor = UIColor(red: 249 / 255, green: 249 / 255, blue: 249 / 255, alpha: 1.0)

            headerView.addSubview(myLabel)
            return headerView
        }
        return UIView()

    }


    internal func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if section == 0 {

            return 1
        }


        if self.segmentControl?.selectedSegmentIndex == 0 {

            let wordKey = self.cwSectionArray[section - 1]

            if let values = self.cwSortedDictionary[wordKey] {

                return values.count

            }

            return 0
        } else {

            let wordKey = self.phoneSectionArray[section - 1]

            if let values = self.phoneSortedDictionary[wordKey] {

                return values.count

            }
            return 0
        }
    }

    func hasReachedEnd(indexPath: IndexPath) -> Bool {
        //Sections 1 (mynumber) + characters
        var isEnd = false
        let wordKey = self.cwSectionArray[indexPath.section - 1]
        let values = self.cwSortedDictionary[wordKey]

        if let values = values {

            if indexPath.section == cwSectionArray.count { // last section

                if values.count - 1 == indexPath.row { // last item in the last section
                    isEnd = true

                    log.verbose(" is end \(wordKey) \(indexPath.row) \(indexPath.section)", context: "ctxPaging")
                }
            }
        }

        return isEnd
    }
    
    func updateCell(_ contactsCell: ContactsTableViewCell?, indexPath: IndexPath) {
        // ClientWorks

        guard cwSectionArray.count > indexPath.section - 1 else {
            log.error("ERROR - cwSectionArray not in sync", context: "TABLEVIEW")
            return
        }

        let wordKey = self.cwSectionArray[indexPath.section - 1]
        let values = self.cwSortedDictionary[wordKey]
        let cwContact = values![indexPath.row]
        //log.verbose("\(cwContact.nameValue)",context:"ctxPaging")

        if cwContact.imageName.isEmpty {

            if cwContact.variationValue.floatValue >= 0.0 {

                contactsCell?.customerView.image = UIImage(named: "lightGreenGrayCircle")

            } else {

                contactsCell?.customerView.image = UIImage(named: "redGrayCircle")


            }
            contactsCell?.initlalLble.text = CustomUtility.returnStringInitials((cwContact.nameValue)!)
            contactsCell?.initlalLble.isHidden = false
        } else {

            contactsCell?.customerView.image = UIImage(named: cwContact.imageName)!
            contactsCell?.initlalLble.isHidden = true

        }

        //contactsCell?.asOfDateLbl.text = CustomUtility.ret
        contactsCell?.asOfDateLbl.text  = cwContact.asOfDate?.toString(dateFormat: "M/d/yy")
        contactsCell?.asOfDateLbl.isHidden = false
        contactsCell?.variationLbl.text = CustomUtility.returnFormattedCurrency(cwContact.variationValue)
        contactsCell?.variationLbl.isHidden = false

        if values![indexPath.row].variationValue.floatValue >= 0.0 {
            contactsCell?.variationLbl.textColor = UIColor(red: 104 / 255, green: 150 / 255, blue: 39 / 255, alpha: 1.0)
        } else {
            contactsCell?.variationLbl.textColor = UIColor(red: 249 / 255, green: 57 / 255, blue: 43 / 255, alpha: 1.0)
        }


        contactsCell?.nameLbl.text = cwContact.nameValue
        contactsCell?.amountLbl.text = CustomUtility.returnFormattedCurrency(cwContact.amountValue)


        if cwContact.badgeValue != 0 {

            //                    contactsCell?.smsBtn.badgeLabel.isHidden = false
            //                    contactsCell?.smsBtn.addBadgeToButon(badge: String(values![indexPath.row].badgeValue))
        } else {

            //                    contactsCell?.smsBtn.badgeLabel.isHidden = true
        }

        if cwContact.isFav {

            contactsCell?.favImage.isHidden = false
        }

        //                contactsCell?.smsBtn.isHidden = true
        //                contactsCell?.callBtn.isHidden = true
        //                contactsCell?.initlalLble.isHidden = true
    }

    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        if indexPath.section == 0 {

            let myContactsCell: ContactsTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "myContactCell", for: indexPath) as! ContactsTableViewCell)
            myContactsCell?.nameLbl.text = self.currentUser?.name
            myContactsCell?.customerView.image = UIImage(named: "N.A.")
            myContactsCell?.initlalLble.text = CustomUtility.returnStringInitials((self.currentUser?.name)!)
            
            let unformattedPhoneNumber = ContactUtility.removeSpecialCharactersFromNumber((self.currentUser?.number)!)
            let formattedNumber = CustomUtility.format(phoneNumber: unformattedPhoneNumber)
            
            myContactsCell?.amountLbl.text = "My Number:-" + " " + formattedNumber!
            
            myContactsCell?.isUserInteractionEnabled = false

            return myContactsCell!
        } else {

            if self.segmentControl?.selectedSegmentIndex == 0 {

                let contactsCell: ContactsTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "ContactsCell", for: indexPath) as! ContactsTableViewCell)
                updateCell(contactsCell, indexPath: indexPath)

                if isFetchingCW == false {

                    let isEnd = hasReachedEnd(indexPath: indexPath)

                    if isEnd {
                        fetchNextPage()
                    }
                }
                return contactsCell!
            } else {

                //                let contactsCell : ContactsTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "phoneContactsCell", for: indexPath) as! ContactsTableViewCell)
                //
                let contactsCell: ContactsTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "cnPhoneContactCell", for: indexPath) as! ContactsTableViewCell)

                let wordKey = self.phoneSectionArray[indexPath.section - 1]
                let values = self.phoneSortedDictionary[wordKey]

                let formatter = CNContactFormatter()
                contactsCell?.nameLbl.text = formatter.string(from: values![indexPath.row])
                //                if let actualNumber = values![indexPath.row].phoneNumbers.first?.value {
                //
                //                    contactsCell?.amountLbl.text = actualNumber.stringValue
                ////                    contactsCell?.smsBtn.isHidden = false
                ////                    contactsCell?.callBtn.isHidden = false
                //                }
                //                else{
                //                    contactsCell?.amountLbl.text = "N.A"
                ////                    contactsCell?.smsBtn.isHidden = true
                ////                    contactsCell?.callBtn.isHidden = true
                //
                //                }
                contactsCell?.customerView.image = UIImage(named: "N.A.")
                contactsCell?.initlalLble.text = CustomUtility.returnStringInitials((contactsCell?.nameLbl.text)!)
                contactsCell?.initlalLble.isHidden = false
                contactsCell?.favImage.isHidden = true
                //                contactsCell?.smsBtn.badgeLabel.isHidden = true

                return contactsCell!

            }

        }

    }

    internal func sectionIndexTitles(for tableView: UITableView) -> [String]? {

        if self.segmentControl?.selectedSegmentIndex == 1 {

            return self.phoneSectionArray
        } else {

            return self.cwSectionArray

        }

    }

    func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {

        if self.segmentControl?.selectedSegmentIndex == 0 {

            guard let index = cwSectionArray.index(of: title) else {

                return -1
            }
            return index
        } else {

            guard let index = phoneSectionArray.index(of: title) else {

                return -1
            }
            return index
        }

    }

    internal func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: false)

        if indexPath.section == 0 {

            return
        } else {
            if self.segmentControl?.selectedSegmentIndex == 0 {

                let wordKey = self.cwSectionArray[indexPath.section - 1]
                let values = self.cwSortedDictionary[wordKey]

                self.selectedCWContact = values![indexPath.row]
                
            } else {

                let wordKey = self.phoneSectionArray[indexPath.section - 1]
                let values = self.phoneSortedDictionary[wordKey]

                self.selectedPhoneContact = values![indexPath.row]

            }

            if isNewMessageMode {
                let profile: Profile?
                if self.segmentControl?.selectedSegmentIndex == 0 {
                    profile = self.selectedCWContact.profile
                } else {
                    profile = ContactUtility.convertToProfile(phoneContact: self.selectedPhoneContact)
                }
                self.msgsNavigationDelegate?.didSelect(profile: profile!)
            } else {
                self.performSegue(withIdentifier: "ProfileFromContacts", sender: self)
            }
        }

    }

    //
    //    func invokeChat(_ viewController:ChatDetailsViewController){
    //        if self.segmentControl?.selectedSegmentIndex == 0 {
    //
    //        } else {
    //
    //        }
    //
    //                    let number = "+17045939367"
    //                    let smsData = SMSData(imageName: "N.A.", nameValue: "N.A.", description: "",
    //                                          time: " " , badgeValue : 0,owner: .sender, numberValue: number, timeDate:NSDate() as Date,
    //                                          fromNumber:MessageService.advisorNumber,
    //                                          toNumber:number
    //                    )
    //
    //                    //let viewController = segue.destination as! ChatDetailsViewController
    //                    viewController.selectedUser = smsData
    //                    viewController.configureTheTitleViewForNav()
    //  //      self.navdel?.done()
    ////
    //       // viewController.publicFetch()
    //
    //    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        log.verbose(segue.identifier ?? "")

        if isNewMessageMode {
            //            //self.navigationController?.popViewController(animated: true)
            //            // popViewControllerAnimated
            //            let chatDetailsVC = segue.destination as! ChatDetailsViewController
            //
            //            self.invokeChat(chatDetailsVC)
            //
            //
            //            //self.dismiss(animated: true, completion: nil)
            //
            ////
            ////            var number = "+17045939367"
            ////            let smsData = SMSData(imageName: "N.A.", nameValue: "N.A.", description: "",
            ////                                  time: " " , badgeValue : 0,owner: .sender, numberValue: number, timeDate:NSDate() as Date,
            ////                                  fromNumber:MessageService.advisorNumber,
            ////                                  toNumber:number
            ////            )
            ////
            ////            let viewController = segue.destination as! ChatDetailsViewController
            ////            viewController.selectedUser = smsData
            ////            viewController.configureTheTitleViewForNav()
            ////
        } else {

            let viewController = segue.destination as! ProfileViewController

            if self.segmentControl?.selectedSegmentIndex == 0 {
                viewController.cwContact = self.selectedCWContact
            } else {
                viewController.phoneContact = self.selectedPhoneContact
            }
        }
    }

    internal func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {

        searchBar.resignFirstResponder()
        return true

    }

    internal func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        let searchText = searchBar.text ?? ""
        if self.segmentControl?.selectedSegmentIndex == 0 {


//            NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(self.searchContacts(_:)), object: searchText)
//            perform(#selector(self.searchContacts(_:)), with: searchText, afterDelay: 0.75)

            searchContacts(searchText)

        }
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if self.segmentControl?.selectedSegmentIndex == 0 {
//            NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(self.searchContacts(_:)), object: searchText)
//            perform(#selector(self.searchContacts(_:)), with: searchText, afterDelay: 0.75)
//
        } else {
            searchContacts(searchText)

        }
    }

    @objc func searchContacts(_ string: String) {

        if self.segmentControl?.selectedSegmentIndex == 0 {

            if string.count == 0 || string.count >= minCharactersToSearch {
                //string.count == 0  - cancelled or cleared searchtext.
                resetCwContacts()
                fetchNextPage()
            }
        } else {

            var filteredPhoneContacts = [CNContact]()
            self.phoneContacts = self.completePhoneContact

            if string == "" {

                self.generatePhoneWordsDict()

            } else if string.isNumber {


                for contact in self.phoneContacts {

                    let nameStr = contact.phoneNumbers
                    if let isFilterMatch = (nameStr.first?.value.stringValue)?.contains(string), isFilterMatch {

                        filteredPhoneContacts.append(contact)
                    }

                }

                self.phoneContacts = filteredPhoneContacts
                self.generatePhoneWordsDict()
            } else {

                for contact in self.phoneContacts {

                    let nameStr = contact.givenName + " " + contact.familyName

                    if (nameStr.contains(string)) {

                        filteredPhoneContacts.append(contact)
                    }

                }

                self.phoneContacts = filteredPhoneContacts
                self.generatePhoneWordsDict()

            }
        }


    }


    func getPermissionForContacts() {

        let store = CNContactStore()
        store.requestAccess(for: .contacts) { (isGranted, error) in

            if isGranted {

                self.FetchContacts()

            } else {

                self.phoneSectionArray = []
                self.contactsTable.reloadData()
            }
        }
    }

    func FetchContacts() {

        self.phoneContacts = []

        let store = CNContactStore()
        let keysToFetch = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName), CNContactPhoneNumbersKey, CNContactImageDataKey, CNContactEmailAddressesKey] as [Any]
        let request = CNContactFetchRequest(keysToFetch: keysToFetch as! [CNKeyDescriptor])
        do {
            try store.enumerateContacts(with: request) {
                (contact, cursor) -> Void in
                if (!contact.phoneNumbers.isEmpty) {
                }
                if (!contact.emailAddresses.isEmpty) {
                }
                self.phoneContacts.append(contact)
                self.completePhoneContact.append(contact)
            }
        } catch let error {
            NSLog("Fetch contact error: \(error)")
        }

        self.generatePhoneWordsDict()

    }


    //MARK: Showing popup from New Message flow

    var isNewMessageMode: Bool = false

    var msgsNavigationDelegate: MessagesNavigationDelegate?

    func setNewMessageMode() {
        self.showCancel()
        self.isNewMessageMode = true
    }

    func setContactsMode() {
        self.isNewMessageMode = false
        self.hideCancel()
    }

    func showCancel() {
        uiButtonCancel.isEnabled = true
        uiButtonCancel.tintColor = .white
    }

    func hideCancel() {
        uiButtonCancel.isEnabled = false
        uiButtonCancel.tintColor = .clear
    }

    @IBAction func uiButtonCancel_TouchUpInside(_ sender: Any) {
        self.hideCancel()
        self.dismiss(animated: true, completion: nil)
    }

    //Add Contacts button removed
    @IBAction func addContacts(_ sender: Any) {

        //        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        //
        //        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "WorkInProgress") as! WIPViewController
        //        nextViewController.screenType = .addContact
        //        self.navigationController?.pushViewController(nextViewController, animated: true)
    }

}
