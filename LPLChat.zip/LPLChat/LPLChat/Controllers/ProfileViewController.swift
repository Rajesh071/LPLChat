//
//  ProfileViewController.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/20/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import ContactsUI
import GSKStretchyHeaderView

enum StickyHeaderViewSize: CGFloat {
    case large = 300.0
    case small = 200.0
}


class ProfileViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var initialLbl: UILabel!
    @IBOutlet weak var imageView: RoundedImageView!
    @IBOutlet weak var phoneTableView: UITableView!
    var mobileNumber : String!
    var workNumber : String!
    var selectedContact : Contacts!
    @IBOutlet weak var nameLbl: UILabel!
    var nameText : String!
    var initialText : String!
    var imageName : String!
    var selectedNumber : String!
    var customHeaderView: HeaderView!

    @IBOutlet weak var marketValStackView: UIStackView!
    @IBOutlet weak var gainLossLbl: UILabel!
    @IBOutlet weak var marketValueLbl: UILabel!
    var phoneContact : CNContact!
    var cwContact : Contacts!
    var profile : Profile! // Model for this view.
    @IBOutlet weak var asOfDateLbl: UILabel!
    
    //My Work
    @IBOutlet weak var stickyHeaderContainer: UIView!
    @IBOutlet weak var tableViewContainer: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var nameInitialLabel: CustomInsetLabel!
    @IBOutlet weak var superStackView: UIStackView!
    @IBOutlet weak var marketView: UIView!
    
    var contentOffset:CGFloat = 0.0
    
    @IBOutlet weak var stikcyHeaderHeightConstraint: NSLayoutConstraint!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         prepareContact()
        
        if cwContact != nil{

            self.marketValueLbl.text = CustomUtility.returnFormattedCurrency(cwContact.amountValue)
            self.gainLossLbl.text = CustomUtility.returnFormattedCurrency(cwContact.variationValue)
            self.asOfDateLbl.text = CustomUtility.calculateStringForDate(cwContact.asOfDate!)
          
            if cwContact.variationValue.floatValue >= 0.0{
                self.gainLossLbl.textColor = UIColor(red: 104/255, green: 150/255, blue: 39/255, alpha: 1.0)
            }
            else{
                self.gainLossLbl.textColor = UIColor(red: 249/255, green: 57/255, blue: 43/255, alpha: 1.0)
            }


        }
        else{
            
            
            self.marketValueLbl.isHidden = true
            self.marketValueLbl.text = ""
            self.gainLossLbl.isHidden = true
            self.gainLossLbl.text = ""
            self.asOfDateLbl.isHidden = true
            self.asOfDateLbl.text = ""
            self.superStackView.removeArrangedSubview(self.marketView)
            self.superStackView.spacing = -10
            
        }
        self.nameLbl.text = self.profile.name
        self.nameInitialLabel?.text = self.initialText

        self.phoneTableView.tableFooterView = UIView()
        
        self.updateRoundCornersOfNameInitialLabel()

       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        

    }
    
    @IBAction func editProfileBtnClicked(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "WorkInProgress") as! WIPViewController
        nextViewController.screenType = .editProfile
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    func prepareContact(){

        if self.phoneContact != nil {
            preparePhoneContact()
        }else {
            prepareCwContact()
        }
    }
    
    func prepareCwContact(){
        
        self.profile = self.cwContact.profile
        
        if let profile = self.cwContact.profile{
            self.profile = profile
        }else{
             self.profile = Profile(name:cwContact.nameValue,
                                    phoneNumbers: [
                                        PhoneNumber(displayValue: cwContact.phoneNumber ?? "", label: "Mobile", isFav: false)]
                                        ,emails:[],addresses:[], amountValue: 0, variationValue: 0, asOfDateStr:Date().toISO8601String())
        }
        if self.cwContact.imageName.isEmpty{
            self.imageName = "N.A."
            self.initialText = CustomUtility.returnStringInitials(self.cwContact.nameValue!)
        }
        else{
            self.imageName =  self.cwContact.imageName!
            self.initialText = ""
        }
    }
    
    func preparePhoneContact(){
        
        self.profile = ContactUtility.convertToProfile(phoneContact: self.phoneContact)
        
        let formatter = CNContactFormatter()
        self.nameText = formatter.string(from: self.phoneContact )
        
        
        if self.phoneContact.phoneNumbers.count > 1 {
            
            self.mobileNumber = self.phoneContact.phoneNumbers.first?.value.stringValue
            self.workNumber = self.phoneContact.phoneNumbers[1].value.stringValue
            
        }
        else {
            
            self.mobileNumber = self.phoneContact.phoneNumbers.first?.value.stringValue
            
        }
        
        self.imageName  =  "N.A."
        self.initialText = CustomUtility.returnStringInitials(formatter.string(from: self.phoneContact)!)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func callBtnClicked(_ sender: Any) {
        
        if  self.profile.phoneNumbers.count == 0 {
            //no number to call
        }else if  self.profile.phoneNumbers.count == 1 {
             self.invokeNativeCall(self.profile.phoneNumbers[0].value)
        } else {
            
            let optionMenu = UIAlertController(title: nil, message: "Call Mobile", preferredStyle: .actionSheet)
            
            for pn in self.profile.phoneNumbers {
                let title = "\(pn.label!) : \(pn.displayValue!)"
                let callAction = UIAlertAction(title: title, style: .default, handler:
                {
                    (alert: UIAlertAction!) -> Void in
                    self.invokeNativeCall(pn.value)
                })
                
                 optionMenu.addAction(callAction)
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler:
            {
                (alert: UIAlertAction!) -> Void in
                print("Cancelled")
            })
            optionMenu.addAction(cancelAction)
            self.present(optionMenu, animated: true, completion: nil)
        }
    }
    
    
    func invokeNativeCall(_ number: String) {
        
        guard let number = URL(string: "tel://" + number) else { return }
        UIApplication.shared.open(number)
    }
    @IBAction func smsBtnClicked(_ sender: Any) {
        
        if  self.profile.phoneNumbers.count == 0 {
            //no number to call
        }else if  self.profile.phoneNumbers.count == 1 {
            self.invokeChat(self.profile.phoneNumbers![0].value)
        } else {
            
            let optionMenu = UIAlertController(title: nil, message: "Message mobile", preferredStyle: .actionSheet)
            
            for pn in self.profile.phoneNumbers {
                let title = "\(pn.label!) : \(pn.displayValue!)"
                let callAction = UIAlertAction(title: title, style: .default, handler:
                {
                    (alert: UIAlertAction!) -> Void in
                    self.invokeChat(pn.value)
                })
                
                optionMenu.addAction(callAction)
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler:
            {
                (alert: UIAlertAction!) -> Void in
                print("Cancelled")
            })
            optionMenu.addAction(cancelAction)
            self.present(optionMenu, animated: true, completion: nil)
        }
    }
    
    func invokeChat(_ number: String) {
        
        self.selectedNumber = number
        self.performSegue(withIdentifier: "ChatFromProfile", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var imageName : String!
        if self.imageName == "N.A." {
            
            imageName = ""
        }
        else{
            
            imageName = self.imageName
        }
        
        let smsData = SMSData(imageName: imageName, nameValue: self.profile.name, description: "",
                              time: " " , badgeValue : 0,owner: .sender, numberValue: self.selectedNumber, timeDate:NSDate() as Date,
            fromNumber:Session.getAdvisorVirtualNumber(),
            toNumber:self.selectedNumber, totalUnread: 0)
        
        let viewController = segue.destination as! ChatDetailsViewController
        viewController.isFromProfile = true
        viewController.selectedUser = smsData
        viewController.configureTheTitleViewForNav()
        
    }
    
    
    @IBAction func backBtnClicked(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
    internal func numberOfSections(in tableView: UITableView) -> Int{
        
        return 1
        
    }
    
    internal func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
       
        return self.profile.phoneNumbers.count + self.profile.emails.count + self.profile.addresses.count + 1
        
    }
        
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{

        //phone 3
        //address 2
        var maxIndexOfPhone : Int = 0
        var maxIndexOfEmail : Int = 0
        var maxIndexOfAddress : Int = 0
        
        if (self.profile.phoneNumbers.count > 0 ){
         
            maxIndexOfPhone = self.profile.phoneNumbers.count - 1

        }
        if (self.profile.emails.count > 0 ){

            maxIndexOfEmail = self.profile.emails.count - 1

        }
        if (self.profile.addresses.count > 0 ){

            maxIndexOfAddress = self.profile.addresses.count - 1

        }

        
        //2 0-2
        if (indexPath.row <= maxIndexOfPhone) && self.profile.phoneNumbers.count != 0 {
        
            let phoneCell : PhoneTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "ProfileContactCell", for: indexPath) as! PhoneTableViewCell)
            
            
            let phoneNumber = self.profile.phoneNumbers[indexPath.row]
            
            phoneCell?.phoneTypeLabel.text = phoneNumber.label.capitalized
            phoneCell?.numberLbl.text = CustomUtility.format(phoneNumber: phoneNumber.displayValue)
            
            return phoneCell!
        }
        else if (indexPath.row <= (self.profile.phoneNumbers.count + maxIndexOfEmail)) && self.profile.emails.count != 0 {
            
            let emailCell : PhoneTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "EmailContactCell", for: indexPath) as! PhoneTableViewCell)
            
            
            let email = self.profile.emails[indexPath.row - self.profile.phoneNumbers.count]
            
            emailCell?.phoneTypeLabel.text = email.label.capitalized
            emailCell?.numberLbl.text = email.value
            
            return emailCell!
            
        }
        else  if (indexPath.row <= (self.profile.phoneNumbers.count + self.profile.emails.count + maxIndexOfAddress)) && self.profile.addresses.count != 0{
            let addressCell : AddressTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "AddressCell", for: indexPath) as! AddressTableViewCell)
            
            /*
             0-work
             1-mobile
             2-home
             3-addresswork
             4-addressmobile
             
             */
            let address = self.profile.addresses[ indexPath.row - (self.profile.phoneNumbers.count + self.profile.emails.count)]
            
            addressCell?.uiLabelType.text = address.label.capitalized
            addressCell?.uiLabelLine1.text = address.line1
            addressCell?.uiLabelCity.text = address.city+" , "+address.state
            
            return addressCell!
        }
        else{
            
            let notesCell : AddressTableViewCell? = (tableView.dequeueReusableCell(withIdentifier: "NotesCell", for: indexPath) as! AddressTableViewCell)
            notesCell?.isUserInteractionEnabled = false
            return notesCell!
        }
     }
    
    internal func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){

        let maxIndexOfPhone = self.profile.phoneNumbers.count - 1
        
        //2 0-2
        if indexPath.row <= maxIndexOfPhone {
            
        
        let phoneNumber = self.profile.phoneNumbers[indexPath.row]

        if let phoneValue = phoneNumber.value {
            guard let number = URL(string: "tel://" + phoneValue) else {
                print("error : didSelectRow - phoneValue")
                return
            }
            UIApplication.shared.open(number)
        }
        }
        
        tableView.deselectRow(at: indexPath, animated: false)
    }
    
    //MARK: - My Strechy Work
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        let scrollAmount = contentOffset + scrollView.contentOffset.y
        
        if contentOffset >= scrollView.contentOffset.y {
            guard stikcyHeaderHeightConstraint.constant < StickyHeaderViewSize.large.rawValue else {return}
            self.stikcyHeaderHeightConstraint.constant -= scrollAmount
        } else {
            guard stikcyHeaderHeightConstraint.constant > StickyHeaderViewSize.small.rawValue else {return}
            self.stikcyHeaderHeightConstraint.constant -= scrollAmount
        }
        
        self.updateRoundCornersOfNameInitialLabel()
    }
    
    func updateRoundCornersOfNameInitialLabel() {
        self.nameInitialLabel.layer.cornerRadius = self.nameInitialLabel.frame.size.width / 2
        self.nameInitialLabel.layer.borderWidth = 0
        self.nameInitialLabel.layer.borderColor = UIColor.groupTableViewBackground.cgColor
        self.nameInitialLabel.clipsToBounds = true
    }
    
}
