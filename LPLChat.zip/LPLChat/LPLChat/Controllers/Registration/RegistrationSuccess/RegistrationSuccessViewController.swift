//
//  RegistrationSuccessViewController.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class RegistrationSuccessViewController: BaseViewController {

    @IBOutlet weak var actualNumberLabel: UILabel!
    @IBOutlet weak var virtualNumberLabel: UILabel!
    
    var registrationSuccessViewModel: RegistrationSuccessViewModel?
    
    
    // MARK: - Factory Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.configureUI()
    }

    class func build(with viewModel: RegistrationSuccessViewModel) -> RegistrationSuccessViewController {
        let storyboard = UIStoryboard(name: "Registration",
                                      bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"RegistrationSuccessViewController") as! RegistrationSuccessViewController
        viewController.registrationSuccessViewModel = viewModel
        
        return viewController
    }
    
    // MARK: - Private Methods
    
    func configureUI() {
        self.actualNumberLabel.text = NumberUtil.format(phoneNumber: (self.registrationSuccessViewModel?.actualPhoneNumber)!)
        
        self.virtualNumberLabel.text = NumberUtil.format(phoneNumber: (self.registrationSuccessViewModel?.virtualPhoneNumber)!)
    }
    
    func navigateToMain() {
        // save data to user
        AppStateData.shared.actualNumber = self.registrationSuccessViewModel?.actualPhoneNumber
        AppStateData.shared.virtualNumber = self.registrationSuccessViewModel?.virtualPhoneNumber
        
        Session.updateUser(twilioNumber: (self.registrationSuccessViewModel?.virtualPhoneNumber)!,
                           callFwdNumber: AppStateData.shared.actualNumber!)
        
        // UI update should happen on main thread
        DispatchQueue.main.async {
            let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Main") as UIViewController
            
            if let tab = viewController as? UITabBarController {
                tab.selectedIndex = 1 //Select Contacts
            }
            self.present(viewController, animated: true, completion: nil)
        }
    }
    
    
    // MARK: - IBAction Methods
    
    @IBAction func getStartedButtonPressed() {
        self.navigateToMain()

    }

}
