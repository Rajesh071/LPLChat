//
//  RegistrationSuccessViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class RegistrationSuccessViewModel: NSObject {
    
    var actualPhoneNumber: String?
    var virtualPhoneNumber: String?

}
