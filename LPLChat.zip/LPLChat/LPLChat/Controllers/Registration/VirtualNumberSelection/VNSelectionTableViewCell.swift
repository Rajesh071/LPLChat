//
//  VNSelectionTableViewCell.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/3/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

class VNSelectionTableViewCell: UITableViewCell {

    @IBOutlet weak var phoneNumberLabel: UILabel!
    
    func configure(phoneNumber: String) {
        self.phoneNumberLabel.text = phoneNumber;
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
