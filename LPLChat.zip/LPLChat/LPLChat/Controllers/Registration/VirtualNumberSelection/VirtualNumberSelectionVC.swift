//
//  VirtualNumberSelectionVC.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/3/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

class VirtualNumberSelectionVC: BaseViewController, UITableViewDataSource, UITableViewDelegate {
    
    // IBOutlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var infoView: UIView!

    var virtualNumberVM: VirtualNumberSelectionViewModel?
    
    //MARK: - Factory Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.configure()
    }

    
    //MARK: - Public Methods

    class func buildViewController(with viewModel: VirtualNumberSelectionViewModel) -> VirtualNumberSelectionVC {
        let storyboard = UIStoryboard(name: "Registration",
                                      bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"VirtualNumberSelectionVC") as! VirtualNumberSelectionVC
        viewController.virtualNumberVM = viewModel
        
        return viewController
    }
    
    
    //MARK: - Private Methods
    
    func configure() {
        self.configureTableView()
    }
    
    func selectVirtualNumber() {
        self.showIndicator()
        self.virtualNumberVM?.registerVirtualNumber({ (result) in
            self.removeIndicator()
            
            switch result {
            case .success(_):
                self.navigateToCallForwarding()
            case let .failure(error):

                AlertUtil.showAlert(with: "Error", message: String.readableFormOf(error), onController: self)
                print(error)
            }
        })
    }
    
    func configureTableView() {
        
        self.tableView.rowHeight = UITableViewAutomaticDimension
        // hide unused cell
        self.tableView.tableFooterView = self.infoView
        
        // register cell
        self.tableView.register(UINib.init(nibName: "VNSelectionTableViewCell",
                                           bundle: nil),
                                forCellReuseIdentifier: "VNSelectionTableViewCell")
        
    }
    
    func tableFooterView() -> UIView {
        
        let view = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 100))
        view.backgroundColor = UIColor.blue
        
        return view
    }

    func navigateToCallForwarding() {
        // navigate to call forwarding number screen
        
        DispatchQueue.main.async {
            self.performSegue(withIdentifier: "callForwarding",
                              sender: self)
        }
    }
    
    func displayConfirmationAlert() {
        // display alert
        AlertUtil.showAlert(with: "Confirm Number",
                               message: "You can not change VBN later! Please confirm",
                               constructiveButtonTitle: "Ok",
                               destructiveButtonTitle: "Cancel",
                               constructiveActionHandler: {
                                
                                DispatchQueue.main.async {
                                    self.selectVirtualNumber()
                                }
        },
                               destructiveActionHandler: {
                                // dismiss alert
                                
        }, onController: self)
        
    }
    
    
    // MARK: - UITableView Datasource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.virtualNumberVM?.vitualNumbers().count)!
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "VNSelectionTableViewCell",
                                                 for: indexPath) as! VNSelectionTableViewCell
        let phone = self.virtualNumberVM?.vitualNumbers()[indexPath.section]
        cell.configure(phoneNumber: phone!)
        
        return cell
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return section == 0 ? 0 : 10
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int){
        view.tintColor = UIColor.clear
    }
    
    func tableView(_ tableView: UITableView,
                   didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath) as! VNSelectionTableViewCell
        
        cell.pulsate()
        self.virtualNumberVM?.selectedVirtualNumber = self.virtualNumberVM?.vitualNumbers()[indexPath.section]
        
        cell.roundCorner(cornerRadius: 0.0,
                          borderWidth: 2.0,
                          borderColor: UIColor.white)
        
        // reset all cells
        resetAllCellsToDefault()
        
        cell.phoneNumberLabel.font = UIFont(name: "Helvetica Bold",
             size: 18)
        
        // display number selection confirmation alert
        self.displayConfirmationAlert()
    }
    
    func resetAllCellsToDefault() {
        
        for cell in self.tableView.visibleCells {
            let currentCell = cell as! VNSelectionTableViewCell
            currentCell.phoneNumberLabel.font = UIFont(name: "Helvetica",
                                                size: 18)
        }
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier?.elementsEqual("callForwarding"))! {
            let viewController = segue.destination as! SelectCallForwardingViewController
            viewController.selectCallForwardingVM = SelectCallForwardingViewModel()
            
            viewController.selectCallForwardingVM?.selectedVirtualNumber = self.virtualNumberVM?.selectedVirtualNumber
        }
    }
    
}
