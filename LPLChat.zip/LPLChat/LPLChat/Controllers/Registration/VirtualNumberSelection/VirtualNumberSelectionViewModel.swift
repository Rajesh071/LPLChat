
//
//  VirtualNumberSelectionViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/13/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class VirtualNumberSelectionViewModel: NSObject {
    
    var user: ModelUser?
    
    var selectedVirtualNumber: String?
    
    func vitualNumbers() -> [String] {
        
        var phoneNumbers:[String] = []
        if let contactNumbers = self.user?.phoneNumbers {
            
            for phoneNumber in contactNumbers {
                phoneNumbers.append(NumberUtil.format(phoneNumber: phoneNumber)!)
            }
        }
        
        return phoneNumbers
    }
    
    func registerVirtualNumber(_ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        
        /* remove formatting. Twillio API can take number with +1, 1 and with correct phone number. Below are the format
         +14086617865
         14086617865
         4086617865
 
         */
        let pureNumber = NumberUtil.removeFormatting(self.selectedVirtualNumber!)
        ServiceManager.registerVirtualNumber(pureNumber,
                                             completionHandler)
    }
}
