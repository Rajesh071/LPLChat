//
//  VirtualNumberViewModel.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/12/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class VirtualNumberViewModel: NSObject {
    
    func retrieveUser(_ completionHandler: @escaping GenericCompletionHandler<ModelUser>) {
        ServiceManager.retriveUser(completionHandler)
    }

    func retrieveNumbers(city:String, state:String, _ completionHandler: @escaping GenericCompletionHandler<[RetrieveNumberResponse]>) {
        ServiceManager.retriveNumbers(city:city, state:state, completionHandler)
    }
}
