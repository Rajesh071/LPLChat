//
//  BaseViewController.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/4/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit
import NVActivityIndicatorView


class BaseViewController: UIViewController, NVActivityIndicatorViewable {
    
    @IBOutlet weak var backgroundImageView: UIImageView!
    @IBOutlet weak var topConstraintForSmallScreen: NSLayoutConstraint?
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        addKeyboardNotifications()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        guard let topConstraint = self.topConstraintForSmallScreen else {
            return
        }
        
        // move screen up for smaller devices
        topConstraint.constant = UIScreen.main.sizeType == .iPhone5 ? 20 : 51
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    //MARK: - IBAction Methods
    
    @IBAction func pop() {
        self.view.window?.endEditing(true)
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func dismiss() {
        self.view.window?.endEditing(true)
        self.dismiss(animated: true,
                     completion: nil)
    }
    
    
    //MARK: - Keyboard Notifications
  
    func addKeyboardNotifications() {
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(keyboardWillShow(notification:)),
                                               name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(keyboardWillHide(notification:)),
                                               name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            let duration = notification.userInfo![UIKeyboardAnimationDurationUserInfoKey] as! Double
            // if using constraints
            // bottomViewBottomSpaceConstraint.constant = keyboardSize.height
            self.view.frame.origin.y -= keyboardSize.height
            UIView.animate(withDuration: duration) {
                self.view.layoutIfNeeded()
            }
        }
    }
    @objc func keyboardWillHide(notification: NSNotification) {
        
        let duration = notification.userInfo![UIKeyboardAnimationDurationUserInfoKey] as! Double
        //if using constraint
        //        bottomViewBottomSpaceConstraint.constant = 0
        self.view.frame.origin.y = 0
        UIView.animate(withDuration: duration) {
            self.view.layoutIfNeeded()
        }
    }
    
    
    //MARK: - Activity indicator
    
    func showIndicator() {
        DispatchQueue.main.async {
            let size = CGSize(width: 35, height: 35)
            self.startAnimating(size, message: "Loading...", type: NVActivityIndicatorType.ballScaleRippleMultiple)
        }
    }
    
    func removeIndicator() {
        DispatchQueue.main.async {
            self.stopAnimating()
        }
    }
    
    
    func errorAlert(msg:String){
        //TODO : Sanjeev - style error
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }

}
