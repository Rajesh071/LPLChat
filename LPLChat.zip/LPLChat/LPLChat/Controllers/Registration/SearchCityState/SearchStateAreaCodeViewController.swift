//
//  SearchStateAreaCodeViewController.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/4/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

typealias SelectStateAreaCodeCompletionHandler = (([RetrieveNumberResponse], StateAreaCodes) -> ())

class SearchStateAreaCodeViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchTextField: UITextField!

    var viewModel: SearchStateAreaCodeViewModel!
    var stateAreaCodeList: [StateAreaCodes]?
    var selectStateAreaCodeCompletionHandler: SelectStateAreaCodeCompletionHandler?
    
    //MARK: - Factory Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.configure()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        searchTextField.becomeFirstResponder()
    }
    
    
    // MARK: - Public methods
   
    class func buildWith(completionHandler: SelectStateAreaCodeCompletionHandler?) -> SearchStateAreaCodeViewController {
        let storyboard = UIStoryboard(name: "Registration", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"SearchStateAreaCodeViewController") as! SearchStateAreaCodeViewController
        viewController.selectStateAreaCodeCompletionHandler = completionHandler
        
        return viewController
    }
    
    
    // MARK: - Private methods
    
    func configure() {

        // removing unused tableview rows
        self.tableView.tableFooterView = UIView()
        
        searchTextField.clearButtonMode = .whileEditing

        // ViewModel
        viewModel = SearchStateAreaCodeViewModel()
    }
    
    func dismiss(numberList: [RetrieveNumberResponse], stateAreaCode: StateAreaCodes) {
        
            if numberList.count > 0 {
                // impelement a completion handler with data
                if self.selectStateAreaCodeCompletionHandler != nil {
                    self.selectStateAreaCodeCompletionHandler!(numberList, stateAreaCode)
                    
                    // pop tableview
                    self.dismiss(animated: true,
                                 completion: nil)
                }
            } else {
                // display message
                AlertUtil.showAlert(with: "Sorry",
                                        message: "We didn't find any Virtual Business Number (VBN) for this city")
            }
    }
    

    // MARK: - Tableview delegates and datasources

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var rowCount = 0
        
        if let stateAreaCodeList = stateAreaCodeList {
            rowCount = stateAreaCodeList.count
        }
        
        return rowCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "identifier",
                                              for: indexPath) as! SearchTableViewCell
        
        let stateAreaCode = stateAreaCodeList![indexPath.row]
        if let state = stateAreaCode.state, let areaCode = stateAreaCode.areaCode {
            cell.titleLabel.text = " \(state) - \(areaCode)"
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath,
                              animated: true)
        
        searchTextField.resignFirstResponder()
        self.showIndicator()
        
        let stateAreaCode = stateAreaCodeList![indexPath.row]
        
        if let state = stateAreaCode.state, let areaCode = stateAreaCode.areaCode {
            RemoteDataManager.retreiveNumbers(state: state, areaCode: areaCode) { (result) in
                self.removeIndicator()
                switch result {
                case let .success(value):
                    let displayAlert:() -> Void = {
                        DispatchQueue.main.async {
                            AlertUtil.showAlert(with: "", message: "Working on getting VBN for this area code.\nPlease select another to continue", onController: self)
                        }
                    }
                    guard let numbers = value else {
                        displayAlert()
                        return
                    }
                    if numbers.count == 0 {
                        displayAlert()
                    } else {
                        self.dismiss(numberList: numbers, stateAreaCode: self.stateAreaCodeList![indexPath.row])
                    }
                case let .failure(error):
                    AlertUtil.showAlert(with: "Error", message: error.localizedDescription, onController: self)
                }
            }
        }
    }
    
    //MARK: - Textfield delegates
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

        // Get invalid characters
        var lplValidCharacterSet = NSCharacterSet.alphanumerics
        lplValidCharacterSet.insert(" ")
        let invalidChars = lplValidCharacterSet.inverted
        if let _ = string.rangeOfCharacter(from: invalidChars) {
            let alert = UIAlertController(title: nil, message: "Please enter only alphanumeric characters.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)

            return false
        } else {
            var textFieldText = textField.text!
            if string.utf16.count == 0 {
                // delete is pressed
                textFieldText = String.init(textFieldText.dropLast())
            } else {
                textFieldText = textField.text! + string
            }
            if (textFieldText.count > 0)  {
                self.viewModel.retrieveStateAreaCodes(searchText: textFieldText) { (result) in
                    switch result {
                    case let .success(value):
                        DispatchQueue.main.async {
                            self.stateAreaCodeList = value
                            self.tableView.reloadData()
                        }
                    case let .failure(error):
                        self.errorAlert(msg: error.localizedDescription)
                    }
                }
            } else {
                self.clearTextField()
            }
            return true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        self.clearTextField()
        return false
    }
    
    @IBAction func textFieldTextChange() {
        if searchTextField.text!.count > 1 {
            if searchTextField.text!.hasWhiteSpaceOnly() {
                searchTextField.text = " "
                self.displayErrorAlert()
            }
        }
    }
    
    func displayErrorAlert() {
        AlertUtil.showAlert(with: "",
                            message: "Please enter only alphanumeric characters.",
                            onController: self)
        
    }
    
    func clearTextField() {
        self.searchTextField.text = ""
        self.stateAreaCodeList = []
        self.tableView.reloadData()
    }
    
}
