//
//  SearchTableViewCell.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/12/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class SearchTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
