//
//  SearchStateAreaCodeViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/12/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class SearchStateAreaCodeViewModel: NSObject {

    func retrieveStateAreaCodes(searchText:String, _ completionHandler: @escaping GenericCompletionHandler<[StateAreaCodes]>) {
        RemoteDataManager.retrieveStateAreaCodes(searchText,pageNo: 1, pageSize: 50, completionHandler)
    }
    
// 💢 Dead Code?
//    static func retreiveNumbers(city:String,
//                                state:String,
//                                _ completionHandler: @escaping GenericCompletionHandler<[RetrieveNumberResponse]>) {
//        ServiceManager.retreiveNumbers(city: city,
//                                       state: state,
//                                       completionHandler)
//    }
    
}

