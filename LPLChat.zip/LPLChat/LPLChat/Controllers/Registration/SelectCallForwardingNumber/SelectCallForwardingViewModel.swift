//
//  SelectCallForwardingVM.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

enum CallForwardingEnum {
    case setup
    case edit
}

class SelectCallForwardingViewModel: NSObject {

    var selectedVirtualNumber: String?
    var configurationType: CallForwardingEnum = .setup
    
    func verifyCallForward(_ callForwardNumber:String,
                           _ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        // remove + if there is any
        let unformattedNumber = NumberUtil.removeFormattingAndPlus(callForwardNumber)
        
        ServiceManager.verifyCallForward(unformattedNumber,
                                         completionHandler)
    }
    
}
