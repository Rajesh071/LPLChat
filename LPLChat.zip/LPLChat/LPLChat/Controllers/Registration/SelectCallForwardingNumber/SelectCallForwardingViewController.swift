//
//  SelectCallForwardingViewController.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/5/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

class SelectCallForwardingViewController: BaseViewController, UITextFieldDelegate {

    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var virtualNumberLabel: UILabel!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var backButton: UIButton!

    //comment:-  make naming consistent
    @IBOutlet weak var vbnOrCallForwardingLabel: UILabel!
    @IBOutlet weak var callForwardingTextLabel: UILabel!

    var selectCallForwardingVM: SelectCallForwardingViewModel?
    
    //MARK: - Factory Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.configure()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
       
        // set textfield input accessoryView
        let keyboardAccessoryView = AccessoryView.build()
        keyboardAccessoryView.doneCompletionHandler = {
            // done button pressed
            DispatchQueue.main.async {
                
                if (self.phoneNumberTextField.text?.utf16.count)! >= 17 {
                    self.nextButton.enabledState()
                } else {
                    self.nextButton.disabledState()
                }
                self.phoneNumberTextField.resignFirstResponder()
            }
        }
        
        self.phoneNumberTextField.inputAccessoryView = keyboardAccessoryView
    }
    
    // Private Methods
  
    func configure() {
        self.nextButton.disabledState()
        
        if self.selectCallForwardingVM?.configurationType == CallForwardingEnum.edit {
            self.backButton.isHidden = false
            self.vbnOrCallForwardingLabel.text = "Your current Call Forwarding Number is"
            self.callForwardingTextLabel.text = "Do you want to change your Call Forwarding Number?"
            
            guard let callForwardingNumber = Session.user?.callForwardNumber else {
                return
            }
            self.virtualNumberLabel.text = NumberUtil.format(phoneNumber: (callForwardingNumber))
        } else {
            if let number = self.selectCallForwardingVM?.selectedVirtualNumber {
                self.virtualNumberLabel.text = NumberUtil.format(phoneNumber: number)
            }
        }
        
    }
    
    func navigateToVerifyScreen() {
        DispatchQueue.main.async {
            self.performSegue(withIdentifier: "contactVerficiation",
                              sender: self)
        }
    }

    
    // IBAction Methods

    @IBAction func nextButtonPressed() {
    
        self.showIndicator()
       
       
       // test
        
        if self.selectCallForwardingVM == nil {
            self.selectCallForwardingVM = SelectCallForwardingViewModel()
        }
        self.selectCallForwardingVM?.verifyCallForward(self.phoneNumberTextField.text!,
                                                       { (result) in
                                                        
                                                        self.removeIndicator()
                                                        
                                                            switch result {
                                                            case .success(_):
                                                                self.navigateToVerifyScreen()
                                                            case let .failure(error):
                                                                print(error)
                                                                AlertUtil.showAlert(with: "Error", message: error.localizedDescription, onController: self)
                                                        }
        })
    
    }
    
    
    // Public Methods
    
    class func buildViewController(with viewModel: SelectCallForwardingViewModel) -> SelectCallForwardingViewController? {
        let storyboard = UIStoryboard(name: "Registration",
                                      bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"SelectCallForwardingViewController") as! SelectCallForwardingViewController
        viewController.selectCallForwardingVM = viewModel
        
        return viewController
    }
    
    
    //MARK: - Textfield delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if (textField == self.phoneNumberTextField) && textField.text == ""{
            textField.text = "+1" // or "+7 ("
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        self.nextButton.disabledState()

        if textField == self.phoneNumberTextField {
            let oldString = textField.text!
            let newString = oldString.replacingCharacters(in: Range(range, in: oldString)!, with: string)
            
            let components = newString.components(separatedBy: CharacterSet.decimalDigits.inverted)
            let numString = components.joined(separator: "")
            let length = numString.count
            
            if newString.count < oldString.count && newString.count >= 2 {
                return true                                 // backspace to work and don`t deleting first "+"
            }
            if length < 1 || length > 11 {
                return false                                // don`t deleting first "+"
            }
            
            var indexStart, indexEnd: String.Index
            var maskString = "", template = ""
            var endOffset = 0
            
            if length >= 1 {
                maskString += "+"
                indexStart = numString.index(numString.startIndex, offsetBy: 0)
                indexEnd = numString.index(numString.startIndex, offsetBy: 1)
                maskString += String(numString[indexStart..<indexEnd]) + " ("
            }
            if length > 1 {
                endOffset = 4
                template = ") "
                if length < 4 {
                    endOffset = length
                    template = ""
                }
                indexStart = numString.index(numString.startIndex, offsetBy: 1)
                indexEnd = numString.index(numString.startIndex, offsetBy: endOffset)
                maskString += String(numString[indexStart..<indexEnd]) + template
            }
            if length > 4 {
                endOffset = 7
                template = "-"
                if length < 7 {
                    endOffset = length
                    template = ""
                }
                indexStart = numString.index(numString.startIndex, offsetBy: 4)
                indexEnd = numString.index(numString.startIndex, offsetBy: endOffset)
                maskString += String(numString[indexStart..<indexEnd]) + template
            }
            if length > 7 {
                indexStart = numString.index(numString.startIndex, offsetBy: 7)
                indexEnd = numString.index(numString.startIndex, offsetBy: length)
                maskString += String(numString[indexStart..<indexEnd])
            }
            
            textField.text = maskString
            //if also need real phone number - noMask
            //print("real PhonNum (without mask) = +\(numString)")
            if (length == 11) {
                //dimiss kayboard
                self.nextButton.enabledState()
            }
            
            return false
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        
        textField.resignFirstResponder()
        return true
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier?.elementsEqual("contactVerficiation"))! {
            
            let viewController = segue.destination as! VerifyPhoneNumberViewController
            viewController.verifyPhoneNumberViewModel = VerifyPhoneNumberViewModel()
            
            viewController.verifyPhoneNumberViewModel?.actualPhoneNumber = self.phoneNumberTextField.text
            
            // Edit existing or Setup a new Call Forwarding Number
            if self.selectCallForwardingVM?.configurationType == .edit {
                viewController.verifyPhoneNumberViewModel?.newCallForwarding = self.phoneNumberTextField.text!
            } else {
                viewController.verifyPhoneNumberViewModel?.virtualPhoneNumber = self.selectCallForwardingVM?.selectedVirtualNumber
            }
        }
    }
    
}
