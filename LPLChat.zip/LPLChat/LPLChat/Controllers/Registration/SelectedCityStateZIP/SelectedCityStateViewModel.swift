//
//  SelectedStateAreaCodeViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/13/18.
//  Copyright © 2018 LPL. All rights reserved.
//


/*
 can use hardcoded numbers: "+1 (858) 703-5772 for demo only
 */

import UIKit

class SelectedStateAreaCodeViewModel: NSObject {

    var user: ModelUser?
    
    func getStateAreaCodesTitle() -> String? {
        
        var stateAreaCodeString = ""
        var areaCode: String = ""
        var stateValue: String? = ""

// 💢 Dead Code?
//        if let city = user?.city {
//            // new logic
//
//            let cityComponents: [String] = city.components(separatedBy: " ")
//
//            var flag = false
//            for componenet in cityComponents {
//                flag = true
//                let firstChar = "\(componenet.first!)".capitalized
//                let camelString = firstChar + componenet.dropFirst().lowercased()
//
//                areaCode.append(camelString + " ")
//            }
//
//            if flag {
//                areaCode = String(areaCode.dropLast(1))
//            }
//        }
        
        if let phoneNumbers = user?.phoneNumbers {
            let phone = phoneNumbers[0]
            let startingIndex = phone.index(phone.startIndex, offsetBy: 2)
            let endingIndex = phone.index(phone.endIndex, offsetBy: -7)
            let areaCodeSubString = phone[startingIndex..<endingIndex]
            areaCode = String(areaCodeSubString)
        }
        
        if let state = user?.state {
            stateValue = state.uppercased()
        }
        
        if (areaCode.count) > 0 && (stateValue?.count)! > 0 {
            if let state = stateValue {
                stateAreaCodeString = state + " - " + areaCode
            }
        } else if (areaCode.count) > 0 && (stateValue?.count)! <= 0 {
            stateAreaCodeString = areaCode
        } else if (areaCode.count) <= 0 && (stateValue?.count)! > 0 {
            if let state = stateValue {
                stateAreaCodeString = state
            }
        } else {
            stateAreaCodeString = "Search"
        }
        
     return stateAreaCodeString
        
    }
    
}
