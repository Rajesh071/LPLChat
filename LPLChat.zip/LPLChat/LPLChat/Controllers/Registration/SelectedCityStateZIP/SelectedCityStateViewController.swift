//
//  SelectedStateAreaCodeViewController.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/4/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

class SelectedStateAreaCodeViewController: BaseViewController, CAAnimationDelegate {

    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var selectedStateLabel: UILabel!

    var selectStateAreaCodeViewModel: SelectedStateAreaCodeViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureUI()
    }

    //MARK: - Public Methods
    
    class func buildWithViewModel(viewModel: SelectedStateAreaCodeViewModel?) -> SelectedStateAreaCodeViewController {
        let storyboard = UIStoryboard(name: "Registration", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"SelectedStateAreaCodeViewController") as! SelectedStateAreaCodeViewController
        viewController.selectStateAreaCodeViewModel = viewModel
        
        return viewController
    }
    
    
    //MARK: - Private Methods
    
    func configureUI() {
        
        DispatchQueue.main.async {
            
            if let phones = self.selectStateAreaCodeViewModel?.user?.phoneNumbers {
                if phones.count > 0 {
                    self.nextButton.enabledState()
                self.searchButton.setTitle(self.selectStateAreaCodeViewModel?.getStateAreaCodesTitle(),
                                                  for: .normal)
                }
            } else {
                self.nextButton.disabledState()
                self.selectedStateLabel.text = "Search by State or Area Code"
            }
            
        }
    }
    

    //MARK: - IBActions
    
    @IBAction func nextButtonPress() {
        self.nextButton.pulsate()

    }
    
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier?.elementsEqual("SearchStateAreaCodeSegue"))! {
            let viewController = segue.destination as! SearchStateAreaCodeViewController
            
            // assign completion handler to get response back
            viewController.selectStateAreaCodeCompletionHandler = { list, stateAreaCode in
                if list.count > 0 {
                    var phones: [String] = []
                    
                    for contact in list {
                        phones.append(contact.phone_number!)
                    }
                    self.selectStateAreaCodeViewModel?.user?.phoneNumbers = phones
                    self.selectStateAreaCodeViewModel?.user?.state = stateAreaCode.state
                }
                
                // enable or disable UI state
                self.configureUI()
            }
        } else if (segue.identifier?.elementsEqual("DisplayVirtualNumber"))! {
            let viewController = segue.destination as! VirtualNumberSelectionVC
            viewController.virtualNumberVM = VirtualNumberSelectionViewModel()
            viewController.virtualNumberVM?.user = self.selectStateAreaCodeViewModel?.user
        }
    }

}
