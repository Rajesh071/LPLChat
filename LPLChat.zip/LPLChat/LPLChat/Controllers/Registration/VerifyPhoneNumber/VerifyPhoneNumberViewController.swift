//
//  VerifyPhoneNumberViewController.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/4/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

class VerifyPhoneNumberViewController: BaseViewController, UITextFieldDelegate {
    
    @IBOutlet weak var actualPhoneNumber: UILabel?
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var textfieldContainer: UIView!

    @IBOutlet weak var textfield1: CustomTextfield!
    @IBOutlet weak var textfield2: CustomTextfield!
    @IBOutlet weak var textfield3: CustomTextfield!
    @IBOutlet weak var textfield4: CustomTextfield!
    
    var textFieldList: [CustomTextfield]! = []
    
    @IBOutlet weak var blurView: UIVisualEffectView!
    
    var verifyPhoneNumberViewModel: VerifyPhoneNumberViewModel?
    
    
    //MARK: - Factory Method
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.configureUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.textFieldList = [textfield1,
                              textfield2,
                              textfield3,
                              textfield4]
        
        // add keyboard for small screens
        if UIScreen.main.sizeType == .iPhone5 {
         addInputAccessoryViewToAllKeyboards()
        }
        
        textfield1.becomeFirstResponder()
    }
    
    
    //MARK: - Action Method Pressed
    
    @IBAction func resendCodePressed() {
        
        self.enableOrDisableResendCode(isEnabled: false)
        
        self.verifyPhoneNumberViewModel?.verifyCallForward({ (result) in
            
            self.enableOrDisableResendCode(isEnabled: true)
            
            switch result {
            case .success(_):
                break
            case let .failure(error):
                AlertUtil.showAlert(with: "Error", message: error.localizedDescription, onController: self)
                
            }
        })
    }
    
    func enableOrDisableResendCode(isEnabled: Bool) {
        DispatchQueue.main.async {
            self.view.isUserInteractionEnabled = isEnabled
            self.blurView.isHidden = isEnabled
        }
    }
    
    
    @IBAction func doneButtonPressed() {
        // validate all the textfiled texts and then send user to success screen
        
        // resigning textfields from view before calling API
        self.view.endEditing(true)
        
        self.showIndicator()
        self.verifyPhoneNumberViewModel?.verifyTokenAndPhone(token: self.consolidatedText(), { (result) in
            self.removeIndicator()
            switch result {
            case .success(_):
                
                self.navigateToSuccess()
                
            case let .failure(error):
                
                DispatchQueue.main.async {
                    self.textfieldContainer.shake()
                    self.nextButton.disabledState()
                    
                    AlertUtil.showAlert(with: "Error",
                                           message: String.readableFormOf(error),
                                           constructiveButtonTitle: "Ok",
                                           destructiveButtonTitle: nil,
                                           constructiveActionHandler: {
                                            DispatchQueue.main.async {
                                                self.clearAllTextFields()
                                                self.textfield1.becomeFirstResponder()
                                            }
                    },
                                           destructiveActionHandler: nil,
                                           onController: self)
                }
            }
        })
    }
    
    
    //MARK: - Private Method
    
    func configureUI() {
        self.enableOrDisableNext()
        self.actualPhoneNumber?.attributedText = self.verifyPhoneNumberViewModel?.retrieveLabelText()
    }
    
    func addInputAccessoryViewToAllKeyboards() {
        
        for keyboard in textFieldList {
            let keyboardAccessoryView = AccessoryView.build()
            keyboardAccessoryView.doneCompletionHandler = {
                // done button pressed
                DispatchQueue.main.async {
                    keyboard.resignFirstResponder()
                }
            }
            keyboard.inputAccessoryView = keyboardAccessoryView
        }// end of for loop
    }
    
    func navigateToSuccess() {
        DispatchQueue.main.async {
            
            if let newCallForwardingNumber = self.verifyPhoneNumberViewModel?.newCallForwarding {
                if newCallForwardingNumber.count > 0 {
                    
                    AlertUtil.showAlert(with: "",
                                        message: "Your Call Forwarding Number has changed successfully.",
                                        constructiveButtonTitle: "Ok",
                                        destructiveButtonTitle: nil,
                                        constructiveActionHandler: {
                                            DispatchQueue.main.async {
                                                
                                                if let twilioNumber = Session.user?.twilioNumber , let callForwardNumber = self.verifyPhoneNumberViewModel?.newCallForwarding {
                                                    Session.updateUser(twilioNumber: twilioNumber, callFwdNumber: callForwardNumber)
                                                }
                                                self.navigationController?.popToRootViewController(animated: true)
                                            }
                                        },
                                        destructiveActionHandler: nil,
                                        onController: self)
                    
                    return
                }
            }
            
            self.performSegue(withIdentifier: "Success", sender: self)
        }
    }
    
    func clearAllTextFields() {
        for textField in self.textFieldList {
            textField.text = ""
        }
    }
    
    func enableOrDisableNext() {
        
        if  (self.textfield1.text?.count)! > 0 &&
            (self.textfield2.text?.count)! > 0 &&
            (self.textfield3.text?.count)! > 0 &&
            (self.textfield4.text?.count)! > 0 {
            self.nextButton.enabledState()
        } else {
            self.nextButton.disabledState()
        }
    }
    
    func consolidatedText() -> String {
        
        return self.textfield1.text! +
            self.textfield2.text! +
            self.textfield3.text! +
            self.textfield4.text!
    }
    
    //MARK: - UITextfield Delegates
    
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool {
        
        if string.isEmpty && textField.tag == 0 && (textField.text?.count)! <= 0 {
            
            self.enableOrDisableNext()
            
            // don't do anything because user is at first textfield and hitting delete
            return false
        } else if (string.count > 0 && textField.tag == 3 && (textField.text?.count)! > 0) {
            self.enableOrDisableNext()
            
            // don't do anything because user is at last textfield and trying to enter new characters
            return false
        } else {
            // move forward or backward
            if string.count > 0 {
                // move forward
                self.perform(#selector(moveNext),
                             with: textField,
                             afterDelay: 0.01)
                
            } else {
                
                // textfield is empty then move back else stay on that textfield
                self.perform(#selector(moveBack),
                             with: textField,
                             afterDelay: 0.01)
                
            }
        }
        
        textField.text = String(string.dropFirst())
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @objc func moveNext(textField: CustomTextfield) {
        
        self.enableOrDisableNext()
        
        if textField.tag == 3 { return }
        let nextTextField = self.textFieldList[textField.tag + 1]
        nextTextField.becomeFirstResponder()
    }
    
    @objc func moveBack(textField: CustomTextfield) {
        
        self.enableOrDisableNext()
        
        if textField.tag == 0 { return }
        
        let prevTextField = self.textFieldList[textField.tag - 1]
        prevTextField.becomeFirstResponder()
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier?.elementsEqual("Success"))! {
            let viewController = segue.destination as! RegistrationSuccessViewController
            viewController.registrationSuccessViewModel = RegistrationSuccessViewModel()
            viewController.registrationSuccessViewModel?.actualPhoneNumber = self.verifyPhoneNumberViewModel?.actualPhoneNumber
            viewController.registrationSuccessViewModel?.virtualPhoneNumber = self.verifyPhoneNumberViewModel?.virtualPhoneNumber
        }
    }
    
}
