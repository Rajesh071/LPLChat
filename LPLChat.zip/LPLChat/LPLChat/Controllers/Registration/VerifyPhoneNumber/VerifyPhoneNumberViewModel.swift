//
//  VerifyPhoneNumberViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class VerifyPhoneNumberViewModel: NSObject {

    var actualPhoneNumber: String?
    var virtualPhoneNumber: String?
    var newCallForwarding: String = ""
    
    func retrieveLabelText() -> NSAttributedString {
       
        var number: String = ""
        
        if newCallForwarding.count > 0 {
            number = newCallForwarding
        } else {
            if let actualNumber = actualPhoneNumber {
                if let formattedNumber = NumberUtil.format(phoneNumber: actualNumber) {
                    number = formattedNumber
                }
            }
        }
                
        let text = "sent to " + number
        let attributedText = NSMutableAttributedString(string: text)
        attributedText.setBoldFont(for: NumberUtil.format(phoneNumber: actualPhoneNumber!)!)
        
        return attributedText
    }
    
    func verifyCallForward(_ completionHandler: @escaping GenericCompletionHandler<Bool>) {
        // remove + if there is any
        let unformattedNumber = NumberUtil.removeFormattingAndPlus(self.actualPhoneNumber!)
        
        ServiceManager.verifyCallForward(unformattedNumber,
                                         completionHandler)
    }
    
    func verifyTokenAndPhone(token: String,
                             _ completionHandler: @escaping GenericCompletionHandler<Bool>) {
    
        let unformattedNumber = NumberUtil.removeFormattingAnd1OrPlus1(self.actualPhoneNumber!)

        ServiceManager.verifyTokenAndPhone(callForwardNumber: unformattedNumber,
                                           token: token,
                                           completionHandler)
    }
    
}
