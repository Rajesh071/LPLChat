//
//  DisclaimerViewController
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/11/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit


class DisclaimerViewController: BaseViewController {

    // IBOutlets
    @IBOutlet weak var webView: UIWebView!

    // IBOutlets
    @IBOutlet weak var acceptBtn: UIButton!

    var disclaimerVM: DisclaimerViewModel!
    
    var user: ModelUser?
    
    //MARK: - Factory Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.configureUI()
    }

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.showIndicator()
        
        disclaimerVM.retriveDisclaimerWith { (result) in
            self.removeIndicator()
            switch result {
            case let .success(value):
                self.populate(text: value?.ConfigValue ?? "Error loading")
            case let .failure(error):
                self.errorAlert(msg: error.localizedDescription)            
            }
        }
    }
    
    
    // MARK: - Public Methods
    
    class func buildViewController() -> DisclaimerViewController {
        let storyboard = UIStoryboard(name: "Registration", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :"DisclaimerViewController") as! DisclaimerViewController

        return viewController
    }
    
    
    // MARK: - Private Methods
    
    func configureUI() {
        // configure view model
        self.disclaimerVM = DisclaimerViewModel()
        self.acceptBtn.disabledState()
    }
    
    func populate(text: String) {
        
        DispatchQueue.main.async {
            self.webView.loadHTMLString(text.webViewCompatible(),
                                        baseURL: nil)
            self.acceptBtn.enabledState()
        }
    }
    
    
    // MARK: - Action Methods
    
    @IBAction func acceptDisclaimer() {
        
        self.showIndicator()
        
        self.disclaimerVM.saveDisclaimer { (result) in
            
            switch result {
            case .success(_):
                self.retrieveUser()
            case let .failure(error):
                print (error)
                self.retrieveUser()
            }
        }
    }
    
    func retrieveUser(){
        self.disclaimerVM.retrieveUser { (result) in
            self.removeIndicator()
            
            switch result {
            case let .success(user):
                self.navigationToStateAreaCodeView(user: user)
            case .failure(_):
                AlertUtil.showAlert(with: "Error", message: "Unable to retrieve user info", onController: self)
            }
        }
    }
    
    func navigationToStateAreaCodeView(user: ModelUser?) {
        DispatchQueue.main.async {
            
            let selectedStateAreaCodeViewModel = SelectedStateAreaCodeViewModel()
            selectedStateAreaCodeViewModel.user = user
            
            let selectedStateAreaCodeViewController = SelectedStateAreaCodeViewController.buildWithViewModel(viewModel: selectedStateAreaCodeViewModel)
                self.navigationController?.pushViewController(selectedStateAreaCodeViewController,
                                                          animated: true)
        }
    }

}
