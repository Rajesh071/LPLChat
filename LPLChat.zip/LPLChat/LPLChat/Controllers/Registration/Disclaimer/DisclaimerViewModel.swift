//
//  DisclaimerViewModel.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/11/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class DisclaimerViewModel: NSObject {

    func retriveDisclaimerWith(_ completionHandler: @escaping GenericCompletionHandler<Disclaimer>) {
        ServiceManager.retriveDisclaimerWith(completionHandler)
    }
    
    func retrieveUser(_ completionHandler: @escaping GenericCompletionHandler<ModelUser>) {
        ServiceManager.retriveUser(completionHandler)
    }
    
    func saveDisclaimer(_ completionHandler: @escaping GenericCompletionHandler<SaveDisclaimerResponse>) {
        ServiceManager.saveDisclaimer(true, completionHandler)
    }
}
