//
//  AppDelegate.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import UserNotifications
import Reachability

// Define identifier
let connectionAvailableNotification = Notification.Name("ConnectionAvailableNotification")


let log = LPLLogger.self

//class LPLNotificationMessage{
//    var msg: String!
//    var fromNo: String!
//
//    init(msg:String,fromNo:String) {
//        self.msg = msg
//        self.fromNo = fromNo
//    }
//}

//UIApplicationMain is commented out to allow idle timeout functionality see the main.swift file in the IdleTimeoutUtility group
//@UIApplicationMain
class AppDelegate: UITapGestureRecognizer, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    let notificationSessionTimeOutIdentifier = "sessionTimeOut"
    var window: UIWindow?
    var deviceTokenStr : String?
    var overlayImageView: UIImageView?
    var reachability = Reachability(hostName: "google.com")
    var toNumber: String? = nil
    // When application will enter to foreground need to display login as modal
    var loginVC: HybridLoginViewController?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        let defaults = UserDefaults.standard
        let appDefaults = [String:AnyObject]()
        defaults.register(defaults: appDefaults)
        #if AppStore
        if let _ = defaults.object(forKey: "environment") {} else {
            defaults.set("AppStore", forKey: "environment")
        }
        #elseif Dev
        if let _ = defaults.object(forKey: "environment") {} else {
            defaults.set("Dev", forKey: "environment")
        }
        #elseif QA
        if let _ = defaults.object(forKey: "environment") {} else {
            defaults.set("QA", forKey: "environment")
        }
        #endif
        
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        
        //set delegate to self
        UNUserNotificationCenter.current().delegate = self
        
        FeatureFlagUtil.configureDefaultValuesOfFeatureFlag()
        
        log.setup()
        self.setupUN()
        
        application.registerForRemoteNotifications()
        
        let attributes = [NSAttributedStringKey.font: UIFont(name: "Lato", size: 16)!]
        UINavigationBar.appearance().titleTextAttributes = attributes
        UINavigationBar.appearance().prefersLargeTitles = true
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedStringKey(rawValue: NSAttributedStringKey.foregroundColor.rawValue): UIColor.lPLBlue4]
        UINavigationBar.appearance().largeTitleTextAttributes = [NSAttributedStringKey(rawValue: NSAttributedStringKey.foregroundColor.rawValue): UIColor.lPLBlue4]
        // opening a specific controller
        if let option = launchOptions {
            let info = option[UIApplicationLaunchOptionsKey.remoteNotification]
            if (info != nil) {}}
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
        
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        if let unReadMessageCount = UserDefaults.init(suiteName: Constants.appGroup)?.integer(forKey: Constants.appBadgeCount) {
            UIApplication.shared.applicationIconBadgeNumber = unReadMessageCount
        }
        //Show Overlay only if the user is logged in
        if Session.getUser() != nil {
            self.addSecurityOverlay()
        }
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        self.removeSecurityOverlay()
        
        // present router
        Router.presentLoginViewController()
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        self.listenForNetworkChangeNotifications()
        self.removeSecurityOverlay()
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        if let unReadMessageCount = UserDefaults.init(suiteName: Constants.appGroup)?.integer(forKey: Constants.appBadgeCount) {
            UIApplication.shared.applicationIconBadgeNumber = unReadMessageCount
        }
    }
    
    //MARK: - APNS
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        deviceTokenStr = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        
        AppStateData.shared.saveDeviceToken(deviceToken: deviceTokenStr ?? "")
        print("Mobile App Device token = \(String(describing: deviceTokenStr))")
        log.verbose("Mobile App Device token \(String(describing: deviceTokenStr))")
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        log.verbose(userInfo)
        if let toNumber = extractMessage(fromPushNotificationUserInfo: userInfo as! [String : Any]) {
            navigateToChatDetailsFromPush(toNumber: toNumber, userInfo: userInfo)
        }
        NotificationCenter.default.post(name: .myNotificationKey, object: nil, userInfo: userInfo)
    }
    
    // Silent Notifications
//    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
//        let state = UIApplication.shared.applicationState
//
//        switch state {
//        default:
//            let nc = NotificationCenter.default
//            nc.post(name: Notification.Name.silentPushNotificationKey, object: nil, userInfo: userInfo)
//            completionHandler(UIBackgroundFetchResult.noData)
//        }
//    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (_ options:   UNNotificationPresentationOptions) -> Void) {
        
        //if top controller is message detail view controller AND the chat is from the current push notification sender, only play sound
        //Else, show notification
        if (self.window?.topViewController()?.isKind(of: ChatDetailsViewController.classForCoder()))! {
            
            let userInfo = notification.request.content.userInfo
            if let numberFromPush = extractMessage(fromPushNotificationUserInfo: userInfo as! [String : Any]) {
                print("NUMBERFROMPUSH: \(numberFromPush)")
                let chatDetailsVC = self.window?.topViewController() as! ChatDetailsViewController
                
                if chatDetailsVC.toNumber.removeWhiteListedCharacters() == numberFromPush {
                    completionHandler([.sound])
                } else {
                    completionHandler([.alert, .sound])
                }
            }
        } else {
            completionHandler([.alert, .sound])
        }
        
        NotificationCenter.default.post(name: .myNotificationKey, object: nil, userInfo: notification.request.content.userInfo)
    }

    private func extractMessage(fromPushNotificationUserInfo userInfo:[AnyHashable: Any]) -> String? {
        var title: String?
        if let aps = userInfo["aps"] as? NSDictionary {
            if let alert = aps["alert"] as? NSDictionary {
                if let alertTitle = alert["title"] as? String {
                     let formattedTitle = ContactUtility.removeSpecialCharactersFromNumber(alertTitle)
                    title = formattedTitle
                }
            }
        }
        return title
    }
    
    func setupUN(){
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
            (granted, error) in
            if !granted {
                log.info("User is not allowing notifications")
            }
        }
        UIApplication.shared.registerForRemoteNotifications()
    }

    // MARK: - Navigation
    // TODO: Can this be moved out of AppDelegate
    private func navigateToChatDetailsFromPush(toNumber: String, userInfo: Dictionary<AnyHashable, Any>?) {
        //notificationTapped = true
        
        let topViewController = self.window?.topViewController()
        let controller = UIViewController.build(with: "Main", and: "ChatDetailsViewController") as? ChatDetailsViewController
        guard let viewController = controller else {
            return
        }
        viewController.toNumber = NumberUtil.removeSpecialCharatersFrom(text: toNumber).removeWhitespaces()
        
        let contact = Contact.createContact(from: userInfo)
        viewController.contactInfo = contact
        
        let navController = topViewController?.navigationController
        
        switch UIApplication.shared.applicationState {
        case .active:
            print("activeState")
            DispatchQueue.main.async {
                
                if (topViewController?.isKind(of: ChatDetailsViewController.classForCoder()))! {
                    navController?.popViewController(animated: true)
                    navController?.pushViewController(viewController, animated: true)
                } else if (topViewController?.isKind(of: HybridLoginViewController.classForCoder()))! {
                    self.toNumber = toNumber
                } else {
                    topViewController?.navigationController?.pushViewController(viewController,
                                                                                animated: true)
                }
            }
            break
        case .inactive:
            
            if (topViewController?.isKind(of: ChatDetailsViewController.classForCoder()))! {
                navController?.popViewController(animated: true)
                navController?.pushViewController(viewController, animated: true)
            } else if (topViewController?.isKind(of: HybridLoginViewController.classForCoder()))! {
                self.toNumber = toNumber
            } else {
                topViewController?.navigationController?.pushViewController(viewController,
                                                                            animated: true)
            }
            break
            
        case .background:
            /*Not sure if we actually need this logic here.
             separating .inactive and .active state resolved many navigation from push issues. keeping here for now as a redundancy - PE */
            
            if (topViewController?.isKind(of: ChatDetailsViewController.classForCoder()))! {
                //navController?.navigationBar.isHidden = true
                navController?.popViewController(animated: true)

                
                navController?.pushViewController(viewController, animated: true)
                
            } else if (topViewController?.isKind(of: HybridLoginViewController.classForCoder()))! {
                self.toNumber = NumberUtil.removeSpecialCharatersFrom(text: toNumber).removeWhitespaces()
            } else {
                topViewController?.navigationController?.pushViewController(viewController,
                                                                            animated: true)
            }
            break
        }
    }
    
    func pushChatDetailViewControllerIfNotThere(smsData: SMSData) {
        if !(self.window?.topViewController()?.isKind(of: ChatDetailsViewController.classForCoder()))! {
            
            DispatchQueue.main.async {
                let controller = UIViewController.build(with: "Main", and: "ChatDetailsViewController") as? ChatDetailsViewController
                guard let viewController = controller else {
                    return
                }
                
                let topViewController = self.window?.topViewController()
                topViewController?.navigationController?.pushViewController(viewController,
                                                                            animated: true)
            }
        }
    }
    
    //MARK: - Overlay Views
    func addSecurityOverlay() {
        if self.overlayImageView == nil {
            DispatchQueue.main.async {
                self.overlayImageView = UIImageView(image: UIImage(named: "SplashScreen"))
                self.overlayImageView?.frame = UIScreen.main.bounds
                self.window?.addSubview(self.overlayImageView!)
            }
        }
    }
    
    func removeSecurityOverlay(){
        DispatchQueue.main.async {
            if ((self.overlayImageView) != nil) {
                self.overlayImageView?.removeFromSuperview()
            }
        }
    }

    //MARK:- Reachability
    func listenForNetworkChangeNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(note:)), name: .reachabilityChanged, object: reachability)
        reachability?.startNotifier()
    }
    
    @objc func reachabilityChanged(note: Notification) {
        let reachability = note.object as! Reachability
        if !reachability.isReachable() {
            self.displayNetworkNotConnectedAlert()
        }
//        print("reachable via: \(reachability.currentReachabilityString())")
    }
    
    // TODO: this looks like a prime candidate to take out of the app delegate
    func displayNetworkNotConnectedAlert() {
        
        // remove alert if any before displaying other
        let window = UIApplication.shared.keyWindow
        let alertView = window?.viewWithTag(1001)

        if (alertView != nil) {
            return
        }
        
        reachability = Reachability(hostName: "google.com")
        if let isReachable = reachability?.isReachable() {
            
            if isReachable {
                // Post notification
                NotificationCenter.default.post(name: connectionAvailableNotification, object: nil)

            } else {
                
                AlertUtil.showAlert(with: "Sorry",
                                       message: "You are not connected to internet",
                                       constructiveButtonTitle: "Retry",
                                       destructiveButtonTitle: nil,
                                       constructiveActionHandler: {
                                        DispatchQueue.main.async {
                                            self.displayNetworkNotConnectedAlert()
                                        }
                },
                                       destructiveActionHandler: nil,
                                       onController: self.window?.topViewController())
            }
        }
    }
    
}

extension UIApplication {
    
    var statusBarView: UIView? {
        return value(forKey: "statusBar") as? UIView
    }
}

extension UINavigationController {
    
    override open func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .lPLLightGray
    }
    
}


