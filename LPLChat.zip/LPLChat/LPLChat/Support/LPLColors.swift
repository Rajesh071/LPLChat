//
//  LPLColors.swift
//  LPLMessaging
//
//  Created by Kent Franks on 8/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

extension UIColor {
    
    static let lPLBlue1         = #colorLiteral(red: 0.008179619908, green: 0.4708960056, blue: 0.7495005727, alpha: 1) // UIColor(red: 51, green: 118, blue: 186, alpha: 1)
    static let lPLBlue2         = #colorLiteral(red: 0.004385677632, green: 0.3576426506, blue: 0.5686432123, alpha: 1) // UIColor(red: 38, green: 90, blue: 141, alpha: 1)
    static let lPLBlue3         = #colorLiteral(red: 0.001494432217, green: 0.214111656, blue: 0.3457856178, alpha: 1) // UIColor(red: 20, green: 53, blue: 86, alpha: 1)
    static let lPLBlue4         = #colorLiteral(red: 0.0005508871982, green: 0.133310616, blue: 0.2145403624, alpha: 1) // UIColor(red: 9, green: 34, blue: 53, alpha: 1)
    static let lPLLightGray     = #colorLiteral(red: 0.9601849914, green: 0.9601849914, blue: 0.9601849914, alpha: 1) // UIColor(red: 235, green: 235, blue: 235, alpha: 1)
    static let lPLMediumGray    = #colorLiteral(red: 0.7952535152, green: 0.7952535152, blue: 0.7952535152, alpha: 1) // UIColor(red: 203, green: 203, blue: 203, alpha: 1)
    static let lPLDarkGray      = #colorLiteral(red: 0.5723067522, green: 0.5723067522, blue: 0.5723067522, alpha: 1) // UIColor(red: 146, green: 146, blue: 146, alpha: 1)
    static let lplLightSky      = #colorLiteral(red: 0.9607843137, green: 0.9725490196, blue: 0.9803921569, alpha: 1) // UIColor(red: 9, green: 34, blue: 53, alpha: 1)

}
