//
//  LPLLogger.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/26/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import SwiftyBeaver
import Alamofire

enum ctx :String{
    case Paging = "Paging"
}
class LPLLogger{

    static let sblog = SwiftyBeaver.self
    
    class func setup(){
        let console = ConsoleDestination()  // log to Xcode Console
        let appname = "lpllog"
        console.useNSLog = true
        //console.format = "$DHH:mm:ss.SSS$d \(appname) $C$L$c $N.$F:$l $X - $M"  // loglevel: message
        console.format = "\(appname) $C$L$c $N.$F:$l $X - $M"  // loglevel: message
        console.asynchronously = false
        sblog.addDestination(console)
    }
    
    class func verboseResponse(_  dr: DataResponse<Any> ,
                               file: String = #file, _ function: String = #function, line: Int = #line, context: Any? = nil) {

        sblog.verbose("ResponseLog \(String(describing: dr.request?.httpMethod)) " +
                "\(String(describing: dr.request?.url?.absoluteString))" +
                "\(String(describing: dr.request?.httpBody)) ",
                file, function, line: line,context: context)

        sblog.verbose("ResponseLog \(String(describing: dr.request?.allHTTPHeaderFields))", file, function, line: line,context: context)

        if let reqHeaders = dr.request?.allHTTPHeaderFields{
            for header in reqHeaders{
                sblog.verbose("ResponseLog Reqheaders \(header.key) \(header.value)", file, function, line: line,context: context)
            }
        }

        sblog.verbose("ResponseLog \(String(describing: dr.response?.allHeaderFields))", file, function, line: line,context: context)
        sblog.verbose("ResponseLog \(String(describing: dr.response?.statusCode))", file, function, line: line,context: context)
        sblog.verbose("ResponseLog \(String(describing: dr.result.value))", file, function, line: line,context: context)
    }
    
    class func verbose(_ message: @autoclosure () -> Any,
                       file: String = #file, _ function: String = #function, line: Int = #line, context: Any? = nil) {
        sblog.verbose(message, file, function, line: line,context: context)
        //print("->>>>>", message)
    }
    
    class func debug(_ message: @autoclosure () -> Any,
                     file: String = #file, _ function: String = #function, line: Int = #line, context: Any? = nil) {
        sblog.debug(message, file, function, line: line,context: context)
        //print("->>>>>", message)
    }
    
    class func info(_ message: @autoclosure () -> Any,
                    file: String = #file, _ function: String = #function, line: Int = #line, context: Any? = nil) {
        sblog.info(message, file, function, line: line,context: context)
        //print("->>>>>", message)
        
    }
    
    class func warning(_ message: @autoclosure() -> Any,
        file: String = #file, _ function: String = #function, line: Int = #line, context: Any? = nil) {
        sblog.warning(message, file, function, line: line,context: context)
        //print("->>>>>", message)
        
    }
    
    class func error(_ message: @autoclosure () -> Any,
                     file: String = #file, _ function: String = #function, line: Int = #line, context: Any? = nil) {
        sblog.error(message, file, function, line: line,context: context)
       // print("->>>>>", message)
    }
}
