//
//  Environment.swift
//  LPLMessaging
//
//  Created by Kent Franks on 8/2/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum Environment: String {
    
    case Dev = "devInt"
    case QA = "qa"
    case AppStore = "AppStore"

    var env: String {
        switch self {
        case .Dev: return "DevInt"
        case .QA: return "QA"
        case .AppStore: return "Prod"
        }
    }

    var urlLogin: String {
        switch self {
        case .Dev: return "https://logindevint.lpl.com"
        case .QA: return "https://loginqa.lpl.com"
        case .AppStore: return "https://login.lpl.com"
        }
    }
    
    var baseWebApiUrl: String {
        switch self {
        case .Dev: return "https://webapidvi.dev.lpl.com/lplmessagingwebapi/"
        case .QA: return "https://webapiqa.qa.lpl.com/lplmessagingwebapi/"
        case .AppStore: return "https://webapi.lpl.com/lplmessagingwebapi/"
        }
    }
    
    var baseLPLServicesUrl: String {
        switch self {
        case .Dev: return "https://clientworksdevint.lpl.com/ieCors/"
        case .QA: return "https://clientworksqa.lpl.com/ieCors/"
        case .AppStore: return "https://clientworks.lpl.com/ieCors/"
        }
    }
    
    var urlSuccess: String {
        switch self {
        case .Dev: return "https://clientworksdevint.lpl.com/clientmanagement/"
        case .QA: return "https://clientworksqa.lpl.com/clientmanagement/"
        case .AppStore: return "https://clientworks.lpl.com/clientmanagement/"
        }
    }
    
    var baseSharedServicesUrl: String {
        switch self {
        case .Dev: return "https://apidvi.dev.lpl.com/"
        case .QA: return "https://apiqa.qa.lpl.com/"
        case .AppStore: return "https://api.lpl.com/"
        }
    }

    var clientId: String {
        switch self {
        case .Dev: return "491e2a25eeb541daa6b2dbb7a4b6ce3d"
        case .QA: return "2ac772ef99964d7f9623947af4f35fa8"
        case .AppStore: return "8b9b6bf850c343dbab85b080ffcb5cf3"
        }
    }

    var clientSecret: String {
        switch self {
        case .Dev: return "4DD655BBae7641ff8921484654f91a2F"
        case .QA: return "https://clientworksqa.lpl.com/clientmanagement/"
        case .AppStore: return "https://clientworks.lpl.com/clientmanagement/"
        }
    }

    var headerOrigin: String {
        switch self {
        case .Dev: return "https://clientworksdevint.lpl.com"
        case .QA: return "https://clientworksqa.lpl.com"
        case .AppStore: return "https://clientworks.lpl.com"
        }
    }

    var getContacts: String {
        return self.baseWebApiUrl  + "user/information/contact"
    }

}
