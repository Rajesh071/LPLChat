//
//  Constants.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/9/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class Constants {
    
    //Keys
    static let appBadgeCount                    = "LPLMessage-badgeCount"
    static let appGroup                         = "group.com.lplMessageContainer"
    
    //Cell Identifiers
    static let advisorContactCell               = "AdvisorContactCell"
    static let cWContactsCell                   = "CWContactsCell"
    static let localContactCell                 = "LocalContactCell"
    static let contactNumberTableViewCell       = "ContactNumberTableViewCell"
    static let addressInfoTableViewCell         = "AddressInfoTableViewCell"
    static let contactDateTableViewCell         = "ContactDateTableViewCell"

}
