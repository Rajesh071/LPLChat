//
//  EnvOverrides.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/9/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class EnvOverrides{
    
    //Developer mode: set true wherever applicable
    //Prod set to false
    
    // MARK: APP
    static let debugDoDisablePush = false // only 1 device APN will work at a time.
    
    // MARK: Registration
    
    static let forceRegistrationAlways = FeatureFlagUtil.getValueOf(key: FeatureFlag.forceUserRegistation.rawValue)
    
    // true to always skip registration screen.
    static let debugSkipRegistrationAlways = FeatureFlagUtil.getValueOf(key: FeatureFlag.skipUserRegistation.rawValue)
    
    static let debugSkipVerificationStep = false // you can put dummy number in callforward text field- no call from the twilio
    
    static let debugDoOverrideAutoPopulateUserInLoginWeb = false
    
    static let debugDoOverrideAutoPopulateUserInLoginWebForTouchId = false
    static let debugOverrideAutoPopulateUserInLoginWeb = "vigilius.booke"
    //static let debugOverrideAutoPopulateUserInLoginWeb = "vigilius.booke"
    static let debugOverrideAutoPopulateUserInLoginWebPwd = "P@ssw0rd"
    
    static let debugUseDummyData = false
    static let debugUseLocalDataForCities = true //true for 3/17 demo
    static let debugUseDummyDataForTwilioNumbersRetrieve = false
    
    //ASAT
    
    static let debugDoOverrideASATAccess = false
    static let debugOverrideASATAccess = false
    
}
