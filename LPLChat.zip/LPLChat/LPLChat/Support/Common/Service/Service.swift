//
//  Service.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/9/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class Service {

    class func call<T: Codable>(url: URL, type: T.Type,
                                completionHandler: @escaping (_ resp: Result<T?>) -> ())
                    -> URLSessionTask {

        let task = URLSession.shared.dataTask(with: url) { (data, urlResponse, error) in

            guard let httpUrlResponse = urlResponse as? HTTPURLResponse else {
                return completionHandler(Result<T?>(error: "error"))
            }

            //status code 401
            let statusCode = httpUrlResponse.statusCode
            guard statusCode != 401 else {
                //TODO global error handling - load login screen ???
                completionHandler(Result<T?>(error: "error"))
                return
            }

            //any status code other than 200 is considered failure
            guard  statusCode == 200 else {
                completionHandler(Result<T?>(error: "Unknown error. Please try again"))
                return
            }

            // handle error
            if let error = error {
                completionHandler(Result<T?>(error: error.localizedDescription))
            }

            //handle result
            completionHandler(convertDataToResult(data: data))

        }

        task.resume()

        // return task - so caller can cancel it if needed ( for type ahead  search scenarios )
        return task
    }

    //TODO: resuse this method and write a call with empty result
//    class func call<T: Codable>(url: URL, type: T.Type,
//                                completionHandler: @escaping (_ resp: Result<T?>) -> ())
//                    -> URLSessionTask {


    class func convertDataToResult<T: Codable>(data: Data?) -> Result<T?> {

        do {
            //Error: empty response
            guard let data = data else {
                return Result<T?>(error: "Please try again")
            }

            let serviceResponse = try JSONDecoder().decode(ServiceResponseCodable<T>.self, from: data)

            //any status other than "success" is considered failure
            guard serviceResponse.status == "success" else {
                return Result<T?>(error: serviceResponse.statusMessage ?? "error")
            }

            let successResult = Result<T?>(value: serviceResponse.data ?? nil)
            return successResult //only success scenario

        } catch let error {
            let result = Result<T?>(error: error.localizedDescription)
            return result
        }
    }

    class func log(data: Data?, urlResponse: URLResponse?, error: Error?) {
        //TODO : log
        //log verbose  : log url , request header, response headers, error, statuscode, response
        //log info mode log url , error, statuscode
        //log error with error
    }
}
