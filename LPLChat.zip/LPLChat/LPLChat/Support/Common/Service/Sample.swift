//
//  Sample.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class MessageC : Codable{
    
}

class SampleSvc {
    func sample() {
        
        let urlString = ""
        
        let serviceUrl = URL.init(string: urlString)
        
        var request = URLRequest.init(url: serviceUrl!)
        
        request.httpMethod = "GET" //HTTPMethodType.get.rawValue
        
        request.setValue("Application/json",
                         forHTTPHeaderField: "Content-Type")
        
        request.allHTTPHeaderFields = RequestHelper.getHeaders()
        
        let _ =  Service.call(url: serviceUrl!, type: MessageC.self) { result in
            
            switch result {
            case let .success(msg):
                print("succes \(String(describing: msg))")
            case let .failure(error):
                print (error)
            }
        }
    }
}
