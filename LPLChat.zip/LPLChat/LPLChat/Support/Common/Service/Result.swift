//
//  Result.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum Result<Value> :CustomStringConvertible, CustomDebugStringConvertible {
    case success(Value)
    case failure(String) // todo: TBD use Error instead of string ???
    
    /**
      Constructs a success wrapping a `value`.
     */
    public init(value: Value) {
        self = .success(value)
    }

    /**
      Constructs a failure wrapping an error in string.
     */
    public init(error: String) {
        self = .failure(error)
    }

    // MARK: CustomStringConvertible
    public var description: String {
        switch self {
        case let .success(value): return ".success(\(value))"
        case let .failure(error): return ".failure(\(error))"
        }
    }

    // MARK: CustomDebugStringConvertible
    public var debugDescription: String {
        return description
    }
}
