//
//  ServiceResponseCodable.swift
//  LPLMessages
//
//  Created by Avinash Rajendran on 4/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum ServiceResponseError: Error {
    case MissingStatusMsgForFail
}

/**
Class to represent Service Response

- Important:
Conforms to Codable
Data should conform to Codable

Sample JSON Response:
 {
     "status": "success",
     "statusMessage": "Request was successful",
    "data": {
       "asatCheck": false
      }
 }
*/

class ServiceResponseCodable<T : Codable> : Codable, CustomDebugStringConvertible {

    var status: String?
    var statusMessage: String?
    var data: T?

    init(status: String, statusMessage: String, data: T) {
        self.status = status
        self.statusMessage = statusMessage
        self.data = data
    }

    var debugDescription: String {
        return String("Status: \(String(describing: status)). Message: \(String(describing: statusMessage)) Data: \(String(describing: data))")
    }

    enum ServiceResponseCodableKeys: String, CodingKey { // declaring our keys
        case status
        case statusMessage
        case data
    }

    convenience required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: ServiceResponseCodableKeys.self)
        let status: String = try container.decode(String.self, forKey: .status)

        let statusMessage: String = try container.decode(String.self, forKey: .statusMessage)

        if status != "success" && statusMessage == "" {
            throw ServiceResponseError.MissingStatusMsgForFail
        }

        let data: T = try container.decode(T.self, forKey: .data)
        self.init(status: status, statusMessage: statusMessage, data: data)
    }
}
