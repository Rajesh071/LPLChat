//
//  Groups.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/2/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

struct GroupConstant {
    static let groupKey = "group.com.lplMessageContainer"
    static let contacts = "All_Contacts"
}

class Groups: NSObject {

    // MARK: - Shared Instance
    private let userDefaults = UserDefaults(suiteName: GroupConstant.groupKey)
    
    static let shared: Groups = {
        let instance = Groups()

        // setup code
        return instance
    }()
    
    // MARK: - Initialization Method
    
    override init() {
        super.init()
    }
    
    
    // save contacts which needs to be shared among app extension
    
    func saveContactsToGroup(contactDict: [String : String]) {
        // save contacts which needs to be shared with extension
        self.userDefaults?.set(contactDict,
                       forKey: GroupConstant.contacts)
        self.userDefaults?.synchronize()
    }
    
}
