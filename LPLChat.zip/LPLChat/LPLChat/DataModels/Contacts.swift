//
//  Contacts.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

public class Contacts {
    
    public var imageName: String!
    public var nameValue: String!
    public var amountValue: NSNumber!
    public var variationValue: NSNumber!
    public var unreadCount: Int!
    public var isNew: Bool!
    public var isFav: Bool!
    public var badgeValue: Int!
    public var phoneNumber: String!
    public var mobilePhone: String?
    public var businessPhone: String?
    public var clientID: String?

    public var firstName: String!
    public var lastName: String!
    var notes: String? = ""
    
    public var profile : Profile?
    
    public var asOfDate:Date?
    
    init(imageName: String, nameValue: String, amountValue: NSNumber, variationValue: NSNumber,
         unreadCount: Int, isNew: Bool, isFav: Bool, badgeValue: Int, phoneNumber: String, asOfDateStr:String, mobilePhone: String, businessPhone: String, firstName: String, lastName: String, clientID: String? = nil) {
        
        self.imageName = imageName
        self.nameValue = nameValue
        self.amountValue = amountValue
        self.variationValue = variationValue
        self.unreadCount = unreadCount
        self.isNew = isNew
        self.isFav = isFav
        self.badgeValue = badgeValue
        self.phoneNumber = phoneNumber
        self.asOfDate = asOfDateStr.convertToDate()
        self.clientID = clientID
    }
    
}
