//
//  Address.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

public class Address {
    
    public var label:String! //home,work,etc
    public var line1:String = ""
    public var line2:String = ""
    public var line3:String = ""
    public var city:String = ""
    public var state:String = ""
    public var zipCode:String = ""
    
    
    init(label:String,
         line1:String,
         line2:String,
         line3:String,
         city:String,
         state:String,
         zipCode:String) {
        
        self.label = label
        self.line1 = line1.replacingOccurrences(of: "\n",
                                                with: " ")
     
        self.line3 = line3
        self.city = city
        self.state = state
        self.zipCode = zipCode
    }
    
    class func mockData() -> Address {
        let address = Address.init(label: "address",
                                   line1: "14545 North Frank Lloyd",
                                   line2: "# 1050",
                                   line3: "",
                                   city: "Scottsdale",
                                   state: "AZ",
                                   zipCode: "85260")
        
        return address
    }
}
