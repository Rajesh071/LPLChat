//
//  PhoneNumber.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class PhoneNumber {
    
    public var displayValue:String!
    public var value:String!
    public var label:String!
    public var isFav:Bool!
    
    init(displayValue:String,
         label:String,
         isFav:Bool) {
        
        self.displayValue = displayValue
        self.value = displayValue.components(separatedBy: CharacterSet.decimalDigits.inverted).joined(separator: "")
        self.label = label
        self.isFav = isFav
    }
}
