import Foundation

struct ProspectResponse: Decodable {
    let status: String?
    let statusMessage: String?
    let data: [Prospect]
}

struct Prospect: Decodable {
    let clientID: String?
    let firstName: String?
    let lastName: String?
    let homePhone: String?
    let businessPhone: String?
    let mobilePhone: String?
    let email: String?
    let mailingAddressLine1: String?
    let mailingAddressLine2: String?
    let mailingAddressLine3: String?
    let mailingCity: String?
    let mailingState: String?
    let mailingZipCode: String?
    let isProspect: String?
    let marketValue: String?
    let unrealizedGainLoss: String?
    let asofDate: String?
}
