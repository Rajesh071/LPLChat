//
//  ContactDate.swift
//  LPLMessages
//
//  Created by Kent Franks on 7/5/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct ContactDate {
    public var dateType: String?
    public var dateValue: String?
    
    init(dateType:String, dateValue:String) {
        self.dateType = dateType
        self.dateValue = dateValue
    }
}
