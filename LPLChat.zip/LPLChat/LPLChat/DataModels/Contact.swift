//
//  Contact.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 8/3/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

enum ContactTypeEnum {
    case clientWorks
    case phoneBook
    case unknown
}

struct Contact {
    let name: String?
    let number: String?
    var contactType: ContactTypeEnum = .unknown
    var clientID: String?
    
    var initials: String? {
        get {
            if let validName = name {
                return ContactUtility.retrieveInitials(from: validName)
            }
            return ""
        }
    }
    
    init(contactName: String?, contactNumber: String?, contactType: ContactTypeEnum = .unknown, clientID: String?) {
        self.name = contactName
        self.number = contactNumber
        self.contactType = contactType
        self.clientID = clientID
    }
    
    static func createContact(from userInfo: Dictionary<AnyHashable, Any>?) -> Contact? {
       
        guard let infoDict = userInfo else {
            return nil
        }
        let name: String? = APNSUtil.name(from: infoDict)
        let number: String? = APNSUtil.number(from: infoDict)
        
        let isClientWorks:ContactTypeEnum = name != nil ? .clientWorks : .unknown
        
        return Contact(contactName: name, contactNumber: number, contactType: isClientWorks, clientID: nil)
    }
    
}
