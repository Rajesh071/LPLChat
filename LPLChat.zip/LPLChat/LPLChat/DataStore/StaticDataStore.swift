//
//  StaticDataStore.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class StaticDataStore: NSObject {

    public static func getContact(pageNo:Int,pageSize:Int, i:Int, s:String) -> Contacts {
        
        let date = Date()
        let dateStr:String = date.toISO8601String()
        _ = (pageSize*pageNo) + i
        
        let keys:[Int:String] = [1:"A",2:"B",3:"C",4:"D",5:"E",6:"F",7:"G",8:"H",9:"I",10:"J"]
        
        var letter = "z"
        if pageNo <= 10{
            letter = keys[pageNo]!
        }
        
        
        let c =
            Contacts(imageName: "customer1",
                     nameValue: "\(letter) \(i) \(s)",
                     amountValue: 411123,
                     variationValue: 3232,
                     unreadCount: 0,
                     isNew: false,
                     isFav: true,
                     badgeValue: 1,
                     phoneNumber: "980980989",
                     asOfDateStr: dateStr,
                     mobilePhone: "2342342342",
                     businessPhone: "2342342342",
                     firstName: "\(letter)",
                     lastName: "\(i)")
        
        return c
    }
    
    public static func getAllContacts() -> [Contacts] {
        let date = Date()
        let dateStr:String = date.toISO8601String()
        let allContacts = [
            Contacts(imageName: "customer1",
                     nameValue: "Richard Bacon",
                     amountValue: 411123,
                     variationValue: 3232,
                     unreadCount: 0,
                     isNew: false,
                     isFav: true,
                     badgeValue: 1,
                     phoneNumber: "980980989",
                     asOfDateStr: dateStr,
                     mobilePhone: "2342342342",
                     businessPhone: "2342342342",
                     firstName: "Richard",
                     lastName: "Bacon"),
            Contacts(imageName: "customer2",
                     nameValue: "Jenny Babbit",
                     amountValue: 392812,
                     variationValue: -12112,
                     unreadCount: 2,
                     isNew: false,
                     isFav: true,
                     badgeValue: 0,
                     phoneNumber: "123344555",
                     asOfDateStr: dateStr,
                     mobilePhone: "2342342342",
                     businessPhone: "2342342342",
                     firstName: "Jenny",
                     lastName: "Babbit"),
            Contacts(imageName: "customer3",
                     nameValue: "Sarah Mustard",
                     amountValue: 304124,
                     variationValue: 13332,
                     unreadCount: 1,
                     isNew: false,
                     isFav: true,
                     badgeValue: 0,
                     phoneNumber: "231124325",
                     asOfDateStr: dateStr,
                     mobilePhone: "2342342444",
                     businessPhone: "2342342342",
                     firstName: "Sarah",
                     lastName: "Mustard"),
            Contacts(imageName: "",
                     nameValue: "Grey Petterson",
                     amountValue: 234111,
                     variationValue: 41117,
                     unreadCount: 0,
                     isNew: false,
                     isFav: false,
                     badgeValue: 0,
                     phoneNumber: "0000000000",
                     asOfDateStr: dateStr,
                     mobilePhone: "2342342111",
                     businessPhone: "2342342342",
                     firstName: "Grey",
                     lastName: "Petterson"),
            Contacts(imageName: "customer5",
                     nameValue: "Mary Petterson",
                     amountValue: 129450,
                     variationValue: 4237,
                     unreadCount: 0,
                     isNew: false,
                     isFav: false,
                     badgeValue: 0,
                     phoneNumber: "1231242342",
                     asOfDateStr: dateStr,
                     mobilePhone: "2342342888",
                     businessPhone: "2342342342",
                     firstName: "Mary",
                     lastName: "Petterson")]
        
        return allContacts
    }
    
    
    public static func getCurrentUser() -> User {
        
        if ((Session.user?.fullname) != nil) {
            return User(name: (Session.user?.fullname)!,
                        number: (Session.getUser()?.twilioNumber!)!,
                 id: "123456",
                 profilePic: "N.A." )
        } else {
            return User(name: "Andrew Brady",
                    number: "+1(704)-810-2223",
                    id: "123456",
                    profilePic: "N.A.")
        }
    }
}


public class SMSData {
    public var imageName: String!
    public var nameValue: String!
    public var description: String!
    public var time: String!
    public var badgeValue: Int!
    
    public var fromNumber: String!
    public var toNumber: String!
    public var totalUnread = 0

    //Temp for demo
    var owner: MessageOwner
    var numberValue: String!
    var timeDate: Date!
    
    init(imageName: String, nameValue: String, description: String, time: String, badgeValue: Int,
         owner : MessageOwner, numberValue: String, timeDate: Date, fromNumber:String, toNumber:String, totalUnread: Int) {
        
        self.imageName = imageName
        self.nameValue = nameValue
        self.description = description
        self.time = time
        self.badgeValue = badgeValue
        
        //Temp for Demo
        self.owner = owner
        self.numberValue = numberValue
        self.timeDate = timeDate
        
        self.fromNumber = fromNumber
        self.toNumber = toNumber
        self.totalUnread = totalUnread
    }
}
