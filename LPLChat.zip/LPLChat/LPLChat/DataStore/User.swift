//
//  User.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import UIKit

class User: NSObject {
    
    let name: String?
    let number: String?
    let id: String?
    var profilePic: String?
    
    init(name: String, number: String, id: String, profilePic: String) {
        self.name = name
        self.number = number
        self.id = id
        self.profilePic = profilePic
    }
}

