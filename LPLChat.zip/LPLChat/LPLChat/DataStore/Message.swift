//
//  Message.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import UIKit


enum MessageType {
    case photo
    case text
    case location
}

enum MessageOwner {
    case sender
    case receiver
}

enum MessageStatus {
    case sent
    case delivered
    case failed
}

//equivalent model to DateMessageItem(SVC response)
class DateMessage {
    
    var date: String?
    var messages: [Message]?
    
    init(date:String?, messages:[Message]?) {
        self.date = date
        self.messages = messages
    }
}

//used in binding to UI. Equivalent model to MessageItem
class Message {
    
    var owner: MessageOwner
    var type: MessageType
    var content: Any
    var timestamp: String
    var timeDate:Date
    var isRead: Bool
    var image: String?
    var toID: String?
    var fromID: String?
    var messageId :String?
    var isLocal :Bool = false //from server or local. Local during composing.
    var msgStatus : String?
    
    init(type: MessageType, content: Any, owner: MessageOwner, timeStampStr: String, isRead: Bool, image: String, messageId:String) {

        self.type = type
        self.content = content
        self.owner = owner
        self.timeDate =  timeStampStr.convertToDate()
        self.timestamp = self.timeDate.ConvertDateToReadableString()
        self.isRead = isRead
        self.image = image
        self.messageId = messageId
        //self.msgStatus
    }
    
    init(type: MessageType, content: Any, owner: MessageOwner, timeAsDate: Date, isRead: Bool, image: String) {
        
        self.type = type
        self.content = content
        self.owner = owner
        self.timeDate =  timeAsDate
        self.timestamp = self.timeDate.ConvertDateToReadableString()
        self.isRead = isRead
        self.image = image
    }
}

