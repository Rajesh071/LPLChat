//
//  AppStateData.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

enum AppStateFlags: String {
    case deviceToken = "DeviceToken"
    case cookies = "cookies"
    case xsrfToken = "XSRF-TOKEN"
    case connectionType = "ConnectionType"
    case logoutState = "LogoutState"
}


struct Credentials {
    var userName: String
    var password: String
    
    init(userName: String,
         password: String) {
        self.userName = userName
        self.password = password
    }
}

class AppStateData: NSObject {

    // MARK: - Shared Instance
    
    static let shared: AppStateData = {
        let instance = AppStateData()
        // setup code
        return instance
    }()
    
    // MARK: - Initialization Method
    
    override init() {
        super.init()
    }
    
    var credentials: Credentials?
    
    // store twilio number after registration
    var virtualNumber: String?
    
    // store call forwarding number after sucessful registration
    var actualNumber: String? = "+14086617865"
    
    
    // MARK: -  Credentials
    
    func getCredentials() -> Credentials {

        return Credentials.init(userName: UserDefaultUtil.getStringValueOf(key: CredentialsEnum.userName.rawValue),
                                password: UserDefaultUtil.getStringValueOf(key: CredentialsEnum.password.rawValue))
    }
    
    func setCredentials(credentials: Credentials?) {
        UserDefaultUtil.configureString(stringValue: credentials?.userName ?? "",
                                        keyValue: CredentialsEnum.userName.rawValue)
        UserDefaultUtil.configureString(stringValue: credentials?.password ?? "",
                                        keyValue: CredentialsEnum.password.rawValue)
    }
    
    // MARK:- Token
    
    func saveDeviceToken(deviceToken: String) {
        UserDefaultUtil.configureString(stringValue: deviceToken,
                                        keyValue: AppStateFlags.deviceToken.rawValue)
    }
    
    func getDeviceToken() -> String {
        return UserDefaultUtil.getStringValueOf(key: AppStateFlags.deviceToken.rawValue)
    }
    
    // MARK:- ZCookies
    
    func saveCookie(cookie: String) {
        
        UserDefaultUtil.configureString(stringValue: cookie,
                                        keyValue: AppStateFlags.cookies.rawValue)
        
    }
    
    func getCookie() -> String {
        
        return UserDefaultUtil.getStringValueOf(key: AppStateFlags.cookies.rawValue)
        
    }

    // MARK:-  xsrf cookies
    
    func saveXSRFCookie(cookie: String) {
        
        UserDefaultUtil.configureString(stringValue: cookie,
                                        keyValue: AppStateFlags.xsrfToken.rawValue)
    }
    
    func getXSRFCookie() -> String {
        
        return UserDefaultUtil.getStringValueOf(key: AppStateFlags.xsrfToken.rawValue)
        
    }

    //MARK: LoginFailure
    func loginFailure(){
        
        TouchIDUtility.enbableTouchId(value: false)
        TouchIDUtility.disableTouchIDFeature(value: true)
        let credentials = Credentials.init(userName: "",
                                           password: "")
        
        AppStateData.shared.setCredentials(credentials: credentials)
        self.deleteCookies()
        
    }
    
    // MARK: - Failure and Logout Case
    
    func deleteCookies() {
        
        // Remove all cache
        URLCache.shared.removeAllCachedResponses()
        CookieUtility.clearCookies()
    }
    
    func logout() {
        // app is in logout state, this is for not displaying touch ID prompt
        self.setLogoutState(to: true)
        
        Router.RemoveIdleTimeoutObserver()
        Session.contacts = []
        Session.user = nil
        
        self.deleteCookies()
    }
    
    func setLogoutState(to value: Bool) {
       UserDefaultUtil.configureBool(value: value,
                                     key: AppStateFlags.logoutState.rawValue)
    }
    
    func logoutState() -> Bool {
        return UserDefaultUtil.getBoolValueOf(key: AppStateFlags.logoutState.rawValue)
    }
    
    
    //MARK: - Connection Type
    
    func setInternetConnectionName(value: String) {
        UserDefaultUtil.configureString(stringValue: value,
                                    keyValue: AppStateFlags.connectionType.rawValue)
    }
    
    func getInternetConnectionName() -> String {
        return UserDefaultUtil.getStringValueOf(key: AppStateFlags.connectionType.rawValue)
    }
    
}
