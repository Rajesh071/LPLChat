//
//  LPLUserDefaults.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/17/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import UIKit

class LPLUserDefaults {
    
    
    static func save(key:String , value:String) {
        let userDefaults: UserDefaults? = UserDefaults.standard
        userDefaults?.set(value, forKey: key)
    }
    
    static func retrieve (for key:String) -> String? {
        let userDefaults: UserDefaults? = UserDefaults.standard
        return userDefaults?.string(forKey: key)
    }
}


class DeviceTokenHelpers{
    
    static let KeyNameToken = "tokenSentToServer"

    static func saveToken(token:String) {
        LPLUserDefaults.save(key: KeyNameToken, value: token)
    }
    
    static func getTokenFromStore() -> String? {
        return LPLUserDefaults.retrieve(for: KeyNameToken)
    }
    
    static func getTokenFromApp() -> String? {
        
        if Platform.isSimulator{
            let devTokenSim  = "App in Simulator Mode " + Date().toISO8601String()
            log.verbose(devTokenSim)
            return String(arc4random())
            //return devTokenSim
        }
            
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        var devToken = appDelegate.deviceTokenStr
        
        if devToken == nil{
            log.error("devtoken is empty")
            if EnvOverrides.debugDoDisablePush{
                log.verbose("== DEBUGOVERRIDE == debugDoDisablePush")
                //devToken = "App is running in disablePush mode"
                devToken = ""
            }
        }
        
        log.verbose(devToken as Any)
        
        return devToken
    }
}
