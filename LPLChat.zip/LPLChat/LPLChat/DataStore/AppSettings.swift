//
//  AppSettings.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class AppSettings: NSObject {

    // MARK: - Shared Instance
    
    static let shared: AppSettings = {
        let instance = AppSettings()
        // setup code
        return instance
    }()
    
    // MARK: - Initialization Method
    
    override init() {
        super.init()
    }
    
}
