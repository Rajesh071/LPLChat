//
//  Router.swift
//  LPLMessages
//
//  Created by Phillip English on 5/4/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import UIKit

final class Router {
    
    static func observeIdleTimeout() {
        NotificationCenter.default.post(name: NSNotification.Name.StartIdleTimeOut,
                                        object: nil)
        // listen for notifications
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(presentLoginViewController),
                                               name: Notification.Name.IdleTimeout,
                                               object: nil)
    }
    
    static func RemoveIdleTimeoutObserver() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc static func presentLoginViewController() {
        
        // wait for keyboard to go out of the screen and then present login
        DispatchQueue.main.async {
            
            /* if top controller is already login return because we are already on login.
            This case will come when user is on the login page and put application in background and then come from background
            */

            let topViewController = UIApplication.shared.keyWindow?.topViewController()
            
            guard let topController = topViewController else {
                return
            }

            if topController.isKind(of: UIAlertController.classForCoder()) {
                if let currentController = topController.presentingViewController {
                    if currentController.isKind(of: HybridLoginViewController.classForCoder()) {
                        return
                    }
                }
            }
            
            if topController.isKind(of: HybridLoginViewController.classForCoder()) || topController.isKind(of: ASATViewController.classForCoder()) {
                return
            }
            
            if !(FeatureFlagUtil.getValueOf(key: FeatureFlag.enableBiometric.rawValue) && TouchIDUtility.isTouchIdConfigured()) {
                
                //dismiss every controller from memory and temporarily disable touch id
                TouchIDUtility.disableTouchIDFeature(value: false)
            }
            
            // instantiate hybrid login view controller
            let loginViewController = HybridLoginViewController.build(with: .modal)
            
            // present VC
            topController.present(loginViewController,
                                   animated: true,
                                   completion: nil)
        }// top closure closed
    }

}
