//
//  TitleView.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/21/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

protocol TitleViewDelegates {
    func backButtonPressed()
    func profilePressed()
    func noteButtonPressed()
}


class TitleView: UIView {

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var subTitleLabel: UILabel!
    @IBOutlet var nameInitialLabel: UILabel!
    @IBOutlet var image: UIImageView!
    
    @IBOutlet var noteView: UIView!
    @IBOutlet var activityView: UIView!
    
    @IBOutlet var notesButton: UIButton!

    var titleViewDelegate: TitleViewDelegates!
    
    class func buildWithDelegate(delegate: TitleViewDelegates) -> TitleView {
        let titleView = TitleView.xibView() as! TitleView
        titleView.titleViewDelegate = delegate
        
        // hide both views initially
        titleView.activityView.isHidden = true
        titleView.noteView.isHidden = true
        
        return titleView
    }

    
    // MARK: - Action Methods
    
    @IBAction func backButtonPressed() {
        DispatchQueue.main.async {
         self.titleViewDelegate.backButtonPressed()
        }
    }
    
    @IBAction func noteButtonPressed() {
        DispatchQueue.main.async {
            self.titleViewDelegate.noteButtonPressed()
            self.notesButton.isSelected = !self.notesButton.isSelected
        }
    }
    
    @IBAction func profileTapAction() {
        DispatchQueue.main.async {
            self.titleViewDelegate.profilePressed()
        }
    }
}
