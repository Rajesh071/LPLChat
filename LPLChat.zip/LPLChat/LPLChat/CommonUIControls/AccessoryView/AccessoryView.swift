//
//  AccessoryView.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

typealias DonePressHandler = () -> ()

class AccessoryView: UIView {
    
    var doneCompletionHandler: DonePressHandler?
    
    class func build() -> AccessoryView {
        return AccessoryView.xibView() as! AccessoryView
    }
    
    @IBAction func doneButtonPressed() {
        if doneCompletionHandler != nil {
            self.doneCompletionHandler!()
        }
    }
    
    
}
