//
//  RegistrationRouter.swift
//  LPLMessages
//
//  Created by Phillip English on 4/30/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

enum RegistrationFlow {
    case disclaimer
    case callForward
    case registrationSuccess
}

struct RegistrationRouter {
    static func navigate(to registrationFlow: RegistrationFlow){
        var vc: UIViewController?
        switch registrationFlow {
        case .disclaimer:
            let disclaimerVC = DisclaimerViewController.buildViewController()
            vc = disclaimerVC
            //UIApplication.shared.keyWindow?.rootViewController?.present(disclaimerVC, animated: true, completion: nil)
        case .callForward:
            guard let vn = Session.user?.twilioNumber else {print("no Virtual Business Number (VBN)")
                return
            }
            let callForwardVM = SelectCallForwardingViewModel()
            callForwardVM.selectedVirtualNumber = vn 
            let callForwardVC = SelectCallForwardingViewController.buildViewController(with: callForwardVM)
            vc = callForwardVC
        case .registrationSuccess:
            let registrationSuccessVM = RegistrationSuccessViewModel()
            registrationSuccessVM.virtualPhoneNumber = Session.user?.twilioNumber
            let registrationSuccessVC = RegistrationSuccessViewController.build(with: registrationSuccessVM)
            vc = registrationSuccessVC
            
        }
        guard let viewController = vc else {return}
        
        DispatchQueue.main.async {
                    let navController = UINavigationController.init(rootViewController: viewController)
                    navController.isNavigationBarHidden = true
            if let loginController: HybridLoginViewController = UIApplication.shared.keyWindow?.rootViewController as? HybridLoginViewController {
                
                loginController.present(navController, animated: true, completion: nil)
            }
            
        }
    }
}
