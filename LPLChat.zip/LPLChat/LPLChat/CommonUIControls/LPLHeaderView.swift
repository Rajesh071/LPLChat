//
//  LPLHeaderView.swift
//  LPLMessaging
//
//  Created by Kent Franks on 8/21/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

enum PhoneHeight: Int {
    case iPhoneX = 45
    case iPhoneStandard = 20
}

protocol LPLHeaderDelegate {
    func searchStarted(withSearchString: String)
    func segmentedControlChanged(withIndex: Int)
}

extension LPLHeaderDelegate {
    func segmentedControlChanged(withIndex: Int) {
        
    }
}

class LPLHeaderView: UIView, UISearchBarDelegate {
    
    @IBOutlet var searchBar: UISearchBar?
    @IBOutlet var segmentedControl: UISegmentedControl?
    
    var lplHeaderDelegate: LPLHeaderDelegate?
    let selectedSegmentBar = UIView()
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        if let _ = segmentedControl {
            customizeSegmentedControl()
        }
        customizeSearchBar()
    }
    
    // MARK: - UI
    func customizeSearchBar() {
        searchBar?.backgroundImage = UIImage()
    }
    
    func customizeSegmentedControl() {
        // create segments
        segmentedControl?.removeAllSegments()
        segmentedControl?.insertSegment(withTitle: "Client", at: 0, animated: true)
        segmentedControl?.insertSegment(withTitle: "Prospect", at: 1, animated: true)
        segmentedControl?.insertSegment(withTitle: "Local", at: 2, animated: true)
        segmentedControl?.selectedSegmentIndex = 0
        
        // set colors
        segmentedControl?.backgroundColor = .clear
        segmentedControl?.tintColor = .clear
        selectedSegmentBar.backgroundColor = .lPLBlue1
        
        // set titles
        segmentedControl?.setTitleTextAttributes([NSAttributedStringKey.font : UIFont(name: "Helvetica", size: 18) as Any, NSAttributedStringKey.foregroundColor: UIColor.lightGray], for: .normal)
        segmentedControl?.setTitleTextAttributes([NSAttributedStringKey.font : UIFont(name: "Helvetica", size: 18) as Any, NSAttributedStringKey.foregroundColor: UIColor.darkGray], for: .selected)
        segmentedControl?.addTarget(self, action: #selector(adjustSelectedBar(_:)), for: UIControlEvents.valueChanged)
        
        // add as subviews
        self.addSubview(selectedSegmentBar)
        
        // Constraints
        segmentedControl?.translatesAutoresizingMaskIntoConstraints = false
        selectedSegmentBar.translatesAutoresizingMaskIntoConstraints = false
        
        segmentedControl?.topAnchor.constraint(equalTo: self.topAnchor)
        segmentedControl?.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        segmentedControl?.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        selectedSegmentBar.topAnchor.constraint(equalTo: (segmentedControl?.bottomAnchor)!, constant: -5).isActive = true
        selectedSegmentBar.heightAnchor.constraint(equalToConstant: 1.0).isActive = true
        selectedSegmentBar.leftAnchor.constraint(equalTo: (segmentedControl?.leftAnchor)!).isActive = true
        selectedSegmentBar.widthAnchor.constraint(equalTo: (segmentedControl?.widthAnchor)!, multiplier: 1 / CGFloat((segmentedControl?.numberOfSegments)!)).isActive = true
    }
    
    
    // MARK: - UI Calculations
    func setYposition(offset: CGFloat = 0, height: CGFloat = 0, translucent: Bool)  {
        if translucent {
            self.frame.origin.y = height + CGFloat(getHeightForPhone().rawValue)
        } else {
            if offset < 0 {
                self.frame.origin.y = -offset
            }
        }
    }
    
    func getHeightForPhone() -> (PhoneHeight){
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 2436:
                return .iPhoneX
            default:
                return .iPhoneStandard
            }
        }
        return .iPhoneStandard
    }
    
    // MARK: - Selector
    @objc func adjustSelectedBar(_ sender: UISegmentedControl) {
        UIView.animate(withDuration: 0.3) {
            self.selectedSegmentBar.frame.origin.x = ((self.segmentedControl?.frame.width)! / CGFloat((self.segmentedControl?.numberOfSegments)!)) * CGFloat((self.segmentedControl?.selectedSegmentIndex)!)
        }
    }

    // MARK: - Actions
    @IBAction func segmentControlValueChanged(segmentedControl: UISegmentedControl)  {
        lplHeaderDelegate?.segmentedControlChanged(withIndex: segmentedControl.selectedSegmentIndex)
    }

}
