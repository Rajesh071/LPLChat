//
//  AlertController.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 6/11/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class AlertController: UIAlertController {
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let screenBounds = UIScreen.main.bounds
        self.view.center = CGPoint(x: screenBounds.size.width * 0.5, y: screenBounds.size.height * 0.5)
    }

}
