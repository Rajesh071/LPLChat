//
//  AlertUtil.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/12/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

typealias ActionHandler = (() -> Void)


class AlertUtil: NSObject {
   
    class func showAlert(with title: String,
                             message: String,
                             onController: UIViewController? = nil) {

        DispatchQueue.main.async {
            let alert = AlertController(title: title,
                                          message: message,
                                          preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))

            alert.modalPresentationStyle = .overFullScreen

            if onController != nil {
                onController?.present(alert,
                                      animated: true,
                                      completion: nil)
            } else {
                UIApplication.shared.keyWindow?.rootViewController?.present(alert,
                                                                            animated: true,
                                                                            completion: nil)
            }
        }
    }

    /// Below discussion is to display alert title, subtitle and action handlers
    ///
    /// - Parameters:
    ///   - title: Alert Title
    ///   - message: Alert Message
    ///   - constructiveButtonTitle: Ok Button
    ///   - destructiveButtonTitle: Cancel Button
    ///   - constructiveActionHandler: Ok button press handler
    ///   - destructiveActionHandler: Cancel button press handler
    static func showAlert(with title:String? = "",
                      message: String? = "",
                      constructiveButtonTitle: String?,
                      destructiveButtonTitle: String?,
                      constructiveActionHandler: ActionHandler?,
                      destructiveActionHandler: ActionHandler?,
                      onController: UIViewController? = nil) {
        
        let alert = AlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        alert.view.tag = 1001
        if destructiveActionHandler != nil {
            let action = UIAlertAction.init(title: destructiveButtonTitle,
                                            style: .default) { (action) in
                                                guard let actionHandler = destructiveActionHandler else {
                                                    return
                                                }
                                                DispatchQueue.main.async {
                                                    actionHandler()
                                                }
            }
            
            alert.addAction(action)
        }

        if constructiveActionHandler != nil {
            let action = UIAlertAction.init(title: constructiveButtonTitle,
                                style: .default) { (action) in
                                    guard let actionHandler = constructiveActionHandler else {
                                        return
                                    }
                                    DispatchQueue.main.async {
                                        actionHandler()
                                    }
            }

            alert.addAction(action)
        }

        alert.modalPresentationStyle = .overFullScreen

        DispatchQueue.main.async {
            onController?.present(alert,
                                 animated: true,
                                 completion: nil)
        }
    }
    
    static func showActionsheet(viewController: UIViewController,
                                title: String,
                                message: String?,
                                actions: [(String, UIAlertActionStyle)],
                                completion: @escaping (_ index: Int) -> Void) {
        
        let actionSheetController = UIAlertController(title: title,
                                                      message: message ?? nil,
                                                      preferredStyle: .actionSheet)
        
        for (index, (title, style)) in actions.enumerated() {
            let alertAction = UIAlertAction(title: title,
                                            style: style) { (_) in
                completion(index)
            }
            
            actionSheetController.addAction(alertAction)
        }
        
        viewController.present(actionSheetController,
                               animated: true,
                               completion: nil)
    }
    
}
