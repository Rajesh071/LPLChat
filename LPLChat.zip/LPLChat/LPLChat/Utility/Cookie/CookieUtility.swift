//
//  CookieUtility.swift
//  LPLMessages
//
//  Created by Phillip English on 5/3/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct CookieUtility {
    
    ///Returns value of cookie by key
    static func getCookieValue(key:String) -> String {
        var cookieValue:String = ""
        
        for cookie in (HTTPCookieStorage.shared.cookies)! {
            if cookie.name == key {
                cookieValue = cookie.value
            }
        }
        return cookieValue
    }
    
    ///Returns a string listing each cookie in cookie store seperated by ;
    static func getCookies() -> String {
        var cookieStr = ""
        for cookie in (HTTPCookieStorage.shared.cookies)! {
            cookieStr.append("\(cookie.name)=\(cookie.value);")
        }
        return cookieStr
    }
    
    ///Clears HTTPCookieStorage of any cookie that is not aatoken
//    static func clearCookies() {
//        let storage = HTTPCookieStorage.shared
//        if let cookies = storage.cookies {
//            //Filter "aatoken" out of cookie array so that it is not deleted, then run delete on everything else.
//
//            cookies.filter {$0.name != "aatoken"}.forEach {storage.deleteCookie($0)}
//        }
//    }
    
    static func cookieToPersist() -> [String] {
        return ["aatoken"]
    }

    ///Clears HTTPCookieStorage of any cookie that is not aatoken
    static func clearCookies() {
        let storage = HTTPCookieStorage.shared

        if let cookies = storage.cookies {
            //Filter "aatoken" out of cookie array so that it is not deleted, then run delete on everything else.
            for cookie in cookies {
                if cookieToPersist().contains (cookie.name) == false {
                    storage.deleteCookie(cookie)
                }
            }// for loop closed
        }
    }
    
    
}
