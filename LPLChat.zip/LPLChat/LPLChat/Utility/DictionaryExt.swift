//
//  DictionaryExt.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/24/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

extension Dictionary {
    
    mutating func update(other:Dictionary) {
        for (key,value) in other {
            self.updateValue(value, forKey:key)
        }
    }
    
}
