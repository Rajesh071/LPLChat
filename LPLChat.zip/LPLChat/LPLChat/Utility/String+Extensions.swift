//
//  String+Extensions.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import UIKit

extension NSMutableAttributedString {
    
    func setColor(color: UIColor,
                  forText stringValue: String) {
        let range: NSRange = self.mutableString.range(of: stringValue, options: .caseInsensitive)
        self.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: range)
    }
    
    func setBoldFont(for stringValue: String) {
        let range: NSRange = self.mutableString.range(of: stringValue,
                                                      options: .caseInsensitive)
        self.addAttribute(NSAttributedStringKey.font,
                          value: UIFont(name: "Helvetica Bold", size: 18)!,
                          range: range)
    }
    
}


extension String {

    func trim() -> String    {
        return self.trimmingCharacters(in: NSCharacterSet.whitespaces)
    }
    
    func hasWhiteSpaceOnly() -> Bool {
        return self.trimmingCharacters(in: NSCharacterSet.whitespaces).elementsEqual("")
    }
    
    var isNumber: Bool {
        let characters = CharacterSet.decimalDigits.inverted
        return !self.isEmpty && rangeOfCharacter(from: characters) == nil
    }
    
    func convertToDate() -> Date {
        let dateStr = self
        let formatter = ISO8601DateFormatter()
        
        formatter.formatOptions = [.withFullDate,
                                   .withTime,
                                   .withDashSeparatorInDate,
                                   .withColonSeparatorInTime]
        formatter.timeZone = TimeZone(secondsFromGMT: 0)

        let date = formatter.date(from: dateStr)
        
        if date != nil{
            return date!
        }
        return Date()
    }
    
    func convertToPDTDateFormat() -> Date? {
        // date is in PDF format
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ssZZZ"
        dateFormatter.timeZone = TimeZone.init(abbreviation: "PDT")!
        
        guard let date = dateFormatter.date(from: self) else {
            return nil
        }

        //TODO: ⛔️ Need to find a better way to convert PDT to current time zone. This is temp solution for now
        return date.addingTimeInterval(-1 * 60 * 60)
    }
    
    internal func substring(start: Int, offsetBy: Int) -> String? {
        guard let substringStartIndex = self.index(startIndex, offsetBy: start, limitedBy: endIndex) else {
            return nil
        }
        
        guard let substringEndIndex = self.index(startIndex, offsetBy: start + offsetBy, limitedBy: endIndex) else {
            return nil
        }
        
        return String(self[substringStartIndex ..< substringEndIndex])
    }
    
    // #ffffff - White
    func webViewCompatible(colorHex: String? = "#ffffff") -> String {
        let string = "<html><body style=\"font-size: 17; text-align:justify; font-family: Helvetica; color: \(colorHex!)\">\(self)</body></html>"
        
        return string
    }
    
    func stringByRemovingEmoji() -> String {
        return String(self.filter { !$0.isEmoji() })
    }
    
    func removeWhiteListedCharacters() -> String {
        // white listed characters {+, - , (, ), " "}
        
        var input = self
        let whiteListedCharacters = ["+", "-", "(", ")", " "]
        
        for character in whiteListedCharacters {
            input = input.replacingOccurrences(of: character, with: "")
        }
        
        return input.removeWhitespaces()
    }
    
    func removeWhitespaces() -> String {
        return components(separatedBy: .whitespaces).joined()
    }
    
    static func readableFormOf(_ error: Error) -> String {
        
        var errorInfo = "\(error)"
        errorInfo = errorInfo.replacingOccurrences(of: "invalid(\"", with: "")
        errorInfo = errorInfo.replacingOccurrences(of: "\")", with: "")
        
        return errorInfo
    }
    
}

extension Character {
    fileprivate func isEmoji() -> Bool {
        return Character(UnicodeScalar(UInt32(0x1d000))!) <= self && self <= Character(UnicodeScalar(UInt32(0x1f77f))!)
            || Character(UnicodeScalar(UInt32(0x2100))!) <= self && self <= Character(UnicodeScalar(UInt32(0x26ff))!)
    }
}
