//
//  main.swift
//  LPLMessages
//
//  Created by Phillip English on 5/3/18.
//  Copyright © 2018 LPL. All rights reserved.
//


import UIKit

//We pass our IdleTimeoutUtility, a subclass of UIApplication through the main loop to observe for user interactions. Note that this file must remain named main.swift
UIApplicationMain(
    CommandLine.argc,
    UnsafeMutableRawPointer(CommandLine.unsafeArgv)
        .bindMemory(
            to: UnsafeMutablePointer<Int8>.self,
            capacity: Int(CommandLine.argc)
    ),
    NSStringFromClass(IdleTimeoutUtility.self),
    NSStringFromClass(AppDelegate.self)
)
