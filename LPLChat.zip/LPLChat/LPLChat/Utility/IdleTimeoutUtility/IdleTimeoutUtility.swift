//
//  IdleTimeoutUtility.swift
//  LPLMessages
//
//  Created by Phillip English on 5/3/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import UIKit

extension NSNotification.Name {
    public static let IdleTimeout: NSNotification.Name = NSNotification.Name(rawValue: "IdleTimeout")
    public static let StopIdleTimeOut = Notification.Name(rawValue: "StopIdleTimeOut")
    public static let StartIdleTimeOut = Notification.Name(rawValue: "StartIdleTimeOut")

}

//Note the inheritence from UIApplication
 final class IdleTimeoutUtility: UIApplication {
    //The time between timeout in seconds

    private let timeoutInterval: TimeInterval =  5 * 60
    
    private var timer: Timer?
    
    override init() {
        super.init()
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(stop),
                                               name: Notification.Name.UIApplicationDidEnterBackground,
                                               object: nil)

        NotificationCenter.default.addObserver(self,
                                               selector: #selector(stop),
                                               name: NSNotification.Name.StopIdleTimeOut,
                                               object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(resetTimer),
                                               name: NSNotification.Name.StartIdleTimeOut,
                                               object: nil)
        
        resetTimer()
    }
    
    override func sendEvent(_ event: UIEvent) {
        super.sendEvent(event)
        
        if timer != nil {
            self.resetTimer()
        }
        
        if let touches = event.allTouches {
            for touch in touches {
                if touch.phase == UITouchPhase.began {
                    self.resetTimer()
                }
            }
        }
    }
    
    @objc func stop() {
        if let timer = timer {
            timer.invalidate()
        }
    }
    
    @objc func resetTimer() {
            if let timer = timer {
                timer.invalidate()
            }
            
            timer = Timer.scheduledTimer(timeInterval: timeoutInterval, target: self, selector: #selector(self.idleTimeout), userInfo: nil, repeats: false)
        }
    
    //Broadcasts a timeout notification. To subscribe to timeout, call: NotificationCenter.default.addObserver(self, selector: #selector(someFuncitonName), name: Notification.Name.IdleTimeout, object: nil)
    @objc private func idleTimeout() {
        NotificationCenter.default.post(name:Notification.Name.IdleTimeout, object: nil)
        
    }
}
