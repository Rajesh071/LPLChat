//
//  KeychainUtility.swift
//  LPLMessages
//
//  Created by Phillip English on 5/2/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Security

// Arguments for the keychain queries
let kSecClassValue = NSString(format: kSecClass)
let kSecAttrAccountValue = NSString(format: kSecAttrAccount)
let kSecValueDataValue = NSString(format: kSecValueData)
let kSecClassGenericPasswordValue = NSString(format: kSecClassGenericPassword)
let kSecAttrServiceValue = NSString(format: kSecAttrService)
let kSecMatchLimitValue = NSString(format: kSecMatchLimit)
let kSecReturnDataValue = NSString(format: kSecReturnData)
let kSecMatchLimitOneValue = NSString(format: kSecMatchLimitOne)

///Utility for saving and retrieving username and password to/from the keychain
public class KeychainUtility: NSObject {
    
    class func save(username: String,
                    password: String,
                    completion: @escaping (Bool)-> Void) {
        let pwData = password.data(using: .utf8)
        
        //Saving Username in defaults//
        let defaults = UserDefaults.standard
        defaults.set(username, forKey: "username")
        
        let pwQuery = [kSecClassValue       : kSecClassGenericPassword as String,
                       kSecAttrAccountValue : username,
                       kSecValueDataValue   : pwData as Any ] as [String: Any]
                
        let pwStatus: OSStatus = SecItemAdd(pwQuery as CFDictionary, nil)
        
//        let credentials = self.retrieveCredentials()
        
        if pwStatus == errSecSuccess {
            completion(true)
        } else {
            completion(false)
        }
    }
    
    //Returns an optional Credentials object from Keychain query
    class func retrieveCredentials() -> Credentials? {

        //Retrieving Username from defaults//
        let defaults = UserDefaults.standard
        if let username: String = defaults.value(forKey: "username") as? String {
            
            let pwQuery = [
                kSecClassValue : kSecClassGenericPassword,
                kSecAttrAccountValue : username,
                kSecReturnDataValue : kCFBooleanTrue,
                kSecMatchLimitValue : kSecMatchLimitOne ] as [String: Any]
            var pwDataTypeRef: AnyObject? = nil
            let pwStatus: OSStatus = SecItemCopyMatching(pwQuery as CFDictionary, &pwDataTypeRef)
            guard pwStatus == noErr else { return nil }
            guard let pwData = pwDataTypeRef as! Data? else {return nil}
            guard let pwString = String(data: pwData, encoding: .utf8) else {return nil}
            
            let credentials = Credentials(userName: username, password: pwString)

            return credentials

        }
        
        return nil
        
    }
    
    //Remove the stored Credentials//
    class func removeCredentials(username: String) {
        
        //Get the old username//
        let defaults = UserDefaults.standard
        if let storedUser = defaults.value(forKey: "username") {
            
            if (storedUser as? String) != username {
                
                // Instantiate a new default keychain query
                let keychainQuery: NSMutableDictionary = NSMutableDictionary(objects: [kSecClassGenericPassword, username, kCFBooleanTrue, kSecMatchLimitOneValue],
                                                                             forKeys: [kSecClassValue, kSecAttrAccountValue, kSecReturnDataValue, kSecMatchLimitValue])
                
                // Delete any existing items
                defaults.removeObject(forKey: "username")
                let status = SecItemDelete(keychainQuery as CFDictionary)
                if status != errSecSuccess {
                    
                    print("New User: The account is deleted.")
                }
            }
        }
        
    }
}
