//
//  ViewControllerExt.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/21/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

extension UIViewController {
    
    var isModal: Bool {
        if let index = navigationController?.viewControllers.index(of: self), index > 0 {
            return false
        } else if presentingViewController != nil {
            return true
        } else if navigationController?.presentingViewController?.presentedViewController == navigationController  {
            return true
        } else if tabBarController?.presentingViewController is UITabBarController {
            return true
        } else {
            return false
        }
    }
    
    class func build(with storyBoardName: String, and identifier: String) -> UIViewController? {
        let storyboard = UIStoryboard(name: storyBoardName, bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier :identifier)

        return viewController
    }
    
}
