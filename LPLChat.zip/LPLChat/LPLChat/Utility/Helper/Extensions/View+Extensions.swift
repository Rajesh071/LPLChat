//
//  ViewExt.swift
//  Workout
//
//  Created by Sanjeev Bharti on 2/14/18.
//  Copyright © 2018 Sanjeev Bharti. All rights reserved.
//

import Foundation
import UIKit


extension UIView {
    
    /// Below discussion will return view from XIB
    ///
    /// - Returns: view from xib
    class func xibView() -> UIView {
        let view = Bundle.main.loadNibNamed(String(describing: self), owner: self,
                                                   options: [:])?.first
        
        return view as! UIView
    }
    
    /// add round corner to current view
    func roundCorner(cornerRadius: CGFloat? = 1,
        borderWidth: CGFloat? = 1,
        borderColor: UIColor? = UIColor.darkGray) {
        self.layer.cornerRadius = cornerRadius!
        self.layer.borderWidth = borderWidth!
        self.layer.borderColor = borderColor?.cgColor
        self.clipsToBounds = true
    }

    func enabledState() {
        DispatchQueue.main.async {
            self.isUserInteractionEnabled = true
            self.alpha = 1.0
        }
    }
    
    func disabledState() {
        DispatchQueue.main.async {
            self.isUserInteractionEnabled = false
            self.alpha = 0.4
        }
    }

    var parentViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            parentResponder = parentResponder?.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
    
    // MARK: - Animation Methods
    
    func pulsate() {
        
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.2
        pulse.fromValue = 0.95
        pulse.toValue = 1.0
        //        pulse.autoreverses = true
        pulse.repeatCount = 0
        pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        
        layer.add(pulse, forKey: "pulse")
    }
    
    func flash() {
        
        let flash = CABasicAnimation(keyPath: "opacity")
        flash.duration = 0.2
        flash.fromValue = 1
        flash.toValue = 0.1
        flash.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        flash.autoreverses = true
        flash.repeatCount = 1
        
        layer.add(flash, forKey: nil)
    }
    
    
    func shake() {
        let shake = CABasicAnimation(keyPath: "position")
        shake.duration = 0.05
        shake.repeatCount = 3
        shake.autoreverses = true
        
        let fromPoint = CGPoint(x: center.x - 5, y: center.y)
        let fromValue = NSValue(cgPoint: fromPoint)
        
        let toPoint = CGPoint(x: center.x + 5, y: center.y)
        let toValue = NSValue(cgPoint: toPoint)
        
        shake.fromValue = fromValue
        shake.toValue = toValue
        
        layer.add(shake, forKey: "position")
    }
}
