//
//  CustomTextfield.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/4/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//

import UIKit

@IBDesignable

class CustomTextfield: UITextField {

    @IBInspectable var defaultPlaceHolderColor: UIColor? = UIColor.lightGray
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        
        self.setValue(defaultPlaceHolderColor,
                      forKeyPath: "_placeholderLabel.textColor")
        self.tintColor = UIColor.white
        self.autocorrectionType = .no
    }
 
}
