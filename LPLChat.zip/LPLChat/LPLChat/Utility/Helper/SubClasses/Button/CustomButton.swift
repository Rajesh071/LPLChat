//
//  CustomButton.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 4/4/18.
//  Copyright © 2018 Sanjeev Bharati. All rights reserved.
//
//
import UIKit

@IBDesignable

class CustomButton: UIButton {

    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
//        self.disabledState()
        self.titleEdgeInsets = UIEdgeInsets(top: 0.0, left: 10.0, bottom: 0.0, right: 10.0)
        self.titleLabel?.adjustsFontSizeToFitWidth = true;
        self.titleLabel?.minimumScaleFactor = 0.5
    }

}
