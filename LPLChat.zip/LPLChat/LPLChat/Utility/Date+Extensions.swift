//
//  Date+Extensions.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/10/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

extension Date
{
    func toISO8601String ()->String{
        let date = self
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions.insert(.withFractionalSeconds)  // this is only available effective iOS 11 and macOS 10.13
        let dateString = formatter.string(from: date)
        
        return dateString
    }
    
    func toString( dateFormat format  : String ) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
    
    var startOfDay : Date {
        let calendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.year, .month, .day])
        let components = calendar.dateComponents(unitFlags, from: self)
        return calendar.date(from: components)!
    }
    
    func ConvertDateToReadableString () -> String {
        let date = self
        let components = Set<Calendar.Component>([.day])
        let differenceOfDate = Calendar.current.dateComponents(components, from: date.startOfDay, to: Date().startOfDay)
        
        if differenceOfDate.day! > 7 {
            return date.toString(dateFormat: "MMM dd,yyyy")
        }
        if differenceOfDate.day! >= 2 {
            return date.toString(dateFormat: "eeee") //displays Sunday,Monday
        }
        else if differenceOfDate.day! >= 1 {
            return "Yesterday"
        }
        return date.toString(dateFormat: "h:mm a")
    }
    
    func timeOnly() -> String? {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a "
        formatter.amSymbol = "AM"
        formatter.pmSymbol = "PM"
        
        return formatter.string(from: self)
    }
    
    func monthAndDateOnly() -> String? {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/dd"
        
        return formatter.string(from: self)
    }
    
}
