//
//  BackButtonView.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/22/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

protocol BackButtonDelegate {
    func backButtonPressAction()
}


class BackButtonView: UIView {

    @IBOutlet weak var backButton: UIButton!
    
    var buttonDelegate: BackButtonDelegate!
    
    class func buildWithDelegate(delegate: BackButtonDelegate,
                                 imageName: String? = "backButton") -> BackButtonView {
        let backButtonView = BackButtonView.xibView() as! BackButtonView
        backButtonView.buttonDelegate = delegate
        backButtonView.backButton.setImage(UIImage(named: imageName!), for: .normal)
        
        return backButtonView
    }
    
    
    // MARK: - Action Methods
    
    @IBAction func backButtonAction() {
        self.buttonDelegate.backButtonPressAction()
    }

}
