//
//  Utility.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 3/9/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

struct Platform {
    
    static var isSimulator: Bool {
        return TARGET_OS_SIMULATOR != 0
    }
    
}
