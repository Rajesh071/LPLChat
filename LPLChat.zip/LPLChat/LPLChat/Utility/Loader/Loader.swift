//
//  Loader.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 5/2/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class Loader: UIView {
    
    // MARK: - Shared Instance
    
    static let shared: Loader = {
        let instance = Loader()
        
        // setup code
        instance.customInit()
        return instance
    }()


    //MARK: - Public Methods

    func add(to view: UIView) {
        // fetch top controller from window
        DispatchQueue.main.async {
            view.addSubview(self)
        }
    }

    func add() {
        // fetch top controller of window
        DispatchQueue.main.async {
            UIApplication.shared.keyWindow?.addSubview(self)
        }
    }
    
    func remove() {
        DispatchQueue.main.async {
            self.removeFromSuperview()
        }
    }
    
    //MARK: - Private Methods
    
    private func updateView(with alphaValue: CGFloat) {
        UIView.animate(withDuration: 0.2,
                       animations: {
                        self.alpha = alphaValue
        })
    }
    
    private func customInit() {
        let view = Loader.xibView() as! Loader
        self.frame = UIScreen.main.bounds
        view.frame = self.bounds
        self.addSubview(view)
    }
    
}
