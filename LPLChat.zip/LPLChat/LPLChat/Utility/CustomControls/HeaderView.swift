//
//  HeaderView.swift
//  LPLChat
//
//  Created by Animesh Ravi Paranur on 2/26/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class HeaderView: UIView {
    
    @IBOutlet weak var intialLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var companyLbl: UILabel!
    @IBOutlet weak var callBtn: UIButton!
    @IBOutlet weak var msgBtn: UIButton!
    @IBOutlet weak var initialView: UIView!
    @IBOutlet weak var marketValueLbl: UILabel!
    @IBOutlet weak var gainLossLbl: UILabel!
    @IBOutlet weak var profileImage: RoundedImageView!
    @IBOutlet weak var asOfDateLbl: UILabel!
    
    let nibName = "HeaderView"
  
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        Bundle.main.loadNibNamed(nibName, owner: self, options: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
}


