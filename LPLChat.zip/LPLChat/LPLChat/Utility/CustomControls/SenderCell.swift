//
//  SenderCell.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import Foundation

class SenderCell: UITableViewCell {

    @IBOutlet weak var profilePic: RoundedImageView!
    @IBOutlet weak var message: ChatDetailsTextView!
    @IBOutlet weak var messageBackground: UIImageView!
    @IBOutlet weak var uiLabelMsgStatus: UILabel!
    @IBOutlet weak var uiLabelTime: UILabel!
    
    func clearCellData()  {
        self.message.text = ""
        self.uiLabelTime.text = ""
        //self.uiLabelMsgStatus.text = ""
        self.message.isHidden = false
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none

        self.message.textContainerInset = UIEdgeInsetsMake(5, 5, 5, 5)
        
        message.backgroundColor = UIColor(hexString: "#0076D1")
        message.clipsToBounds = true
        message.layer.cornerRadius = 15
        message.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner, .layerMinXMaxYCorner]
        
        message.layer.shadowColor = UIColor.black.cgColor
        message.layer.shadowOpacity = 1
        message.layer.shadowOffset = CGSize.zero
        message.layer.shadowRadius = 10
        
        message.linkTextAttributes =  [NSAttributedStringKey.underlineStyle.rawValue: NSUnderlineStyle.styleSingle.rawValue, NSAttributedStringKey.underlineColor.rawValue: UIColor.white, NSAttributedStringKey.foregroundColor.rawValue: UIColor.white]

    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
}


