//
//  ReceiverCell.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/16/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import Foundation

class ReceiverCell: UITableViewCell {
    
    @IBOutlet weak var message: ChatDetailsTextView!
    @IBOutlet weak var messageBackground: UIImageView!
   
    
    func clearCellData()  {
        self.message.text = ""
        self.message.isHidden = false
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        self.message.textContainerInset = UIEdgeInsetsMake(5, 5, 5, 5)
       
        message.backgroundColor  = UIColor(hexString: "#DCDCDC")//UIColor.lightGray
        message.clipsToBounds = true
        message.layer.cornerRadius = 15
        message.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner, .layerMinXMinYCorner]
        
        message.layer.shadowColor = UIColor.black.cgColor
        message.layer.shadowOpacity = 1
        message.layer.shadowOffset = CGSize.zero
        message.layer.shadowRadius = 10        
    }
}

