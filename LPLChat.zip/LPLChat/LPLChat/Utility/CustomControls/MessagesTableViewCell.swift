//
//  MessagesTableViewCell.swift
//  LPLMessaging
//
//  Created by Kent Franks on 8/24/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class MessagesTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var messageLbl: UILabel!
    @IBOutlet weak var customerView: RoundedImageView!
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var chatIntialLbl: UILabel!
    @IBOutlet weak var blueCircleView: UIView?
    @IBOutlet weak var unreadCountLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        blueCircleView?.backgroundColor = .lPLBlue1
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}

extension UILabel {
    
    func calculateMaxLines() -> Int {
        let maxSize = CGSize(width: frame.size.width, height: CGFloat(Float.infinity))
        let charSize = font.lineHeight
        let text = (self.text ?? "") as NSString
        let textSize = text.boundingRect(with: maxSize, options: .usesLineFragmentOrigin, attributes: [.font: font], context: nil)
        let lines = Int(textSize.height/charSize)
        return lines
    }
    
}
