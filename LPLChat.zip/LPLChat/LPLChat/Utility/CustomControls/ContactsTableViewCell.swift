//
//  ContactsTableViewCell.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class ContactsTableViewCell: UITableViewCell {

    @IBOutlet weak var customerView: RoundedImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
    @IBOutlet weak var asOfDateLbl: UILabel!
    @IBOutlet weak var newIndicator: UIImageView!
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var chatIntialLbl: UILabel!
    @IBOutlet weak var blueCircleView: UIView?
    @IBOutlet weak var unreadCountLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        blueCircleView?.backgroundColor = .lPLBlue1
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}

