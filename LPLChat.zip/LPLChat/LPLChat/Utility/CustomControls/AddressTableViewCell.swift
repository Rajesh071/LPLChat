//
//  File.swift
//  LPLChat
//
//  Created by Avinash Rajendran on 2/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import UIKit

class AddressTableViewCell: UITableViewCell {
    
    @IBOutlet weak var uiLabelType: UILabel!
    
    @IBOutlet weak var uiLabelLine1: UILabel!
    @IBOutlet weak var uiLabelLine2: UILabel!
    @IBOutlet weak var uiLabelState: UILabel!
    @IBOutlet weak var uiLabelCity: UILabel!
    @IBOutlet weak var uiLabelZipCode: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
