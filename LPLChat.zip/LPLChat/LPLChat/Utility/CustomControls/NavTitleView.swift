//
//  NavTitleView.swift
//  LPLChat
//
//  Created by Animesh Ravi Paranur on 3/3/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class titleView: UIView {

    @IBOutlet weak var initialLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    //clickable Title
    @IBOutlet weak var uiBtnCompleteView: UIButton!
    
    var nibName = "NavTitleView"
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        Bundle.main.loadNibNamed(nibName, owner: self, options: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
    override var intrinsicContentSize: CGSize {
        return CGSize(width: 200, height: 44)
    } 


}

