//
//  APNSUtil.swift
//  LPLMessaging
//
//  Created by Sanjeev Bharati on 8/24/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation

class APNSUtil {
    
    static func name(from userInfo: Dictionary<AnyHashable, Any>) -> String? {
        
        return userInfo["investorname"] as? String
    }
    
    static func number(from userInfo: Dictionary<AnyHashable, Any>) -> String? {
        var contactNumber: String?
        let info = userInfo["aps"] as? Dictionary<AnyHashable, Any>
        if let aps = info {
            let alertDict = aps["alert"] as? Dictionary<AnyHashable, Any>
            if let alert = alertDict {
                contactNumber = alert["title"] as? String
            }
        }
        
        return contactNumber
    }
    
}
