
 //
//  ContactUtility.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/23/18.
//  Copyright © 2018 LPL. All rights reserved.
//


import Foundation
import Contacts
import UIKit


public class ContactUtility {
    
    //MARK:- Public Methods
    
    static func convertToProfile(phoneContact:CNContact) -> Profile {
        
        var name:String? = ""
        if phoneContact.givenName.count > 0 {
            name = CNContactFormatter().string(from: phoneContact)!
        } else {
            
            // if there is no name of the contact assign it first number
            if phoneContact.phoneNumbers.count > 0 {
                name = phoneContact.phoneNumbers[0].value.stringValue
            }
        }
        
        var phoneNumbers : [PhoneNumber] = []
        
        for pn in phoneContact.phoneNumbers {
            let localizedLabel = CNLabeledValue<CNPhoneNumber>.localizedString(forLabel: pn.label!)
            phoneNumbers.append(PhoneNumber(displayValue:pn.value.stringValue,  label: localizedLabel, isFav: false))
        }
        
        var emails : [Email] = []
        for email in phoneContact.emailAddresses {
            
            let label = CustomUtility.removeSpecialCharsFromString(text: email.label!)
            emails.append(Email.init(value: email.value as String,
                                     label: label))
        }
        
        var addresses : [Address] = []
        for address in phoneContact.postalAddresses {
            
            let addressLabel = CustomUtility.removeSpecialCharsFromString(text: address.label!)
            addresses.append(Address.init(label: addressLabel,
                                          line1: address.value.street,
                                          line2: "",
                                          line3: "",
                                          city: address.value.city,
                                          state: address.value.state,
                                          zipCode: address.value.postalCode))
        }
        
        let dateFormatter = DateFormatter()
        var birthdayString: String?
        if let birthday = phoneContact.birthday, let birthdate = Calendar.current.date(from: birthday) {
            dateFormatter.dateFormat = "MMMM dd, yyyy";
            birthdayString = dateFormatter.string(from: birthdate)
        }
        
        var anniversaryString: String?
        let anniversary = phoneContact.dates.filter { date -> Bool in
            guard let label = date.label else { return false }
            return label.contains("Anniversary")
            }.first?.value as DateComponents?
        
        dateFormatter.dateFormat = "MMMM dd"
        dateFormatter.timeZone = TimeZone(identifier: "UTC")
        if let anniversaryDate = anniversary?.date {
            anniversaryString = dateFormatter.string(from: anniversaryDate)
        }
        
        let date = Date()
        let dateStr:String = date.toISO8601String()
        
        let profile = Profile(name:name!,
                              phoneNumbers: phoneNumbers,
                              emails:emails,
                              addresses:addresses,
                              birthday:birthdayString,
                              anniversary: anniversaryString,
                              amountValue: 0,
                              variationValue: 0,
                              asOfDateStr:dateStr)
        
        return profile
    }
    
    static func mapName(to phoneNumber:String) -> String {
        
        let map = self.contactListToMap()
        
        let unformattedPhoneNumber = phoneNumber.removeWhiteListedCharacters()
        
        guard let value = map[unformattedPhoneNumber] else {
            // if name did not match in the list return the number as name
            return NumberUtil.format(phoneNumber: phoneNumber)!
        }
        
        if value.count > 0 {
            let removedWhiteSpaces = value.removeWhitespaces()
            if removedWhiteSpaces.isEmpty {
                return phoneNumber
            }
        }
        
        return value
    }
    
    /// deviceContacts method
    ///
    /// - Returns: List of contacts from device
    static func deviceContacts() -> [CNContact] {
        let contactStore = CNContactStore()
        var contacts = [CNContact]()
        let keys = [
            CNContactPostalAddressesKey,
            CNContactFormatter.descriptorForRequiredKeys(for: .fullName),
            CNContactPhoneNumbersKey,
            CNContactEmailAddressesKey,
            CNContactBirthdayKey,
            CNContactDatesKey
            ] as [Any]
        
        let request = CNContactFetchRequest(keysToFetch: keys as! [CNKeyDescriptor])
        request.sortOrder = CNContactSortOrder.givenName
        
        do {
            try contactStore.enumerateContacts(with: request) { (contact, stop) in
                contacts.append(contact)
            }
        } catch {
            print(error.localizedDescription)
        }
        return contacts
    }
    
    //MARK:- Private Methods
    
    /// Below method is to map a device contact to name
    ///
    /// - Returns: a dictionary with mapped phone number with name
    func mapDeviceContactsToName() -> [String : String] {
        
        var localContactDict: [String: String] = [:]
        let contacts = ContactUtility.deviceContacts()
        
        for contact in contacts {
            let fullName = contact.givenName + " " + contact.familyName
            for phoneNumber in contact.phoneNumbers {
                
                // phoneNumber: is of type CNLabeledValue<CNPhoneNumber>
                self.add(contactNumber: phoneNumber.value.stringValue,
                         contactName: fullName,
                         to: &localContactDict)
            }
        }
        
        return localContactDict
    }
    
    func add(contactNumber: String,
             contactName: String,
             to dict:inout [String: String]) {
        
        var unFormattedValue = contactNumber.removeWhiteListedCharacters()
        
        // is valid number after removal of whitelisted characters
        if unFormattedValue.isNumber && unFormattedValue.count >= 10 {
            
            // has 10 digits only then prepend ISD code
            if unFormattedValue.count == 10 {
                unFormattedValue = "1" + unFormattedValue
            }
            
            dict.updateValue(contactName,
                             forKey: unFormattedValue)
        }
    }
    
    /// Below method is to map a client works contact to name
    ///
    /// - Returns: a dictionary with mapped phone number with name
    func mapClientWorkContactsToName() -> [String : String] {
        var clientWorkDict: [String: String] = [:]
        
        for contact in Session.contacts {
            self.add(contactNumber: contact.phoneNumber,
                     contactName: contact.nameValue,
                     to: &clientWorkDict)
            
            // if there would be mobile number associated with client work contact add that to dictionary
            if let contactNumberValue = contact.mobilePhone {
                self.add(contactNumber: contactNumberValue,
                         contactName: contact.nameValue,
                         to: &clientWorkDict)
            }
        }
        
        return clientWorkDict
    }
    
    // based on phone number - get cw or phone contact.
    class func getClientWorksOrPhoneContact (_ phone:String,
                                             name:String) -> (Contacts?,CNContact?) {
        
        let phone = ContactUtility.removeSpecialCharactersFromNumber(phone)
        
        let matchingClientWorksContact: Contacts? = Session.contacts.first {
            ContactUtility.removeSpecialCharactersFromNumber($0.mobilePhone ?? "") == phone
                || ContactUtility.removeSpecialCharactersFromNumber($0.businessPhone ?? "") == phone
                || ContactUtility.removeSpecialCharactersFromNumber($0.phoneNumber ?? "") == phone
        }
        
        if let matchingClientWorksContact = matchingClientWorksContact {
            return (matchingClientWorksContact, nil)
        }
        
        let mapDeviceContactsToName = ContactUtility.deviceContacts()
        
        let unformattedPhone = phone.removeWhiteListedCharacters()
        
        for deviceContact:CNContact in mapDeviceContactsToName {
            
            if unformattedPhone.count > 0 {
                
                // loop through each number in the contact book
                for phone in deviceContact.phoneNumbers {
                    if (unformattedPhone.contains(phone.value.stringValue.removeWhiteListedCharacters())) {
                        return (nil, deviceContact)
                    }
                }
            }
        }
        
        // Temp Fix -> if contact is not present in both ClientWorks and Device treat it as local contact with phone number
        
        let contact = CNMutableContact()
        contact.givenName = name;
        
        let homePhone = CNLabeledValue(
            label:CNLabelPhoneNumberMain,
            value:CNPhoneNumber(stringValue:phone))
        
        contact.phoneNumbers = [homePhone]
        
        return (nil, contact)
    }
    
    static func contactListToMap() -> [String : String] {
        
        var finalContactDict = [String:String]()
        finalContactDict.update(other: ContactUtility().mapDeviceContactsToName())
        finalContactDict.update(other: ContactUtility().mapClientWorkContactsToName())
        
        return finalContactDict
    }
    
    static func removeSpecialCharactersFromNumber(_ number: String) -> String {
        
        var contact = ""
        if number.count > 0 {
            let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
            let compSepByCharInSet = number.components(separatedBy: aSet)
            let numberFiltered = compSepByCharInSet.joined(separator: "")
            contact = numberFiltered
        }
        
        return contact
    }
    
    /// Below discussion is to create and CNMutableContact
    ///
    /// - Parameters:
    ///   - firstName: First Name of person
    ///   - lastName: Last Name of person
    ///   - mobileNumber: Mobile Number of person
    ///   - emailAddress: Email Address of person
    /// - Returns: CNMutableContact object
    static func createContact(with firstName: String,
                              lastName: String,
                              mobileNumber: String,
                              emailAddress: String) -> CNMutableContact {
        
        // Creating a mutable object to add to the contact
        let contact = CNMutableContact()
        
        contact.givenName = firstName
        contact.familyName = lastName
        
        let mobilePhone = CNLabeledValue(
            label:CNLabelPhoneNumberMobile,
            value:CNPhoneNumber(stringValue:mobileNumber))
        contact.phoneNumbers = [mobilePhone]
        
        // if email is not empty
        if !emailAddress.isEmpty {
            let homeEmail = CNLabeledValue(label: CNLabelHome,
                                           value: emailAddress as NSString)
            contact.emailAddresses = [homeEmail]
        }
        
        return contact
    }
    
    
    /// Below discussion save a contact to Native Address Book
    ///
    /// - Parameter contact: CNContact type
    /// - Returns: true if successful else false
    static func save(contact: CNMutableContact) -> Bool {
        // Saving the newly created contact
        let store = CNContactStore()
        let saveRequest = CNSaveRequest()
        saveRequest.add(contact, toContainerWithIdentifier:nil)
        
        do {
            // save contact
            try store.execute(saveRequest)
            
            return true
        } catch {
            
            return false
        }
    }

    static func hasPermissionToAccessDeviewContacts() -> Bool {

        let status = CNContactStore.authorizationStatus(for: .contacts)

        var isAuthorized = true
        if status != .authorized {
            isAuthorized = false
        }

        return isAuthorized
    }
    
    static func displayAccessToDeviceContactsAlert(on controller: UIViewController) {
        AlertUtil.showAlert(with: nil,
                               message: "Please provide access to device contact",
                               constructiveButtonTitle: "Settings",
                               destructiveButtonTitle: "Cancel",
                               constructiveActionHandler: {
                                
                                guard let url = URL(string: UIApplicationOpenSettingsURLString) else {
                                    return
                                }
                                
                                UIApplication.shared.open(url,
                                                          options: [:],
                                                          completionHandler: nil)},
                               destructiveActionHandler: {},
                               onController: controller)
    }
    
    static func retrieveInitials(from text:String) -> String {
        
        let initials = CustomUtility.returnStringInitials(text)
        let numbersRange = initials.rangeOfCharacter(from: .decimalDigits)
        
        if numbersRange == nil {
            return CustomUtility.returnStringInitials(text)
        } else {
            return ""
        }
    }
    
}
