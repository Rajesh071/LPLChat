//
//  FeatureFlagUtil.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit


class FeatureFlagUtil: NSObject {

    // this method will only called once to set the initial values of feature flag
    class func configureDefaultValuesOfFeatureFlag() {
    
        let defaultValue = FeatureFlagUtil.getValueOf(key: FeatureFlag.defaultSetting.rawValue)
 
        if !defaultValue {
            //Alert!!!!! don't change state of this flag. This is for persisting the feature flag values
            FeatureFlagUtil.configureBool(value: true,
                                              key: FeatureFlag.defaultSetting.rawValue)
            
            // Configure feature flags
            
            // force registration flag
            FeatureFlagUtil.configureBool(value: false,
                                          key: FeatureFlag.forceUserRegistation.rawValue)
            // skip registration flag
            FeatureFlagUtil.configureBool(value: false,
                                          key: FeatureFlag.skipUserRegistation.rawValue)
            // bypass or not login page
            FeatureFlagUtil.configureBool(value: false,
                                          key: FeatureFlag.displayLoginWebPage.rawValue)
            // debug call forwarding
            FeatureFlagUtil.configureBool(value: true,
                                          key: FeatureFlag.twilioPhoneNumberRegistration.rawValue)
            // enable or disable biometrics
            // debug call forwarding
            FeatureFlagUtil.configureBool(value: true,
                                          key: FeatureFlag.enableBiometric.rawValue)
        }
    }
    
    class func configureBool(value: Bool,
                             key: String) {
        UserDefaultUtil.configureBool(value: value,
                                      key: key)
    }
    
    class func getValueOf(key: String) -> Bool {
    
        return UserDefaultUtil.getBoolValueOf(key: key)
    }
    
}
