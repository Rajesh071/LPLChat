//
//  UserDefaultUtil.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

enum CredentialsEnum: String {
    case userName = "UserName"
    case password = "password"
}

struct UserDefaultUtilConstants {
    
    static let displayTouchIdConst = "touchIdEnabled"
    static let displayTouchIdAlertPopup = "displayTouchIdPopup"
    static let biometricPrefConst = "biometricEnabled"

}


class UserDefaultUtil: NSObject {

    class func configureBool(value: Bool,
                             key: String) {
        
//        print("user defaults: key: \(key) :: value: \(value)")
        UserDefaults.standard.set(value,
                                  forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    class func getBoolValueOf(key: String) -> Bool {
        return UserDefaults.standard.bool(forKey: key)
    }
    
    class func configureString(stringValue: String,
                               keyValue: String) {
      
        UserDefaults.standard.set(stringValue,
                                  forKey: keyValue)
        UserDefaults.standard.synchronize()
    }
    
    class func getStringValueOf(key: String) -> String {
        
        if UserDefaults.standard.value(forKey: key) != nil {
            
            return UserDefaults.standard.value(forKey: key) as! String

        }
        
        return ""
        
    }

}
