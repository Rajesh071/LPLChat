//
//  SettingsAccessViewController.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class SettingsAccessViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // put a check for debug or release mode

        #if DEBUG
         //   self.configureSettingButton()
        #else
        // enter release mode
        
        #endif
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureSettingButton() {
        let settingView = SettingUI.build()
        settingView.frame = CGRect.init(x: self.view.frame.size.width - settingView.frame.size.width,
                                        y: self.view.frame.size.height - settingView.frame.size.height *  2,
                                        width: settingView.frame.size.width,
                                        height: settingView.frame.size.height)
        
        settingView.buttonPressHandler = {
            let storyboard = UIStoryboard.init(name: "FeatureFlagTableViewController",
                                               bundle: nil)
            let featureFlagController = storyboard.instantiateViewController(withIdentifier: "FeatureFlagTableViewController")
            
            DispatchQueue.main.async {
                self.present(featureFlagController,
                             animated: true,
                             completion: nil)
            }
        }
        
        self.view.addSubview(settingView)
        self.view.subviews.last?.bringSubview(toFront: settingView)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
