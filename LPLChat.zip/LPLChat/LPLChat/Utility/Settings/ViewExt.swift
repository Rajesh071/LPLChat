//
//  ViewExt.swift
//  Workout
//
//  Created by Sanjeev Bharti on 2/14/18.
//  Copyright © 2018 Sanjeev Bharti. All rights reserved.
//

import Foundation
import UIKit


extension UIView {
    
    /// Below discussion will return view from XIB
    ///
    /// - Returns: view from xib
    class func xibView() -> UIView {
        let view = Bundle.main.loadNibNamed(String(describing: self), owner: self,
                                                   options: [:])?.first
        
        return view as! UIView
    }
    
    /// add round corner to current view
    func roundCorner(cornerRadius: CGFloat, borderWidth: CGFloat) {
        self.layer.cornerRadius = cornerRadius
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = UIColor.darkGray.cgColor
        self.clipsToBounds = true
    }

}
