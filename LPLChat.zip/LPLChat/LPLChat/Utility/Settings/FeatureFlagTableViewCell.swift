//
//  FeatureFlagTableViewCell.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class FeatureFlagTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
