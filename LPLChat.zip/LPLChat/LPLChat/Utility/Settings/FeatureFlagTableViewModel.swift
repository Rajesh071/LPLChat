//
//  FeatureFlagTableViewModel.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

enum FeatureFlag: String {
    case forceUserRegistation = "ForceRegistration"
    case skipUserRegistation = "SkipRegistration"
    case twilioPhoneNumberRegistration = "BypasstwilioPhoneNumberRegistration"
    case displayLoginWebPage = "DisplayLoginWebPage"
    case enableBiometric = "EnableBiometric"
    case defaultSetting = "DefaultSetting"
}

enum SwitchType: Int {
    case forceRegistration = 0
    case skipRegistration
    case twilioPhoneRegistration
    case displayLoginPage
    case enableBioMetric
}


class FeatureFlagTableViewModel: NSObject {
    
    // each switch has tag value which is set in Feature flag storyboard
    func enableOrDisableFeatureFlag(currentSwitch: UISwitch) {
        var key = ""
        switch currentSwitch.tag {
        case SwitchType.forceRegistration.rawValue:
            key = FeatureFlag.forceUserRegistation.rawValue
        case SwitchType.skipRegistration.rawValue:
            key = FeatureFlag.skipUserRegistation.rawValue
        case SwitchType.twilioPhoneRegistration.rawValue:
            key = FeatureFlag.twilioPhoneNumberRegistration.rawValue
        case SwitchType.displayLoginPage.rawValue:
            key = FeatureFlag.displayLoginWebPage.rawValue
        case SwitchType.enableBioMetric.rawValue:
            key = FeatureFlag.enableBiometric.rawValue

        default:
            break
        }
        
        FeatureFlagUtil.configureBool(value: currentSwitch.isOn,
                                      key: key)
    }
}
