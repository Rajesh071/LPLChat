//
//  SettingUI.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/25/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

typealias ButtonPressHandler = () -> Void

class SettingUI: UIView {

    var buttonPressHandler: ButtonPressHandler!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    class func build() -> SettingUI {
        let settings = SettingUI.xibView() as! SettingUI
        
        return settings
    }

    @IBAction func settingButtonAction() {
        if (buttonPressHandler != nil) {
            self.buttonPressHandler()
        }
    }
    
    
}
