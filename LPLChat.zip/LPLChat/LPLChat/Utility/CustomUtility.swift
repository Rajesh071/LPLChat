//
//  CustomUtility.swift
//  LPLChat
//
//  Created by Animesh ParanurRavi on 2/14/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import Foundation

enum PhoneNumberLength: Int {
    case sevenDigitNumber = 7
    case nineDigitNumber = 9
    case tenDigitNumber = 10
    case elevenDigitNumber = 11
}

public class CustomUtility: NSObject {

    public static func returnFormattedCurrency(_ number:NSNumber) -> String {
        
        let currencyFormatter = NumberFormatter()
        currencyFormatter.usesGroupingSeparator = true
        currencyFormatter.numberStyle = NumberFormatter.Style.currency
        currencyFormatter.minimumFractionDigits = 0
        currencyFormatter.maximumFractionDigits = 0
        currencyFormatter.locale = NSLocale.current
        let priceString = currencyFormatter.string(from: number)
        
        return priceString!
    }
    
    public static func returnStringInitials(_ string: String) -> String {
        
        if string.isEmpty || string.count <= 0 {
            return string 
        }
        
        let phoneNumChars : Set<Character> = Set("()+-1234567890")
         let numRemovedStr = String(string.filter {phoneNumChars.contains($0) == false }).trimmingCharacters(in: .whitespaces)
        
        var stringArray = numRemovedStr.components(separatedBy: " ")
        var initials : String? = ""
        if !(stringArray[0].isEmpty){
            initials = "\(stringArray[0][stringArray[0].startIndex])"
        }
        
        if stringArray.count > 1 &&  !(stringArray[1].isEmpty) {
            initials = initials!+"\(stringArray[1][stringArray[1].startIndex])"
        }
        
        guard let credentials = initials else {
            return ""
        }
        
        if credentials.count == 0 {
            return ""
        } else {
            return initials!.uppercased()
        }
      
    }
    
    public static func calculateLastDate() -> String {
        let today = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        let dayString: String = dateFormatter.string(from: today)
        let weekdayNum: Int = (dateFormatter.weekdaySymbols as NSArray).index(of: dayString)
        switch weekdayNum {
        case 0:
            let yesterday = today.addingTimeInterval(-86400.0*2)
            let dateString = yesterday.toString(dateFormat: "MMM dd,yyyy")
            return dateString
        case 1:
            let yesterday = today.addingTimeInterval(-86400.0*3)
            let dateString = yesterday.toString(dateFormat: "MMM dd,yyyy")
            return dateString
        default:
            let yesterday = today.addingTimeInterval(-86400.0)
            let dateString = yesterday.toString(dateFormat: "MMM dd,yyyy")
            return dateString
        }
    }
    
    public static func calculateStringForDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        let dateString = date.toString(dateFormat: "MMM dd,yyyy")
        return dateString
    }
    
    public static func comparePhone(ph1:String?, ph2:String?) -> Bool {
        
        //Phone 1
        var ph1_noformat = ""
        if let ph1 = ph1 {
            ph1_noformat = removeFormatting(ph1)
            if ph1_noformat.hasPrefix("+") == false{
                ph1_noformat = "+"+ph1_noformat
            }
        } else {
            return false
        }
        
        if ph1_noformat.isEmpty{
            return false
        }
        
        //Phone 2
        var ph2_noformat = ""
        if let ph2 = ph2 {
            ph2_noformat = removeFormatting(ph2)
            if ph2_noformat.hasPrefix("+") == false{
                ph2_noformat = "+"+ph2_noformat
            }
        } else {
            return false
        }
        
        if ph2_noformat.isEmpty{
            return false
        }
        
        return ph1_noformat == ph2_noformat
    }
   
    public static func removeFormattingAndPlus(_ phoneNumber: String) -> String{
        let okayChars : Set<Character> = Set("1234567890")
        return String(phoneNumber.filter {okayChars.contains($0) })
    }
    
    public static func removeFormatting(_ phoneNumber: String) -> String{
            let okayChars : Set<Character> = Set("1234567890+")
            return String(phoneNumber.filter {okayChars.contains($0) })        
    }
    
    static func format(phoneNumber rawNumber: String) -> String {
        
        let strippedNumber = stripPhoneNumberToDigitsOnly(rawPhoneNumber: rawNumber)
        let countryCodeIndex = strippedNumber.index(strippedNumber.startIndex, offsetBy: 1)
        let firstThreeDigitsIndex = strippedNumber.index(strippedNumber.startIndex, offsetBy: 3)
        
        switch strippedNumber.count {
        case PhoneNumberLength.sevenDigitNumber.rawValue:
            let lastFourDigitsIndex = strippedNumber.index(firstThreeDigitsIndex, offsetBy: 4)
            let firstThreeDigits = String( strippedNumber[..<firstThreeDigitsIndex])
            let lastFourDigits = String(strippedNumber[firstThreeDigitsIndex..<lastFourDigitsIndex])
            return "\(firstThreeDigits)-\(lastFourDigits)"
        case PhoneNumberLength.nineDigitNumber.rawValue:
            let secondThreeDigitsIndex =  strippedNumber.index(firstThreeDigitsIndex, offsetBy: 3)
            let lastThreeDigitsIndex =  strippedNumber.index(secondThreeDigitsIndex, offsetBy: 3)
            let areaCode = String(strippedNumber[..<firstThreeDigitsIndex])
            let firstThreeDigits = String(strippedNumber[firstThreeDigitsIndex..<secondThreeDigitsIndex])
            let lastThreeDigits = String(strippedNumber[secondThreeDigitsIndex..<lastThreeDigitsIndex])
            return "(\(areaCode)) \(firstThreeDigits)-\(lastThreeDigits)"
        case PhoneNumberLength.tenDigitNumber.rawValue:
            let secondThreeDigitsIndex =  strippedNumber.index(firstThreeDigitsIndex, offsetBy: 3)
            let lastFourDigitsIndex =  strippedNumber.index(secondThreeDigitsIndex, offsetBy: 4)
            let areaCode = String(strippedNumber[..<firstThreeDigitsIndex])
            let firstThreeDigits = String(strippedNumber[firstThreeDigitsIndex..<secondThreeDigitsIndex])
            let lastFourDigits = String(strippedNumber[secondThreeDigitsIndex..<lastFourDigitsIndex])
            return "(\(areaCode)) \(firstThreeDigits)-\(lastFourDigits)"
        case PhoneNumberLength.elevenDigitNumber.rawValue:
            let firstThreeDigitsIndexForElevenDigits = strippedNumber.index(countryCodeIndex, offsetBy: 3)
            let secondThreeDigitsIndexForElevenDigits = strippedNumber.index(firstThreeDigitsIndex, offsetBy: 4)
            let lastFourDigitsIndex = strippedNumber.index(secondThreeDigitsIndexForElevenDigits, offsetBy: 4)
            let countryCode = String(strippedNumber[..<countryCodeIndex])
            let areaCode = String(strippedNumber[countryCodeIndex...firstThreeDigitsIndex])
            let firstThreeDigits = String( strippedNumber[firstThreeDigitsIndexForElevenDigits..<secondThreeDigitsIndexForElevenDigits])
            let lastFourDigits = String(strippedNumber[secondThreeDigitsIndexForElevenDigits..<lastFourDigitsIndex])
            return "\(countryCode) (\(areaCode)) \(firstThreeDigits)-\(lastFourDigits)"
        default:
            return "❌ Invalid number length"
        }
        
    }
    
    static func stripPhoneNumberToDigitsOnly(rawPhoneNumber: String) -> String {
        let okayChars = Set("1234567890")
        return rawPhoneNumber.filter {okayChars.contains($0) }
    }

    class func removeSpecialCharsFromString(text: String) -> String {
        let okayChars = Set("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLKMNOPQRSTUVWXYZ1234567890+-=().")
        return text.filter {okayChars.contains($0) }
    }
}


extension UIApplication {
    class func topViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        
        if let nav = base as? UINavigationController {
            return topViewController(base: nav.visibleViewController)
        }
        
        if let tab = base as? UITabBarController {
            let moreNavigationController = tab.moreNavigationController
            
            if let top = moreNavigationController.topViewController, top.view.window != nil {
                return topViewController(base: top)
            } else if let selected = tab.selectedViewController {
                return topViewController(base: selected)
            }
        }
        
        if let presented = base?.presentedViewController {
            return topViewController(base: presented)
        }
        
        return base
    }
}

extension UserDefaults{
    //TODO: Can't see that these are being used, or even needed
    func setBadgeCount(value: Int){
        set(value, forKey: Constants.appBadgeCount)
    }
    
    func getBadgeCount() -> Int{
        return integer(forKey: Constants.appBadgeCount)
    }
}

extension  UIView {
    func roundedView() {
        let radius: CGFloat = self.bounds.size.width / 2.0
        self.layer.cornerRadius = radius
        self.clipsToBounds = true
        self.layoutIfNeeded()
    }
}


extension  UILabel {
     func rounded() {
        //super.layoutSubviews()
        let radius: CGFloat = self.bounds.size.width / 2.0
        self.layer.cornerRadius = radius
        self.clipsToBounds = true
    }
}

class RoundedImageView: UIImageView {
    override func layoutSubviews() {
        super.layoutSubviews()
        let radius: CGFloat = self.bounds.size.width / 2.0
        self.layer.cornerRadius = radius
        self.clipsToBounds = true
    }
}

class RoundedButton: UIButton {
    override func layoutSubviews() {
        super.layoutSubviews()
        let radius: CGFloat = self.bounds.size.height / 2.0
        self.layer.cornerRadius = radius
        self.clipsToBounds = true
    }
}


extension String {
    func height(constraintedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let label =  UILabel(frame: CGRect(x: 0, y: 0, width: width, height: .greatestFiniteMagnitude))
        label.numberOfLines = 0
        label.text = self
        label.font = font
        label.sizeToFit()
        
        return label.frame.height
    }
    
    func widthOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedStringKey.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.width
    }
    
    func heightOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedStringKey.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.height
    }
    
    func sizeOfString(usingFont font: UIFont) -> CGSize {
        let fontAttributes = [NSAttributedStringKey.font: font]
        return self.size(withAttributes: fontAttributes)
    }
}

extension UITableView {
    func scrollToLastCall(animated : Bool) {
        let lastSectionIndex = self.numberOfSections - 1 // last section
        let lastRowIndex = self.numberOfRows(inSection: lastSectionIndex) - 1 // last row
        self.scrollToRow(at: IndexPath(row: lastRowIndex, section: lastSectionIndex), at: .bottom, animated: animated)
    }
}


extension Notification.Name {
    public static let myNotificationKey = Notification.Name(rawValue: "remoteNotification")
    public static let msgStatusNotificationKey = Notification.Name(rawValue: "msgStatusNotificationKey")
    public static let chatListUpdateKey = Notification.Name(rawValue: "chatListUpdateKey")
    public static let silentPushNotificationKey = Notification.Name(rawValue: "silentPushNotificationKey")
}

extension UITextField {
    func bordered(color:CGColor) {
        self.layer.borderColor = color
        self.layoutIfNeeded()
    }
}
@IBDesignable extension UIButton {
    
    @IBInspectable override var borderWidth: CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    
    @IBInspectable override var cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
        }
        get {
            return layer.cornerRadius
        }
    }
    
    @IBInspectable override var borderColor: UIColor? {
        set {
            guard let uiColor = newValue else { return }
            layer.borderColor = uiColor.cgColor
        }
        get {
            guard let color = layer.borderColor else { return nil }
            return UIColor(cgColor: color)
        }
    }
}

@IBDesignable extension UIView {
    
    @IBInspectable var borderWidth: CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
        }
        get {
            return layer.cornerRadius
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        set {
            guard let uiColor = newValue else { return }
            layer.borderColor = uiColor.cgColor
        }
        get {
            guard let color = layer.borderColor else { return nil }
            return UIColor(cgColor: color)
        }
    }
}




