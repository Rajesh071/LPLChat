//
//  TouchID.swift
//  LPLChat
//
//  Created by Sanjeev Bharati on 3/28/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit
import LocalAuthentication

enum TouchIDAuthenticationStatus: Int {
    case success = 0
    case failure = 1
}

typealias TouchIdCompletionHandler = (TouchIDAuthenticationStatus) -> ()

class TouchIDUtility: NSObject {
    
    let context: LAContext = LAContext()
    
    // determine if the device is touch sensor or not
    func isDeviceCapable() -> Bool {
        
        let type = TouchIDUtility().biometricType()
        
        if (type.count > 0) {
            
            return true
        }
        
        return false
        
    }
    
    /// if device has capabilty to display finger prints display this alert
    static func displayTouchIdAlert(with completion: @escaping TouchIdCompletionHandler) {

        let touchIdUtil = TouchIDUtility()
        
        if !TouchIDUtility.isTouchIdConfigured() {
            return
        }
        
        touchIdUtil.context.localizedFallbackTitle = "Please Enter Password"
        touchIdUtil.context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                                    localizedReason: "Please Authenticate") { (wasSuccessfull, error) in
                                        
                                        if wasSuccessfull {
                                            completion(.success)
                                        } else {
                                            completion(.failure)
                                        }
        }
    }
    
    static func isTouchIdConfigured() -> Bool {
        var isConfigured = false
        
        if TouchIDUtility().isDeviceCapable() {
            isConfigured = UserDefaultUtil.getBoolValueOf(key: UserDefaultUtilConstants.displayTouchIdConst)
        }
        
        return isConfigured
    }
    
    // MARK: user pref
    static func getBiometricPref() -> Bool {
        
        if UserDefaults.standard.value(forKey: UserDefaultUtilConstants.biometricPrefConst) != nil {
            
            return UserDefaultUtil.getBoolValueOf(key: UserDefaultUtilConstants.biometricPrefConst)

        }
        return true
    }
    
    static func setBiometricPref(value: Bool) {
        UserDefaultUtil.configureBool(value: value,
                                      key: UserDefaultUtilConstants.biometricPrefConst)
    }
    
    
    static func enbableTouchId(value: Bool) {
        UserDefaultUtil.configureBool(value: value,
                                      key: UserDefaultUtilConstants.displayTouchIdConst)
    }
    
    static func disableTouchIDFeature(value: Bool) {
        UserDefaultUtil.configureBool(value: value,
                                      key: FeatureFlag.enableBiometric.rawValue)
    }
    
    // detect biometric type
    func biometricType() -> String {
        
            if #available(iOS 11.0, *) {
                let context = LAContext()
                
                var error: NSError?
                
                if context.canEvaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, error: &error) {
                    
                    if context.biometryType == .faceID {
                        
                        return "Face ID"
                    }
                    if context.biometryType == .touchID {
                        
                        return "Touch ID"
                    }
                }
            }
            return ""
 
    }
    
    //MARK:- TouchID enable or disable popup shown
    static func hasTouchIdAlertPopupShown() -> Bool {
        
        return UserDefaultUtil.getBoolValueOf(key: UserDefaultUtilConstants.displayTouchIdAlertPopup)
    }
    
    static func setTouchIdPopupDisplayState(to seenStatus: Bool) {
        UserDefaultUtil.configureBool(value: seenStatus,
                                      key: UserDefaultUtilConstants.displayTouchIdAlertPopup)
    }
    
}
