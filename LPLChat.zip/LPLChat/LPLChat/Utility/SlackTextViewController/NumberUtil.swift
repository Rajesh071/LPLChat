//
//  NumberUtil.swift
//  LPLMessages
//
//  Created by Sanjeev Bharati on 4/13/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UIKit

class NumberUtil: NSObject {

    public static func format(phoneNumber sourcePhoneNumber: String) -> String? {
        // Remove any character that is not a number
        let numbersOnly = sourcePhoneNumber.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        let length = numbersOnly.count
        let hasLeadingOne = numbersOnly.hasPrefix("1")
        
        // Check for supported phone number length
        guard length == 7 || length == 10 || (length == 11 && hasLeadingOne) else {
            return sourcePhoneNumber
        }
        
        let hasAreaCode = (length >= 10)
        var sourceIndex = 0
        
        // Leading 1
        if hasLeadingOne {
            sourceIndex += 1
        }
        
        // Area code
        var areaCode = ""
        if hasAreaCode {
            let areaCodeLength = 3
            guard let areaCodeSubstring = numbersOnly.substring(start: sourceIndex, offsetBy: areaCodeLength) else {
                return sourcePhoneNumber
            }
            areaCode = String(format: "(%@) ", areaCodeSubstring)
            sourceIndex += areaCodeLength
        }
        
        // Prefix, 3 characters
        let prefixLength = 3
        guard let prefix = numbersOnly.substring(start: sourceIndex, offsetBy: prefixLength) else {
            return sourcePhoneNumber
        }
        sourceIndex += prefixLength
        
        // Suffix, 4 characters
        let suffixLength = 4
        guard let suffix = numbersOnly.substring(start: sourceIndex, offsetBy: suffixLength) else {
            return sourcePhoneNumber
        }
        
        return "+1" + areaCode + prefix + "-" + suffix
    }
    
    class func removeSpecialCharatersFrom(text: String) -> String {
        let okayChars = Set("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLKMNOPQRSTUVWXYZ1234567890+-=().")
        return text.filter {okayChars.contains($0) }
    }

    public static func removeFormattingAndPlus(_ phoneNumber: String) -> String{
        let okayChars : Set<Character> = Set("1234567890")
        return String(phoneNumber.filter {okayChars.contains($0) })
    }
    
    public static func removeFormatting(_ phoneNumber: String) -> String{
        let okayChars : Set<Character> = Set("1234567890+")
        return String(phoneNumber.filter {okayChars.contains($0) })
    }
    
    public static func removeFormattingAnd1OrPlus1(_ phoneNumber: String) -> String {
        
        // if phone number is having 10 digits don't do any thing
        guard phoneNumber.count > 10 else {
            return phoneNumber
        }
        
        var formattedPhoneNumber = phoneNumber
        
        if (phoneNumber.contains("+1")) {
            // remove +1
            formattedPhoneNumber = phoneNumber.replacingOccurrences(of: "+1",
                                                                    with: "")
        } else if (phoneNumber.first == "1") {
            // check if phone number prefix with 1 take that out
            formattedPhoneNumber = String(phoneNumber.dropFirst())
        }
        
        return CustomUtility.removeFormattingAndPlus(formattedPhoneNumber)
    }
    
    public static func add1OrPlus1ToValidNumber(_ phoneNumber: String) -> String {
        
        var newPhone = phoneNumber.removeWhiteListedCharacters()
        
        if newPhone.count == 10 && newPhone.first != "1" {
            newPhone = "+1" + newPhone
        } else if newPhone.count == 11 && newPhone.first == "1" {
            newPhone = "+" + newPhone
        }
        
        return newPhone
    }
    
}


