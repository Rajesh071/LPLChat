Configurations:
Dev, QA, AppStore

Version # 
As part of the octopus continuous builds, soon we will automate build number incrementing when a project’s develop branch updates:

1.	TeamCity, which runs app builds when kicked off, will own the version numbers. Once this is working, we will not be manually editing the info.plist to change version numbers.
2.	TeamCity will have a way for us to manually change the Bundle Version, Short (i.s. the app version). It will not touch this number otherwise.
3.	TeamCity will automatically increment the Bundle Version (the build number) every time there is a merge to develop, and will commit that change back to the develop branch.
4.	Note that for feature branches all this is a dont-care.


Version History

Version 1.2.0
New Registration 
