//: Playground - noun: a place where people can play

import UIKit

enum PhoneNumberLength: Int {
    
    case sevenDigitNumber = 7
    case tenDigitNumber = 10
    case elevenDigitNumber = 11
    
}

var rawSevenDigitPhoneNumber = "5551234"
var rawTenDigitPhoneNumber = "1262789900"
var rawElevenDigitPhoneNumber = "15550007777"

func format(phoneNumber rawNumber: String) -> String {

    let countryCodeIndex = rawNumber.index(rawNumber.startIndex, offsetBy: 1)
    let firstThreeDigitsIndex = rawNumber.index(rawNumber.startIndex, offsetBy: 3)

    switch rawNumber.count {
    case PhoneNumberLength.sevenDigitNumber.rawValue:
        let lastFourDigitsIndex = rawNumber.index(firstThreeDigitsIndex, offsetBy: 4)
        let firstThreeDigits = String(rawNumber[..<firstThreeDigitsIndex])
        let lastFourDigits = String(rawNumber[firstThreeDigitsIndex..<lastFourDigitsIndex])
        return "\(firstThreeDigits)-\(lastFourDigits)"
    case PhoneNumberLength.tenDigitNumber.rawValue:
        let secondThreeDigitsIndex = rawNumber.index(firstThreeDigitsIndex, offsetBy: 3)
        let lastFourDigitsIndex = rawNumber.index(secondThreeDigitsIndex, offsetBy: 4)
        let areaCode = String(rawNumber[..<firstThreeDigitsIndex])
        let firstThreeDigits = String(rawNumber[firstThreeDigitsIndex..<secondThreeDigitsIndex])
        let lastFourDigits = String(rawNumber[secondThreeDigitsIndex..<lastFourDigitsIndex])
        return "(\(areaCode)) \(firstThreeDigits)-\(lastFourDigits)"
    case PhoneNumberLength.elevenDigitNumber.rawValue:
        let firstThreeDigitsIndexForElevenDigits = rawNumber.index(countryCodeIndex, offsetBy: 3)
        let secondThreeDigitsIndexForElevenDigits = rawNumber.index(firstThreeDigitsIndex, offsetBy: 4)
        let lastFourDigitsIndex = rawNumber.index(secondThreeDigitsIndexForElevenDigits, offsetBy: 4)
        let countryCode = String(rawNumber[..<countryCodeIndex])
        let areaCode = String(rawNumber[countryCodeIndex...firstThreeDigitsIndex])
        let firstThreeDigits = String(rawNumber[firstThreeDigitsIndexForElevenDigits..<secondThreeDigitsIndexForElevenDigits])
        let lastFourDigits = String(rawNumber[secondThreeDigitsIndexForElevenDigits..<lastFourDigitsIndex])
        return "\(countryCode) (\(areaCode)) \(firstThreeDigits)-\(lastFourDigits)"
    default:
        return "❌ Invalid number length"
    }
    
}

print(format(phoneNumber: rawSevenDigitPhoneNumber))
print(format(phoneNumber: rawTenDigitPhoneNumber))
print(format(phoneNumber: rawElevenDigitPhoneNumber))


