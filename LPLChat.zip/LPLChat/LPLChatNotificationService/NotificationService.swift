//
//  NotificationService.swift
//  LPLChatNotificationService
//
//  Created by Phillip English on 5/24/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import UserNotifications


class NotificationService: UNNotificationServiceExtension {

    var contentHandler: ((UNNotificationContent) -> Void)?
    var bestAttemptContent: UNMutableNotificationContent?

    override func didReceive(_ request: UNNotificationRequest, withContentHandler contentHandler: @escaping (UNNotificationContent) -> Void) {
        self.contentHandler = contentHandler
        bestAttemptContent = (request.content.mutableCopy() as? UNMutableNotificationContent)
        
        if let bestAttemptContent = bestAttemptContent {
            // Modify the notification content here...
            //bestAttemptContent.title = "\(bestAttemptContent.title) [modified]"
            let numbersRange = bestAttemptContent.title.rangeOfCharacter(from: .decimalDigits)
            let hasNumbers = (numbersRange != nil)
            if hasNumbers {
            var nameFromNumber = ContactUtility.mapName(to: bestAttemptContent.title) //ContactUtility.mapPhoneWith(bestAttemptContent.title)
            if nameFromNumber != "Wrong Name Displayed" {
                if nameFromNumber.rangeOfCharacter(from: .decimalDigits) != nil {
                    //nameFromNumber = nameFromNumber.removeWhiteListedCharacters()
                    if let formattedNumber = NumberUtil.format(phoneNumber: nameFromNumber) {
                    nameFromNumber = formattedNumber.replacingOccurrences(of: "+", with: "").replacingOccurrences(of: "1(", with: "(")
                    }
                    
                }
            bestAttemptContent.title = nameFromNumber
            
            }
            
            bestAttemptContent.body = "You Have Received a Message"
            
            contentHandler(bestAttemptContent)
            }
        }
    }
    
    override func serviceExtensionTimeWillExpire() {
        // Called just before the extension will be terminated by the system.
        // Use this as an opportunity to deliver your "best attempt" at modified content, otherwise the original push payload will be used.
        
        if let contentHandler = contentHandler, let bestAttemptContent =  bestAttemptContent {
            bestAttemptContent.title = ""
            bestAttemptContent.body = "You Have Received a Message"
            contentHandler(bestAttemptContent)
        }
    }

}
