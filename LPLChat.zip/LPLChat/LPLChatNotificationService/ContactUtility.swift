//
//  ContactUtility.swift
//  LPLChatNotificationService
//
//  Created by Phillip English on 5/28/18.
//  Copyright © 2018 LPL. All rights reserved.
//

import Foundation
import Contacts
import AddressBook


public class ContactUtility {
    
    func mapDeviceContactsToName() -> [String : String] {
        
        var localContactDict: [String: String] = [:]
        let contacts = ContactUtility.deviceContacts()
        
        for contact in contacts {
            let fullName = contact.givenName + " " + contact.familyName
            for phoneNumber in contact.phoneNumbers {
                
                // phoneNumber: is of type CNLabeledValue<CNPhoneNumber>
                self.add(contactNumber: phoneNumber.value.stringValue,
                         contactName: fullName,
                         to: &localContactDict)
            }
        }
        
        return localContactDict
    }
    
    func add(contactNumber: String,
             contactName: String,
             to dict:inout [String: String]) {
        
        var unFormattedValue = contactNumber.removeWhiteListedCharacters()
//        dict.updateValue(contactName,
//                        forKey: unFormattedValue)
        
        
        if unFormattedValue.isNumber && unFormattedValue.count >= 10 {
            
            // has 10 digits only then prepend ISD code
            if unFormattedValue.count == 10 {
                unFormattedValue = "1" + unFormattedValue
            }
            
            dict.updateValue(contactName,
                             forKey: unFormattedValue)
        }
    }
    
    func localAddressBookContacts() -> [CNContact] {
        let contactStore = CNContactStore()
        var contacts = [CNContact]()
        let keys = [
            CNContactPostalAddressesKey,
            CNContactFormatter.descriptorForRequiredKeys(for: .fullName),
            CNContactPhoneNumbersKey,
            CNContactEmailAddressesKey
            ] as [Any]
        
        let request = CNContactFetchRequest(keysToFetch: keys as! [CNKeyDescriptor])
        
        do {
            try contactStore.enumerateContacts(with: request) { (contact, stop) in
                contacts.append(contact)
            }
        } catch {
            print(error.localizedDescription)
        }
        
        return contacts
    }
    
    static func deviceContacts() -> [CNContact] {
        let contactStore = CNContactStore()
        var contacts = [CNContact]()
        let keys = [
            CNContactPostalAddressesKey,
            CNContactFormatter.descriptorForRequiredKeys(for: .fullName),
            CNContactPhoneNumbersKey,
            CNContactEmailAddressesKey
            ] as [Any]
        
        let request = CNContactFetchRequest(keysToFetch: keys as! [CNKeyDescriptor])
        request.sortOrder = CNContactSortOrder.givenName
        
        do {
            try contactStore.enumerateContacts(with: request) { (contact, stop) in
                contacts.append(contact)
            }
        } catch {
            print(error.localizedDescription)
        }
        
        return contacts
    }
    
    func phoneContacts() -> [String : String] {
        var localContactDict: [String: String] = [:]
        let contacts = ContactUtility().localAddressBookContacts()
        for contact in contacts {
            
            let fullName = contact.givenName + " " + contact.familyName
            
            for phoneNumber in contact.phoneNumbers {
                let number: CNLabeledValue<CNPhoneNumber> = phoneNumber
                localContactDict.updateValue(fullName,
                                             forKey: ContactUtility.removeSpecialCharactersFromNumber(number.value.stringValue))
            }
        }
        
        return localContactDict
    }
    
    static func contactListToMap() -> [String : String] {
        
        var finalContactDict = [String:String]()
        finalContactDict.update(other: ContactUtility().mapDeviceContactsToName())
        //finalContactDict.update(other: ContactUtility().mapClientWorkContactsToName())
        
        return finalContactDict
    }
    
    class func uncountFirstCharacter(str: String?) -> String {
        guard let newString = str else {
            return ""
        }
        
        let startIndex = newString.index(after: newString.startIndex)
        let endIndex = newString.index(before: newString.endIndex)
        
        return String(newString[startIndex ... endIndex])
    }
    
    class func removeSpecialCharactersFromNumber(_ number: String) -> String {
        
        var contact = ""
        if number.count > 0 {
            let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
            let compSepByCharInSet = number.components(separatedBy: aSet)
            let numberFiltered = compSepByCharInSet.joined(separator: "")
            contact = numberFiltered
        }
        
        return contact
    }
    
    
    static func mapName(to phoneNumber:String) -> String {
        
        let map = self.contactListToMap()
        
       
        var unformattedPhoneNumber = phoneNumber.removeWhiteListedCharacters()
        if unformattedPhoneNumber.count == 10 {
        unformattedPhoneNumber = "1"+unformattedPhoneNumber
        }
        
        guard let value = map[unformattedPhoneNumber] else {
            // if name did not match in the list return the number as name
            return NumberUtil.format(phoneNumber: phoneNumber)!
        }
        
        return value
    }
    
}

struct NumberUtil {
    static func format(phoneNumber sourcePhoneNumber: String) -> String? {
        // Remove any character that is not a number
        let numbersOnly = sourcePhoneNumber.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        let length = numbersOnly.count
        let hasLeadingOne = numbersOnly.hasPrefix("1")
        
        // Check for supported phone number length
        guard length == 7 || length == 10 || (length == 11 && hasLeadingOne) else {
            return sourcePhoneNumber
        }
        
        let hasAreaCode = (length >= 10)
        var sourceIndex = 0
        
        // Leading 1
        if hasLeadingOne {
            sourceIndex += 1
        }
        
        // Area code
        var areaCode = ""
        if hasAreaCode {
            let areaCodeLength = 3
            guard let areaCodeSubstring = numbersOnly.substring(start: sourceIndex, offsetBy: areaCodeLength) else {
                return sourcePhoneNumber
            }
            areaCode = String(format: "(%@) ", areaCodeSubstring)
            sourceIndex += areaCodeLength
        }
        
        // Prefix, 3 characters
        let prefixLength = 3
        guard let prefix = numbersOnly.substring(start: sourceIndex, offsetBy: prefixLength) else {
            return sourcePhoneNumber
        }
        sourceIndex += prefixLength
        
        // Suffix, 4 characters
        let suffixLength = 4
        guard let suffix = numbersOnly.substring(start: sourceIndex, offsetBy: suffixLength) else {
            return sourcePhoneNumber
        }
        
        return "+1" + areaCode + prefix + "-" + suffix
    }
}

extension String {
    
    func trim() -> String    {
        return self.trimmingCharacters(in: NSCharacterSet.whitespaces)
    }
    
    var isNumber: Bool {
        let characters = CharacterSet.decimalDigits.inverted
        return !self.isEmpty && rangeOfCharacter(from: characters) == nil
    }
    
    func convertToDate() -> Date {
        let dateStr = self
        let formatter = ISO8601DateFormatter()
        
        formatter.formatOptions = [.withFullDate,
                                   .withTime,
                                   .withDashSeparatorInDate,
                                   .withColonSeparatorInTime]
        
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        
        
        
        let date = formatter.date(from: dateStr)
        
        if date != nil{
            return date!
        }
        return Date()
    }
    
    internal func substring(start: Int, offsetBy: Int) -> String? {
        guard let substringStartIndex = self.index(startIndex, offsetBy: start, limitedBy: endIndex) else {
            return nil
        }
        
        guard let substringEndIndex = self.index(startIndex, offsetBy: start + offsetBy, limitedBy: endIndex) else {
            return nil
        }
        
        return String(self[substringStartIndex ..< substringEndIndex])
    }
    
    // #ffffff - White
    func webViewCompatible(colorHex: String? = "#ffffff") -> String {
        let string = "<html><body style=\"font-size: 17; text-align:justify; font-family: Helvetica; color: \(colorHex!)\">\(self)</body></html>"
        
        return string
    }
    
    func stringByRemovingEmoji() -> String {
        return String(self.filter { !$0.isEmoji() })
    }
    
    func removeWhiteListedCharacters() -> String {
        // white listed characters {+, - , (, ), " "}
        
        var input = self
        let whiteListedCharacters = ["+", "-", "(", ")", " "]
        
        for character in whiteListedCharacters {
            input = input.replacingOccurrences(of: character, with: "")
        }
        
        return input.removeWhitespaces()
    }
    
    func removeWhitespaces() -> String {
        return components(separatedBy: .whitespaces).joined()
    }
    
}

extension Character {
    fileprivate func isEmoji() -> Bool {
        return Character(UnicodeScalar(UInt32(0x1d000))!) <= self && self <= Character(UnicodeScalar(UInt32(0x1f77f))!)
            || Character(UnicodeScalar(UInt32(0x2100))!) <= self && self <= Character(UnicodeScalar(UInt32(0x26ff))!)
    }
}

extension Dictionary {
    
    mutating func update(other:Dictionary) {
        for (key,value) in other {
            self.updateValue(value, forKey:key)
        }
    }
    
}
